var twentyFourHourTime = false;
//var locale = "38671" //e.g. 'Defiance, Ohio'|'Moscow, Russia'|'Ledyard, AT'|'London, UK'
//var isCelsius = true //true|false
//var useRealFeel = false //true|false
var enableWallpaper = false; //true|false
var enableLockScreen = true; //true|false
var stylesheetWall = 'none' 
var stylesheetLock = 'LockScreen'
var iconSetWall = 'none' //
var iconExtWall = ".png" //'.png'|.'gif' etc.
var iconSetLock = 'IconSets'
var iconExtLock = '.png' 
var updateInterval = 19 //Minutes/>
//Toggles twelve and twenty-four hour time.