var updateInterval = 20
var TwentyFourHourClock = true
var showLeadingZero = true
var showBackground = true




