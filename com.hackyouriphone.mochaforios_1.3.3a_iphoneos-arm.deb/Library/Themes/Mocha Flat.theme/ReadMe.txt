Thank you for downloading this theme. It means a lot to me (even if you pirated it - Although I would really appreciate it if you bought it). I worked hard on this theme and I hope you like it as much as I do.

——————————————————————————————————————————————

Thank you again

       -Max Gerber

@IconixDesign
IconixDesign1@gmail.com