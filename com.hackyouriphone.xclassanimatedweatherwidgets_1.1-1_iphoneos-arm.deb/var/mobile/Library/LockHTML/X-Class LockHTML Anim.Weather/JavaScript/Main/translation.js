// Translation file for UniAW6.2 by Ian Nicoll, with credit to Dacal, languages and missing translations added by BLUE


// TRANSLATION FOR MAIN ELEMENTS

switch (lang) {
     case "da":
		var days = ["S\u00F8ndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "L\u00F8rdag"];
		var months = ["Januar", "Februar", "Marts", "April", "Maj", "Juni", "Juli", "August", "September", "Oktober", "November", "December"];
		var hightext = "H\u00F8j:";
		var lowtext = "Lav:";
		var sunrisetext = "Morgen";
		var sunsettext = "Aften";
		var feelsliketext = "F\u00F8les som: ";
		var lastupdatetext = "Sidste Update: ";
		var visibilitytext = "Sigtbarhed: ";
		var humiditytext = "Luftfugtihed: ";
		var pressuretext = "Lufttryk: ";
		var windtext = "Vind: ";
		var UVIndextext = "UV-index: "; 
	break;
	case "cn":
		var days = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
		var months = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
		var hightext = "最高:";
		var lowtext = "最低:";
		var sunrisetext = "日出";
		var sunsettext = "日落";
		var feelsliketext = "感覺像:";
		var pressuretext = "最高:";	
		var lastupdatetext = "上次更新: ";
		var visibilitytext = "能见度: ";
		var humiditytext = "湿度: ";
		var windtext = "风向: ";
		var UVIndextext = "紫外線指數: ";
	break;
	case "fi":
		var days = ["Sunnuntai", "Maanantai", "Tiistai", "Keskiviikko", "Torstai", "Perjantai", "Lauantai"];
		var months = ["Tammikuu", "Helmikuu", "Maaliskuu", "Huhtikuu", "Toukokuu", "Kesäkuu", "Heinäkuu", "Elokuu", "Syyskuu", "Lokakuu", "Marraskuu", "Joulukuu"];
		var hightext = "Korke.:";
		var lowtext = "Alin:";
		var sunrisetext = "Aamu";
		var sunsettext = "Yö";
		var feelsliketext = "Tuntuu: ";
		var pressuretext = "Paine: ";	
		var lastupdatetext = "Päivitetään: ";
		var visibilitytext = "Näkyvyys: ";
		var humiditytext = "Ilmankosteus: ";
		var windtext = "Tuuli: ";
		var UVIndextext = "UV-indeksi: ";
    break;	
	case "fr":
		var days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
		var months = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Aout", "Septembre", "Octobre", "Novembre", "Decembre"];
		var hightext = "Max:";
		var lowtext = "Min:";
		var sunrisetext = "Lever";
		var sunsettext = "Coucher";
		var feelsliketext = "Ressentie: ";
		var lastupdatetext = "Mise à jour: ";
		var humiditytext = "Humidité: ";	
		var visibilitytext = "Visibilité: ";	
		var pressuretext = "Pression: ";
		var windtext = "Vent: ";
		var UVIndextext = "indice UV: ";
    break;
    case "tr":
	var days = ["Pazar","Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi"];
	var months=['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
		var lowtext = "düş.:";
		var hightext = "yüks.:";
		var sunrisetext = "Morgen";
		var sunsettext = "Abend";
		var feelsliketext = "Gefühlte: ";
		var lastupdatetext = "Letztes Update: ";
		var visibilitytext = "Sichtweite: ";
		var humiditytext = "Luftfeuchte: ";
		var pressuretext = "Luftdruck: ";
		var windtext = "Wind: ";
		var UVIndextext = "UV-index: "; 
	break;
	case "ge":
		var days = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
		var months = ["Januar", "Februar", "Maerz", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
		var hightext = "Hoch:";
		var lowtext = "Tief:";
		var sunrisetext = "Morgen";
		var sunsettext = "Abend";
		var feelsliketext = "Gefühlte: ";
		var lastupdatetext = "Letztes Update: ";
		var visibilitytext = "Sichtweite: ";
		var humiditytext = "Luftfeuchte: ";
		var pressuretext = "Luftdruck: ";
		var windtext = "Wind: ";
		var UVIndextext = "UV-index: "; 
	break;
	case "nl":
		var days = ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"];
		var months = ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"];
		var hightext = "Hoog:";
		var lowtext = "Laag:";
		var sunrisetext ="Ochtend";
		var sunsettext = "Nacht";
		var feelsliketext = "Feels like: ";
		var lastupdatetext = "Laatste Update: ";
		var humiditytext = "Vochtigheid: ";
		var visibilitytext = "Zichtbaarheid: "; 
		var pressuretext = "Druk: ";
		var windtext = "Wind: ";
		var UVIndextext = "UV-index: ";
	break;

	case "sp":
		var days = ["Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab"];
		var months = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
		var hightext = "Alto:";
		var lowtext = "Bajo:";
		var sunrisetext ="Mañana";
		var sunsettext = "Noche";
		var feelsliketext = "se siente como: ";
		var lastupdatetext = "Actualizado: ";
		var humiditytext = "Humedad: ";
		var visibilitytext = "Visibilidad: ";
		var pressuretext = "Presion: ";
		var windtext = "Viento: ";
		var UVIndextext = "índice: ";
    break;
	case "it":
		var days = ["Domenica", "Lunedi", "Martedì", "Mercoledì", "Giovedi", "Venerdì", "Sabato"];
		var months = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
		var hightext = "Alto:";
		var lowtext = "Bass.:";
		var sunrisetext ="Alba";
		var sunsettext = "Tramonto";
		var feelsliketext = "Percepita: ";
		var lastupdatetext = "Attuale: ";
		var humiditytext = "Umidita: ";
		var visibilitytext = "Visibilita: ";
		var pressuretext = "Pressione: ";
		var windtext = "Vento: ";
		var UVIndextext = "Indice UV: ";	
    break;
	case "ru":

		var days = ["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"];
		var months = ['Января','Февраля','Марта','Апреля','Мая','Июня','Июля','Августа','Сентября','Октября','Ноября','Декабря'];
		var hightext = "прив.:";
		var lowtext = "вот:";
		var sunrisetext ="утро";
		var sunsettext = "закат";
		var feelsliketext = "По ощущению: ";
		var lastupdatetext = "обновлены в: ";
		var humiditytext = "Влажность: ";
		var visibilitytext = "видимость: ";
		var pressuretext = "давление: ";
		var windtext = "ветер: ";
		var UVIndextext = "УФ-индекс: ";

	break;
	default: 
		var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
		var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
		var hightext = "High:";
		var lowtext = "Low:";
		var sunrisetext ="Sunrise";
		var sunsettext = "Sunset";
		var feelsliketext = "Feels like: ";
		var lastupdatetext = "Last update: ";
		var humiditytext = "Humidity: ";
		var visibilitytext = "Visibility: ";
		var pressuretext = "Pressure: ";
		var windtext = "Wind: ";
		var UVIndextext = "UV index: ";
	break;
}

// TRANSLATION FOR WEATHER CONDITIONS
function Translate(desc) {
translatedesc = desc.toLowerCase();		
switch (lang) {

case "da":
		    if (translatedesc=='cloudy/windy') { return 'Skyet/Bl\u00E6sende'; }
			if (translatedesc=='sunny') { return 'Sol'; }
			if (translatedesc=='drizzle') { return 'Sm\u00E5 Regn'; }
			if (translatedesc=='heavy snow') { return 'Kraftig Snefald'; }	
			if (translatedesc=='heavy rain') { return 'Kraftige Regnbyger'; }	
			if (translatedesc=='rain and snow') { return 'Regn og Sne'; }
			if (translatedesc=='mixed rain and snow') { return 'Regn og Sne'; }
			if (translatedesc=='fair') { return 'Klart'; }
			if (translatedesc=='mostly sunny') { return 'Mest Sol';   }
			if (translatedesc=='partly sunny') { return 'Delvis Sol';   }
			if (translatedesc=='intermittent clouds') { return 'Lettere Skyet';	 }
			if (translatedesc=='hazy sunshine') { return 'Diset Solskin;'; }
			if (translatedesc=='haze') { return 'Diset'; }
			if (translatedesc=='mostly cloudy') { return 'Mest skyet'; }
			if (translatedesc=='cloudy') { return 'Skyet'; }
			if (translatedesc=='fog') { return 'T\u00E5get'; }
			if (translatedesc=='showers') { return 'Regnbyger'; }
			if (translatedesc=='partly sunny with showers') { return 'Sol og Regnbyger';	}
			if (translatedesc=='thunderstorms') { return 'Torden'; }
			if (translatedesc=='thunderstorm') { return 'Torden'; }
			if (translatedesc=='mostly cloudy with thunder showers') { return 'Skyet med Tordenbyger';	  }
			if (translatedesc=='partly sunny with thunder showers') { return 'Lettere Skyet med Tordenbyger';	  }
			if (translatedesc=='light rain') { return 'Let Regn'; }
			if (translatedesc=='rain') { return 'Regn'; }
			if (translatedesc=='flurries') { return 'Vindst\u00F8d';	}
			if (translatedesc=='mostly cloudy with flurries') { return 'Mest Skyet og Bl\u00E6sende';	  }
			if (translatedesc=='partly sunny with flurries') { return 'Delvis Sol og Bl\u00E6sende';    }
			if (translatedesc=='snow flurries') { return 'Sne Fnug'; }
			if (translatedesc=='snow showers') { return 'Snebyger'; }
			if (translatedesc=='snow') { return 'Sne'; }
			if (translatedesc=='mostly cloudy with snow') { return 'Mest Skyet med Sne';	}
			if (translatedesc=='ice') { return 'Is';	}
			if (translatedesc=='sleet') { return 'Slud'; }
			if (translatedesc=='freezing rain') { return 'Islag'; }
			if (translatedesc=='rain and snow mixed') { return 'Slud';	}
			if (translatedesc=='hot') { return 'Varmt'; }
			if (translatedesc=='cold') { return 'Koldt'; }
			if (translatedesc=='windy') { return 'Bl\u00E6sende'; }
			if (translatedesc=='clear') { return 'Klart'; }
			if (translatedesc=='mostly clear') { return 'Mest Klart';	}
			if (translatedesc=='partly cloudy') { return 'Delvis Skyet';	 }
			if (translatedesc=='hazy') { return 'T\u00E5get';	  }
			if (translatedesc=='partly cloudy with showers') { return 'Delvis Skyet og Regn';	}
			if (translatedesc=='mostly cloudy with showers') { return 'Overskyet og Regn';	  }
			if (translatedesc=='partly cloudy with thunder showers') { return 'Delvis Skyet og Torden';	 }
			if (translatedesc=='foggy') { return 'T\u00E5get'; }
			if (translatedesc=='light snow') { return 'Let Sne'; }
			if (translatedesc=='light snow showers') { return 'Lette Snebyger'; }
			if (translatedesc=='rain shower') { return 'RegnByger'; }
			if (translatedesc=='light drizzle') { return 'Let Sm\u00E5Regn'; }
			if (translatedesc=='mixed rain and sleet') { return 'Regn og Slud'; }
			if (translatedesc=='mixed snow and sleet') { return 'Sne og Slud'; }
			if (translatedesc=='severe thunderstorms') { return 'Kraftig Torden'; }
			if (translatedesc=='hurricane') { return 'Orkan'; }
			if (translatedesc=='tropical storm') { return 'Tropisk Storm'; }
			if (translatedesc=='tornado') { return 'Tornado!'; }
			if (translatedesc=='freezing drizzle') { return 'Frysende Regn'; }
			if (translatedesc=='blowing snow') { return 'Bl\u00E6sende Sne'; }
			if (translatedesc=='hail') { return 'Hagl'; }
			if (translatedesc=='dust') { return 'St\u00F8vet'; }
			if (translatedesc=='smoky') { return 'R\u00F8g'; }
			if (translatedesc=='blustery') { return 'Bl\u00E6sende'; }
			if (translatedesc=='mixed rain and hail') { return 'Regn og Hagl'; }
			if (translatedesc=='isolated thunderstorms') { return 'Enkelte Tordenbyger'; }
			if (translatedesc=='scattered thunderstorms') { return 'Spredte Tordenbyger'; }
			if (translatedesc=='scattered showers') { return 'Spredte Byger'; }
			if (translatedesc=='scattered snow showers') { return 'Spredte Snebyger'; }
			if (translatedesc=='light rain with thunder') { return 'Let Regn og Torden';	}
			if (translatedesc=='not available') { return 'Ingen Info'; }
			if (translatedesc=='drifting snow/windy') { return 'FygeSne/Bl\u00E6sende';    }
			if (translatedesc=='light rain shower') { return 'Lette Regnbyger'; }
			if (translatedesc=='thunder') { return 'Torden'; }
			if (translatedesc=='mostly cloudy/windy') { return 'Overskyet/Bl\u00E6sende'; }
			if (translatedesc=='sandstorm') { return 'Sandstorm'; }
			if (translatedesc=='squalls/windy') { return 'Vindst\u00F8d/Bl\u00E6sende'; }
			if (translatedesc=='sand') { return 'Sand i Luften'; }
			if (translatedesc=='sandstorm/windy') { return 'Sandstorm'; }
			if (translatedesc=='squalls') { return 'Vindst\u00F8d'; }
			if (translatedesc=='light snow grains') { return 'Lette Snebyger'; }
			if (translatedesc=='thundershowers') { return 'Tordenbyger'; }
			if (translatedesc=='isolated thundershowers') { return 'Enkelte Tordenbyger'; }
			if (translatedesc=='showers in the vicinity') { return 'Rengbyger i Omr\u00E5det'; }
			if (translatedesc=='partly sunny') { return 'Delvis Sol'; }
			if (translatedesc=='ground fog') { return 'T\u00E6t T\u00E5e'; }
			if (translatedesc=='mist') { return 'T\u00E5ge'; }
			if (translatedesc=='severe thunderstorm/windy') { return 'Kraftig Torden/bl\u00E6st'; }
		break;

	    case "tr":

			if (translatedesc=='mist') { return 'sis'; }

			if (translatedesc=='sunny') { return 'Güneşli'; }
			
			if (translatedesc=='cloudy/windy') { return 'bulutlu ve rüzgarlı'; }

			if (translatedesc=='drizzle') { return 'Hafif Yağmur'; }

			if (translatedesc=='heavy snow') { return 'Yoğun Kar'; }

			if (translatedesc=='heavy rain') { return 'Çok Yağmurlu'; }

			if (translatedesc=='rain and snow') { return 'Yağmur ve Kar'; }

			if (translatedesc=='mixed rain and snow') { return 'Karla Karışık Yağmur'; }

			if (translatedesc=='fair') { return 'Açık';    }

			if (translatedesc=='mostly sunny') { return 'Çok Güneşli';     }

			if (translatedesc=='partly sunny') { return 'Hafif Güneşli';   }

			if (translatedesc=='intermittent clouds') { return 'Parçalı Bulutlu';}

			if (translatedesc=='hazy sunshine') { return 'Puslu Güneşli'; }

			if (translatedesc=='haze') { return 'Puslu'; }

			if (translatedesc=='mostly cloudy') { return 'Çok Bulutlu';   }

			if (translatedesc=='cloudy') { return 'Bulutlu';     }

			if (translatedesc=='fog') { return 'Sisli';   }

			if (translatedesc=='showers') { return 'Sağanak';    }

			if (translatedesc=='partly sunny with showers') { return 'Hafif Güneşli Yağmur';      }

			if (translatedesc=='thunderstorms') { return 'Gök Gürültülü';	 }

			if (translatedesc=='thunderstorm') { return 'Gök Gürültülü';	}

			if (translatedesc=='mostly cloudy with thunder showers') { return 'Gök Gürültülü Bulutlu';     }

			if (translatedesc=='partly sunny with thunder showers') { return 'Gök Gürültülü Güneşli';    }

			if (translatedesc=='light rain') { return 'Hafif Yağmur';   }

			if (translatedesc=='rain') { return 'Yağmurlu';    }

			if (translatedesc=='flurries') { return 'Esintili'; }

			if (translatedesc=='mostly cloudy with flurries') { return 'Çok Bulutlu Esintili';   }

			if (translatedesc=='partly sunny with flurries') { return 'Hafif Hüneşli Esintili';    }

			if (translatedesc=='snow flurries') { return 'Kar Esintisi';	}

			if (translatedesc=='snow showers') { return 'Kar Yağışlı';    }

			if (translatedesc=='snow') { return 'Karlı';   }

			if (translatedesc=='mostly cloudy with snow') { return 'Çok Bulutlu ve Karlı';	     }

			if (translatedesc=='ice') { return 'Buzlu';  }

			if (translatedesc=='sleet') { return 'Sulu Kar';     }

			if (translatedesc=='freezing rain') { return 'Dondurucu Yağmur';      }

			if (translatedesc=='rain and snow mixed') { return 'Karla Karışık Yağmur'; }

			if (translatedesc=='hot') { return 'Sıcak';    }

			if (translatedesc=='cold') { return 'Soğuk';   }

			if (translatedesc=='windy') { return 'Rüzgarlı';    }

			if (translatedesc=='clear') { return 'Açık';	}

			if (translatedesc=='mostly clear') { return 'Çok Açık';      }

			if (translatedesc=='partly cloudy') { return 'Hafif Açık';    }

			if (translatedesc=='hazy') { return 'Puslu';	}

			if (translatedesc=='partly cloudy with showers') { return 'Parçalı Bulutlu Sağanak'; }

			if (translatedesc=='mostly cloudy with showers') { return 'Çok Bulutlu Sağanak';       }

			if (translatedesc=='party cloudy with thunder showers') { return 'Parçalı Bulutlu Gök Gürültülü';     }

			if (translatedesc=='foggy') { return 'Sisli';	      }

			if (translatedesc=='light snow') { return 'Hafif Karlı'; }

			if (translatedesc=='light snow showers') { return 'Hafif Kar Yağışlı'; }       

			if (translatedesc=='rain shower') { return 'Sağanak Yağmur';  }

			if (translatedesc=='drizzle') { return 'Hafif Yağmur';	      }

			if (translatedesc=='mixed rain and sleet') { return 'Sulusepken Yağmurlu';    }

			if (translatedesc=='mixed snow and sleet') { return 'Sulusepken Karlı';    }

			if (translatedesc=='severe thunderstorms') { return 'Yoğun Gök Gürültülü';    }

			if (translatedesc=='hurricane') { return 'Kasırga';    }

			if (translatedesc=='tropical storm') { return 'Tropikal Fırtına';      }

			if (translatedesc=='tornado') { return 'Hortum';     }

			if (translatedesc=='freezing drizzle') { return 'Dondurucu Hafif Yağmur';      }

			if (translatedesc=='blowing snow') { return 'Rüzgarlı Kar'; }

			if (translatedesc=='hail') { return 'Dolu Yağışı'; }

			if (translatedesc=='dust') { return 'Tozlu'; }

			if (translatedesc=='smoky') { return 'Nemli';	 }

		if (translatedesc=='blustery') { return 'Şiddetli Rüzgar';	  }

			if (translatedesc=='mixed rain and hail') { return 'Dolu Karışık Yağmurlu';    }

			if (translatedesc=='isolated thunderstorms') { return 'İzole Gök Gürültülü';	}

			if (translatedesc=='isolated thundershowers') { return 'İzole Yağmurlu';       }

			if (translatedesc=='scattered thunderstorms') { return 'Dağınık Gök Gürültülü';    }

			if (translatedesc=='scattered showers') { return 'Dağınık Yağmurlu';  }

			if (translatedesc=='scattered snow showers') { return 'Dağınık Kar Yağışlı';	}

			if (translatedesc=='light rain with thunder') { return 'Hafif Yağmurlu Gök Gürültülü';	  }

			if (translatedesc=='not available') { return 'Veri Yok';    }

			if (translatedesc=='drifting snow/windy') { return 'Karlı Savurgan Rüzgar';  }

			if (translatedesc=='light rain shower') { return 'Hafif Sağanak Yağmurlu';     }

			if (translatedesc=='thunder') { return 'Gök Gürültülü'; }

			if (translatedesc=='mostly cloudy/windy') { return 'Çok Bulutlu Rüzgarlı'; }

			if (translatedesc=='sandstorm') { return 'Kum Fırtınası'; }

			if (translatedesc=='squalls/windy') { return 'Uğultulu Rüzgar'; }

			if (translatedesc=='sand') { return 'Kum'; }

			if (translatedesc=='sandstorm/windy') { return 'Kumlu Rüzgar'; }
	break;
		case "cn":

			if (translatedesc=='mist') { return '雾';}
			if (translatedesc=='cloudy/windy') { return '阴天和大风'; }
			if (translatedesc=='sunny') { return '阳光明媚'; }
			if (translatedesc=='drizzle') { return '蒙蒙细雨'; }
			if (translatedesc=='heavy snow') { return '大雪纷飞'; }
			if (translatedesc=='heavy rain') { return '倾盆大雨'; }
			if (translatedesc=='rain and snow') { return '雨雪霏霏'; }
			if (translatedesc=='mixed rain and snow') { return '雨雪霏霏'; }
			if (translatedesc=='fair') { return '天朗气清';	  }
			if (translatedesc=='mostly sunny') { return '风和日丽';	       }
			if (translatedesc=='partly sunny') { return '日丽风清';	 }
			if (translatedesc=='intermittent clouds') { return '云淡风清';	}
			if (translatedesc=='hazy sunshine') { return '日暖生烟';	    }
			if (translatedesc=='haze') { return '十面霾伏'; }
			if (translatedesc=='mostly cloudy') { return '浮云蔽日';   }
			if (translatedesc=='cloudy') { return '乌云蔽日';	 }
			if (translatedesc=='fog') { return '云迷雾锁';	    }
			if (translatedesc=='showers') { return '疾风骤雨';	  }
			if (translatedesc=='partly sunny with showers') { return '晴空骤雨';    }
			if (translatedesc=='thunderstorms') { return '电闪雷鸣';	}
			if (translatedesc=='thunderstorm') { return '雷雨交加'; }
			if (translatedesc=='mostly cloudy with thunder showers') { return '风潇雨晦';	 }
			if (translatedesc=='partly cloudy with thunder showers') { return '风雨如晦';	}
			if (translatedesc=='light rain') { return '和风细雨';	    }
			if (translatedesc=='rain') { return '细雨霖铃'; }
			if (translatedesc=='flurries') { return '流风回雪';  }
			if (translatedesc=='mostly cloudy with flurries') { return '云雪成欢';	}
			if (translatedesc=='partly sunny with flurries') { return '晴雪初飞';	}
			if (translatedesc=='snow flurries') { return '俄而雪骤';	}
			if (translatedesc=='snow showers') { return '雨雪霏霏';	  }
			if (translatedesc=='snow') { return '大雪纷飞'; }
			if (translatedesc=='mostly cloudy with snow') { return '闲云弄雪';	  }
			if (translatedesc=='ice') { return '冰天雪地'; }
			if (translatedesc=='sleet') { return '雨雪霏霏';	}
			if (translatedesc=='freezing rain') { return '凄风冷雨';	  }
			if (translatedesc=='rain and snow mixed') { return '雨雪霏霏';	 }
			if (translatedesc=='hot') { return '骄阳似火'; }
			if (translatedesc=='cold') { return '天寒地冻'; }
			if (translatedesc=='windy') { return '风和日丽';	}
			if (translatedesc=='clear') { return '晴空万里'; }
			if (translatedesc=='mostly clear') { return '风清云净';	   }
			if (translatedesc=='partly cloudy') { return '云淡风轻';	}
			if (translatedesc=='hazy') { return '烟雾缭绕'; }
			if (translatedesc=='partly cloudy with showers') { return '雨霁云消';	    }
			if (translatedesc=='mostly cloudy with showers') { return '断雨残云';	}
			if (translatedesc=='party cloudy with thunder showers') { return '雷雨交加';   }
			if (translatedesc=='foggy') { return '大雾迷茫';	}
			if (translatedesc=='light snow') { return '流风回雪'; }
			if (translatedesc=='light snow showers') { return '流风回雪'; }	       
			if (translatedesc=='rain shower') { return '大雨滂沱';	 }
			if (translatedesc=='light drizzle') { return '和风细雨';	}
			if (translatedesc=='mixed rain and sleet') { return '雨雪霏霏';	  }
			if (translatedesc=='mixed snow and sleet') { return '雨雪纷纷';	  }
			if (translatedesc=='severe thunderstorms') { return '电闪雷鸣';	  }
			if (translatedesc=='hurricane') { return '狂风暴雨';    }
			if (translatedesc=='tropical storm') { return '热带风暴';	 }
			if (translatedesc=='tornado') { return '风卷残云';	  }
			if (translatedesc=='freezing drizzle') { return '寒风冷雨';    }
			if (translatedesc=='blowing snow') { return '狂风暴雪'; }
			if (translatedesc=='hail') { return '天降冰雹'; }
			if (translatedesc=='dust') { return '飞沙走石';	  }
			if (translatedesc=='smoky') { return '烟雾弥漫';	}
			if (translatedesc=='blustery') { return '风起云涌';    }
			if (translatedesc=='mixed rain and hail') { return '冰雹带雨';	 }
			if (translatedesc=='isolated thunderstorms') { return '霹雳列缺';	 }
			if (translatedesc=='isolated thundershowers') { return '霹雳列缺';	  }
			if (translatedesc=='scattered thunderstorms') { return '电闪雷鸣';	  }
			if (translatedesc=='scattered showers') { return '急风骤雨';    }
			if (translatedesc=='scattered snow showers') { return '骤雪初歇';	 }
			if (translatedesc=='light rain with thunder') { return '雷雨交加';	  }
			if (translatedesc=='not available') { return '自行判断';	}
			if (translatedesc=='drifting snow/windy') { return '西门吹雪';	 }
			if (translatedesc=='light rain shower') { return '骤雨初歇'; }
			if (translatedesc=='thunder') { return '雷电交加'; }
			if (translatedesc=='mostly cloudy/windy') { return '风卷残云'; }
			if (translatedesc=='sandstorm') { return '飞沙走砾'; }
			if (translatedesc=='squalls/windy') { return '狂风肆虐'; }
			if (translatedesc=='sand') { return '尘土飞扬'; }
			if (translatedesc=='sandstorm/windy') { return '飞沙走石'; }
			if (translatedesc=='squalls') { return '狂风肆虐'; }
		break;	   
     
		case "ru":
			if (translatedesc=='sunny') { return 'Солнечно'; }
			if (translatedesc=='mist') { return 'Туман'; }
			if (translatedesc=='cloudy/windy') { return 'облачно и ветрено'; }
			if (translatedesc=='drizzle') { return 'Изморось'; }
			if (translatedesc=='heavy snow') { return 'Сильный снег'; }
			if (translatedesc=='heavy rain') { return 'Сильный дождь'; }
			if (translatedesc=='rain and snow') { return 'Дождь со снегом'; }
			if (translatedesc=='mixed rain and snow') { return 'Дождь со снегом'; }
			if (translatedesc=='fair') { return 'Ясно';    }
			if (translatedesc=='mostly sunny') { return 'Небольшая облачность';	  }
			if (translatedesc=='partly sunny') { return 'Переменная облачность';   }
			if (translatedesc=='intermittent clouds') { return 'Прерывистая облачность';	 }
			if (translatedesc=='hazy sunshine') { return 'Солнце и туман';	}
			if (translatedesc=='haze') { return 'Туман'; }
			if (translatedesc=='mostly cloudy') { return 'Небольшая облачность';	 }
			if (translatedesc=='cloudy') { return 'Облачно';    }
			if (translatedesc=='fog') { return 'Туман';	  }
			if (translatedesc=='showers') { return 'Дождь'; }
			if (translatedesc=='partly sunny with showers') { return 'Солнце и дождь';    }
			if (translatedesc=='thunderstorms') { return 'Бури';	}
			if (translatedesc=='thunderstorm') { return 'Буря';    }
			if (translatedesc=='mostly cloudy with thunder showers') { return 'Облачно дождь с громом';	  }
			if (translatedesc=='partly sunny with thunder showers') { return 'Солнце дождь с громом';    }
			if (translatedesc=='light rain') { return 'Небольшой дождь';	  }
			if (translatedesc=='rain') { return 'Дождь';	}
			if (translatedesc=='flurries') { return 'Порывы';	}
			if (translatedesc=='mostly cloudy with flurries') { return 'Облачно с порывами';   }
			if (translatedesc=='partly sunny with flurries') { return 'Солнце и порывы';	}
			if (translatedesc=='snow flurries') { return 'Снег с порывами';    }
			if (translatedesc=='snow showers') { return 'Дождь со снегом';	  }
			if (translatedesc=='snow') { return 'Снег';    }
			if (translatedesc=='mostly cloudy with snow') { return 'Облачно со снегом';    }
			if (translatedesc=='ice') { return 'Лед';	}
			if (translatedesc=='sleet') { return 'Дождь со снегом';    }
			if (translatedesc=='freezing rain') { return 'Ледяной дождь';	 }
			if (translatedesc=='rain and snow mixed') { return 'Дождь и снег';	}
			if (translatedesc=='hot') { return 'Горячий';	  }
			if (translatedesc=='cold') { return 'Холодный';   }
			if (translatedesc=='windy') { return 'Ветер';	 }
			if (translatedesc=='clear') { return 'Ясно';	}
			if (translatedesc=='mostly clear') { return 'Ясно';	}
			if (translatedesc=='partly cloudy') { return 'Переменная облачность';	 }
			if (translatedesc=='hazy') { return 'Туман';	}
			if (translatedesc=='partly cloudy with showers') { return 'Облачно с дождем';	}
			if (translatedesc=='mostly cloudy with showers') { return 'Солнечно с дождем';	  }
			if (translatedesc=='party cloudy with thunder showers') { return 'Облачно с грозой';	 }
			if (translatedesc=='foggy') { return 'Туман';	 }
			if (translatedesc=='light snow') { return 'Небольшой снег'; }
			if (translatedesc=='light snow showers') { return 'Небольшой снег с дождем'; }	     
			if (translatedesc=='rain shower') { return 'Ливень';	}
			if (translatedesc=='drizzle') { return 'Мелкий дождь';	  }
			if (translatedesc=='mixed rain and sleet') { return 'Дождь и мокрый снег';    }
			if (translatedesc=='mixed snow and sleet') { return 'Снег и мокрый снег';    }
			if (translatedesc=='severe thunderstorms') { return 'Гроза';	 }
			if (translatedesc=='hurricane') { return 'Ураган';	  }
			if (translatedesc=='tropical storm') { return 'Горячая буря';	 }
			if (translatedesc=='tornado') { return 'Торнадо';	}
			if (translatedesc=='freezing drizzle') { return 'Изморозь';	  }
			if (translatedesc=='blowing snow') { return 'Снежные заряды'; }
			if (translatedesc=='hail') { return 'Град'; }
			if (translatedesc=='dust') { return 'Пыль';	}
			if (translatedesc=='smoky') { return 'Туман';	 }
			if (translatedesc=='blustery') { return 'Бурный';    }
			if (translatedesc=='mixed rain and hail') { return 'Дождь и град';    }
			if (translatedesc=='isolated thunderstorms') { return 'Изолированные грозы';	}
			if (translatedesc=='isolated thundershowers') { return 'Изолированные грозы с дождем';	  }
			if (translatedesc=='scattered thunderstorms') { return 'Рассеянные грозы';    }
			if (translatedesc=='scattered showers') { return 'Рассеянный дождь';	 }
			if (translatedesc=='scattered snow showers') { return 'Рассеянный снег с дождем';    }
			if (translatedesc=='light rain with thunder') { return 'Небольшой дождь с грозой';    }
			if (translatedesc=='not available') { return 'Недоступно';    }
			if (translatedesc=='drifting snow/windy') { return 'Снег/Ветер';    }
			if (translatedesc=='light rain shower') { return 'Слабый дождь';	  }
			if (translatedesc=='thunder') { return 'Гром'; }
			if (translatedesc=='mostly cloudy/windy') { return 'Переменная облачность/Ветер'; }
			if (translatedesc=='sandstorm') { return 'Песчанная буря'; }
			if (translatedesc=='squalls/windy') { return 'Всплеск/Ветер'; }
			if (translatedesc=='sand') { return 'Песок'; }
			if (translatedesc=='sandstorm/windy') { return 'Песочная буря/Ветер'; }
		break;
								  
		case "it":
			if (translatedesc=='cloudy/windy') { return 'nuvoloso e ventoso'; }
			if (translatedesc=='mist') { return 'nebbia'; }
			if (translatedesc=='sunny') { return 'Soleggiato'; }
			if (translatedesc=='drizzle') { return 'Pioggerella'; }
			if (translatedesc=='heavy snow') { return 'Forti nevicate'; }
			if (translatedesc=='heavy rain') { return 'Forti piogge'; }
			if (translatedesc=='rain and snow') { return 'Vevischio'; }
			if (translatedesc=='mixed rain and snow') { return 'Misto pioggia e neve'; }
			if (translatedesc=='fair') { return 'Sereno';	 }
			if (translatedesc=='mostly sunny') { return 'Molto soleggiato';   }
			if (translatedesc=='partly sunny') { return 'Parzialmente soleggiato';	 }
			if (translatedesc=='intermittent clouds') { return 'Nuvoloso a tratti';  }
			if (translatedesc=='hazy sunshine') { return 'Sole coperto';	}
			if (translatedesc=='haze') { return 'Nebbia'; }
			if (translatedesc=='mostly cloudy') { return 'Molto nuvoloso';	 }
			if (translatedesc=='cloudy') { return 'Nuvoloso';    }
			if (translatedesc=='fog') { return 'Nebbia';	  }
			if (translatedesc=='showers') { return 'Diluvio';	}
			if (translatedesc=='partly sunny with showers') { return 'Soleggiato con pioggia';    }
			if (translatedesc=='thunderstorms') { return 'Fulmini';    }
			if (translatedesc=='thunderstorm') { return 'Tuoni';	}
			if (translatedesc=='mostly cloudy with thunder showers') { return 'Molto Nuvoloso con pioggia e fulmini';	  }
			if (translatedesc=='partly sunny with thunder showers') { return 'Possibili Piogge';	}
			if (translatedesc=='light rain') { return 'Pioggia leggera';	  }
			if (translatedesc=='rain') { return 'Pioggia';	  }
			if (translatedesc=='flurries') { return 'Nevischio';	}
			if (translatedesc=='mostly cloudy with flurries') { return 'Nuvoloso con nevischio';   }
			if (translatedesc=='partly sunny with flurries') { return 'Parzialmente soleggiato con neve';	 }
			if (translatedesc=='snow flurries') { return 'Raffiche di neve';    }
			if (translatedesc=='snow showers') { return 'Precipitazioni nevose';	}
			if (translatedesc=='snow') { return 'Neve';    }
			if (translatedesc=='mostly cloudy with snow') { return 'Molto nuvoloso con neve';    }
			if (translatedesc=='ice') { return 'Ghiaccio';	}
			if (translatedesc=='sleet') { return 'Nevischio';    }
			if (translatedesc=='freezing rain') { return 'Grandine';	 }
			if (translatedesc=='rain and snow mixed') { return 'Pioggia e neve';	}
			if (translatedesc=='hot') { return 'Caldo';	  }
			if (translatedesc=='cold') { return 'Freddo';	}
			if (translatedesc=='windy') { return 'Ventoso';    }
			if (translatedesc=='clear') { return 'Sereno';	  }
			if (translatedesc=='mostly clear') { return 'Molto sereno';	}
			if (translatedesc=='partly cloudy') { return 'Parzialmente nuvoloso';	 }
			if (translatedesc=='hazy') { return 'Velato';	 }
			if (translatedesc=='partly cloudy with showers') { return 'Cielo velato';	}
			if (translatedesc=='mostly cloudy with showers') { return 'Nuvoloso a tratti';	  }
			if (translatedesc=='party cloudy with thunder showers') { return 'Parzialmente nuvoloso con raffiche';	 }
			if (translatedesc=='foggy') { return 'Nebbiolina';	 }
			if (translatedesc=='light snow') { return 'Neve leggiera'; }
			if (translatedesc=='light snow showers') { return 'Poca neve'; }       
			if (translatedesc=='rain shower') { return 'Forti precipitazioni';    }
			if (translatedesc=='drizzle') { return 'Freddino';    }
			if (translatedesc=='mixed rain and sleet') { return 'Misto pioggia e nevischio';    }
			if (translatedesc=='mixed snow and sleet') { return 'Misto neve e nevischio';	 }
			if (translatedesc=='severe thunderstorms') { return 'Tuoni e fulmini';	 }
			if (translatedesc=='hurricane') { return 'Uragano';	  }
			if (translatedesc=='tropical storm') { return 'Tempesta tropicale';    }
			if (translatedesc=='tornado') { return 'Tornado';	}
			if (translatedesc=='freezing drizzle') { return 'Grandine';	  }
			if (translatedesc=='blowing snow') { return 'Vento e neve'; }
			if (translatedesc=='hail') { return 'Grandine'; }
			if (translatedesc=='dust') { return 'Polvere';	}
			if (translatedesc=='smoky') { return 'Humeado';    }
			if (translatedesc=='blustery') { return 'Tempesa';    }
			if (translatedesc=='mixed rain and hail') { return 'misto neve e grandine';    }
			if (translatedesc=='isolated thunderstorms') { return 'Fulmini isolati';    }
			if (translatedesc=='isolated thundershowers') { return 'Temporali isolati';    }
			if (translatedesc=='scattered thunderstorms') { return 'Tempesta di fulmini';	 }
			if (translatedesc=='scattered showers') { return 'Tempesta di pioggia';  }
			if (translatedesc=='scattered snow showers') { return 'Neve sparsa';	}
			if (translatedesc=='light rain with thunder') { return 'Pioggia leggera con fulmini';	 }
			if (translatedesc=='not available') { return 'No disponible';	 }
			if (translatedesc=='drifting snow/windy') { return 'Troppa neve';    }
			if (translatedesc=='light rain shower') { return 'Piccole precipitazioni';	  }
			if (translatedesc=='thunder') { return 'Tuoni'; }
			if (translatedesc=='mostly cloudy/windy') { return 'Molto nuvoloso con vento'; }
			if (translatedesc=='sandstorm') { return 'Tormenta'; }
			if (translatedesc=='squalls/windy') { return 'Pioggia e vento'; }
			if (translatedesc=='sand') { return 'Arena'; }
			if (translatedesc=='sandstorm/windy') { return 'Tormenta ventosa'; }
		break;
		case "fi":

			if (translatedesc=='mist') { return 'Sumu'; }
			if (translatedesc=='cloudy/windy') { return 'pilvinen ja tuulinen'; }
			if (translatedesc=='sunny') { return 'Aurinkoista'; }

			if (translatedesc=='drizzle') { return 'Tihkusadetta'; }

			if (translatedesc=='heavy snow') { return 'Rankkaa lumisadetta'; }

			if (translatedesc=='heavy rain') { return 'Rankkasade'; }

			if (translatedesc=='rain and snow') { return 'R&auml;nt&auml;&auml;'; }

			if (translatedesc=='mixed rain and snow') { return 'Vesisadetta ja r&auml;nt&auml;&auml;'; }

			if (translatedesc=='fair') { return 'Selke&auml;&auml;';    }

			if (translatedesc=='mostly sunny') { return 'Melko selke&auml;&auml;';	  }

			if (translatedesc=='partly sunny') { return 'Puolipilvist&auml;';	  }

			if (translatedesc=='intermittent clouds') { return 'Ajoittaisia pilvi&auml;';	 }

			if (translatedesc=='hazy sunshine') { return 'Utuista auringonpaistetta';	}

			if (translatedesc=='haze') { return 'Utuista';	}

			if (translatedesc=='mostly cloudy') { return 'Enimm&auml;kseen pilvist&auml;';	 }

			if (translatedesc=='cloudy') { return 'Pilvist&auml;';	  }

			if (translatedesc=='fog') { return 'Sumua';	  }

			if (translatedesc=='showers') { return 'Sadekuuroja';	}

			if (translatedesc=='partly sunny with showers') { return 'Puolipilvist&auml; ja sadekuuroja';	 }

			if (translatedesc=='thunderstorms') { return 'Ukkosmyrskyj&auml;';    }

			if (translatedesc=='thunderstorm') { return 'Ukkosta';	  }

			if (translatedesc=='mostly cloudy with thunder showers') { return 'Ukkoskuuroja';	  }

			if (translatedesc=='partly sunny with thunder showers') { return 'Ukkoskuuroja';    }

			if (translatedesc=='light rain') { return 'Tihkusadetta';	  }

			if (translatedesc=='rain') { return 'Sadetta';	  }

			if (translatedesc=='flurries') { return 'Lumisadetta';	}

			if (translatedesc=='mostly cloudy with flurries') { return 'Pilvist&auml; ja lumisadetta';	  }

			if (translatedesc=='partly sunny with flurries') { return 'Aurinkoista ja lumisadetta';    }

			if (translatedesc=='snow flurries') { return 'Lumisadetta';    }

			if (translatedesc=='snow showers') { return 'Lumikuuroja';    }

			if (translatedesc=='snow') { return 'Lumisadetta';    }

			if (translatedesc=='mostly cloudy with snow') { return 'Melko pilvist&auml; ja lumisadetta';	}

			if (translatedesc=='ice') { return 'Rakeita';	}

			if (translatedesc=='sleet') { return 'R&auml;nt&auml;&auml;';	 }

			if (translatedesc=='freezing rain') { return 'J&auml;&auml;t&auml;v&auml;&auml; sadetta';	 }

			if (translatedesc=='rain and snow mixed') { return 'Vesi ja lumisadetta';	}

			if (translatedesc=='hot') { return 'Hellett&auml;';	  }

			if (translatedesc=='cold') { return 'kylm&auml;&auml;';   }

			if (translatedesc=='windy') { return 'Tuulista';    }

			if (translatedesc=='clear') { return 'Selke&auml;&auml;';    }

			if (translatedesc=='mostly clear') { return 'Enimm&auml;kseen selke&auml;&auml;';	}

			if (translatedesc=='partly cloudy') { return 'Puolipilvist&auml;';	 }

			if (translatedesc=='hazy') { return 'Utuista';	  }

			if (translatedesc=='partly cloudy with showers') { return 'Osittaisia sadekuuroja';	}

			if (translatedesc=='mostly cloudy with showers') { return 'Pilvistä ja sadekuuroja';	  }

			if (translatedesc=='party cloudy with thunder showers') { return 'Puolipilvist&auml; ja ukkoskuuroja';	 }

			if (translatedesc=='foggy') { return 'Sumuista';    }

			if (translatedesc=='light snow') { return 'Heikkoa lumisadetta'; }

			if (translatedesc=='light snow showers') { return 'Heikkoja lumikuuroja'; }	

			if (translatedesc=='light snow shower') { return 'Heikkoja lumikuuroja'; }

			if (translatedesc=='rain shower') { return 'Sadekuuroja';    }

			if (translatedesc=='light drizzle') { return 'Osittaista tihkusadetta';    }

			if (translatedesc=='mixed rain and sleet') { return 'Vesi ja r&auml;nt&auml;sadetta';	 }

			if (translatedesc=='mixed snow and sleet') { return 'Lumi ja r&auml;nt&auml;sadetta';	 }

			if (translatedesc=='severe thunderstorms') { return 'Rankkoja ukkoskuuroja';	}

			if (translatedesc=='hurricane') { return 'Py&ouml;rremyrsky';	 }

			if (translatedesc=='tropical storm') { return 'Trooppinen myrsky';    }

			if (translatedesc=='tornado') { return 'Tornaado';    }

			if (translatedesc=='freezing drizzle') { return 'J&auml;&auml;t&auml;v&auml;&auml; tihkusadetta';    }

			if (translatedesc=='blowing snow') { return 'Lumituisku'; }

			if (translatedesc=='hail') { return 'Rakeita'; }

			if (translatedesc=='dust') { return 'P&ouml;lyist&auml;';    }

			if (translatedesc=='smoky') { return 'Utuista';    }

			if (translatedesc=='blustery') { return 'Ei tietoja';	 }

			if (translatedesc=='mixed rain and hail') { return 'Vesisadetta ja raekuuroja';    }

			if (translatedesc=='isolated thunderstorms') { return 'Paikallisia ukkoskuuroja';    }

			if (translatedesc=='isolated thundershowers') { return 'Paikallisia ukkoskuuroja';    }

			if (translatedesc=='scattered thunderstorms') { return 'Hajanaisia ukkoskuuroja';    }

			if (translatedesc=='scattered showers') { return 'Hajanaisia sadekuuroja';    }

			if (translatedesc=='scattered snow showers') { return 'Hajanaisia lumikuuroja';    }

			if (translatedesc=='light rain with thunder') { return 'Kevyit&auml; ukkoskuuroja';    }

			if (translatedesc=='not available') { return 'Ei tietoja';    }

			if (translatedesc=='showers in the vicinity') { return 'Sadetta l&auml;hell&auml;'; }

			if (translatedesc=='drifting snow/windy') { return 'Lumipyry&auml;';	}

			if (translatedesc=='light rain shower') { return 'Kevyiyt&auml; sadekuuroja'; }

			if (translatedesc=='thunder') { return 'Ukkosta'; }

			if (translatedesc=='mostly cloudy/windy') { return 'Enimm&auml;kseen tuulista'; }

			if (translatedesc=='sandstorm') { return 'Hiekkamyrsky'; }

			if (translatedesc=='squalls/windy') { return 'Puuskaista tuulta'; }

			if (translatedesc=='sand') { return 'Kuivaa tuulta'; }

			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTM= 'Tuulista'; }

			if (translatedesc=='squalls') { return 'Puuskaista tuulta'; }

		break;
		case "nl":
			if (translatedesc=='cloudy/windy') { return 'bewolkt en winderig'; }
			if (translatedesc=='mist') { return 'Mist'; }
			if (translatedesc=='light snow') { return 'Lichte Sneeuwval'; }
			if (translatedesc=='tornado') { return 'Tornado!'; }
			if (translatedesc=='tropical storm') { return 'Tropische Storm'; }
			if (translatedesc=='hurricane') { return 'Wervelwind'; }
			if (translatedesc=='severe thunderstorms') { return 'Zware Onweersbuien'; }
			if (translatedesc=='thunderstorms') { return 'Onweersbuien'; }
			if (translatedesc=='mixed rain and snow') { return 'Regen en Sneeuw'; }
			if (translatedesc=='mixed rain and sleet') { return 'Regen en Ijzel'; }
			if (translatedesc=='mixed snow and sleet') { return 'Sneeuw en Ijzel'; }
			if (translatedesc=='freezing drizzle') { return 'Bevriezende Motregen'; }
			if (translatedesc=='drizzle') { return 'Motregen'; }
			if (translatedesc=='freezing rain') { return 'Ijzel'; }
			if (translatedesc=='showers') { return 'Buien'; }
			if (translatedesc=='snow flurries') { return 'Sneeuwvlagen'; }
			if (translatedesc=='light snow showers') { return 'Lichte Sneeuwbuien'; }
			if (translatedesc=='light snow grains') { return 'Lichte Sneeuwbuien'; }
			if (translatedesc=='blowing snow') { return 'Sneeuw Drift'; }
			if (translatedesc=='snow') { return 'Sneeuw'; }
			if (translatedesc=='hail') { return 'Hagel'; }
			if (translatedesc=='sleet') { return 'Ijzel'; }
			if (translatedesc=='dust') { return 'Stoffig'; }
			if (translatedesc=='foggy') { return 'Mistig'; }
			if (translatedesc=='haze') { return 'Wazig'; }
			if (translatedesc=='smoky') { return 'Wazig'; }
			if (translatedesc=='blustery') { return 'Stormachtig'; }
			if (translatedesc=='windy') { return 'Winderig'; }
			if (translatedesc=='cold') { return 'Koud'; }
			if (translatedesc=='cloudy') { return 'Bewolkt'; }
			if (translatedesc=='mostly cloudy') { return 'Algemeen Bewolkt'; }
			if (translatedesc=='partly cloudy') { return 'Gedeeltelijk Bewolkt'; }
			if (translatedesc=='clear') { return 'Helder'; }
			if (translatedesc=='sunny') { return 'Zonnig'; }
			if (translatedesc=='fair') { return 'Bewolkt Weer'; }
			if (translatedesc=='mixed rain and hail') { return 'Regen en Hagel'; }
			if (translatedesc=='hot') { return 'Heet'; }
			if (translatedesc=='isolated thunderstorms') { return 'Geisoleerde Onweersbuien'; }
			if (translatedesc=='scattered thunderstorms') { return 'Verspreide Onweersbuien'; }
			if (translatedesc=='scattered showers') { return 'Verspreide Buien'; }
			if (translatedesc=='heavy snow') { return 'Zware Sneeuw'; }
			if (translatedesc=='scattered snow showers') { return 'Verspreide Sneeuwbuien'; }
			if (translatedesc=='partly cloudy') { return 'Gedeeltelijk Bewolkt'; }
			if (translatedesc=='thundershowers') { return 'Onweersbuien'; }
			if (translatedesc=='snow showers') { return 'Sneeuwbuien'; }
			if (translatedesc=='isolated thundershowers') { return 'Geisoleerde Onweersbuien'; }
			if (translatedesc=='light rain shower') { return 'Lichte Regenbuien'; }
			if (translatedesc=='not available') { return 'niet beschikbaar'; }
			if (translatedesc=='showers in the vicinity') { return 'Lokale Regenbuien'; }
			if (translatedesc=='partly sunny') { return 'Gedeeltelijk Zonnig'; }
			if (translatedesc=='ground fog') { return 'Grondmist'; }
			if (translatedesc=='light drizzle') { return 'Lichte Motregen'; }
			if (translatedesc=='light rain') { return 'Lichte Regen'; }
			if (translatedesc=='mist') { return 'Mist'; }
			if (translatedesc=='fog') { return 'Mist'; }
			if (translatedesc=='rain') { return 'Regen'; }
			if (translatedesc=='rain shower') { return 'Regenbui'; }
			if (translatedesc=='severe thunderstorm/windy') { return 'Zware Onweersbui/Winderig'; }
		break;
		case "fr":
			if (translatedesc=='cloudy/windy') { return 'nuageux et venteux'; }
			if (translatedesc=='mist') { return 'Brouillard'; }
			if (translatedesc=='sunny') { return 'Ensoleill&eacute;'; }
			if (translatedesc=='drizzle') { return 'Bruine'; }
			if (translatedesc=='heavy snow') { return 'Fortes chutes de neige'; }
			if (translatedesc=='heavy rain') { return 'Fortes averses'; }
			if (translatedesc=='rain and snow') { return 'Pluie et neige'; }
			if (translatedesc=='mixed rain and snow') { return 'Pluie et neige m&eacute;l&eacute;es'; }
			if (translatedesc=='fair') { return 'Ciel d&eacute;gag&eacute;';    }
			if (translatedesc=='mostly sunny') { return 'Tr&egrave;s ensoleill&eacute;';	  }
			if (translatedesc=='partly sunny') { return 'Partiellement nuageux';	  }
			if (translatedesc=='intermittent clouds') { return 'Nuages ​​Intermittents';	 }
			if (translatedesc=='hazy sunshine') { return 'L&eacute;g&egrave;rement voil&eacute;';	}
			if (translatedesc=='Hazy Moonlight') { return 'Légèrement voilé';	}
			if (translatedesc=='Dreary (Overcast)') { return 'Couvert';	}
			if (translatedesc=='haze') { return 'Brume';	}
			if (translatedesc=='mostly cloudy') { return 'Très Nuageux';	 }
			if (translatedesc=='cloudy') { return 'Nuageux';    }
			if (translatedesc=='fog') { return 'Brouillard';	  }
			if (translatedesc=='showers') { return 'Averses';	}
			if (translatedesc=='partly sunny with showers') { return 'Soleil et averses';	 }
			if (translatedesc=='Partly Sunny w/Showers') { return 'Soleil et averses';    }
			if (translatedesc=='thunderstorms') { return 'Orages';	  }
			if (translatedesc=='T-storms') { return 'Orages';    }
			if (translatedesc=='thunderstorm') { return 'Orage';	}
			if (translatedesc=='mostly cloudy with thunder showers') { return 'Tr&egrave;s nuageux et fortes averses';	  }
			if (translatedesc=='Mostly Cloudy w/T-Storms') { return 'Nuages et Orages';	  }
			if (translatedesc=='partly sunny with thunder showers') { return 'Soleil et fortes averses';	}
			if (translatedesc=='Partly Sunny w/ T-Storms') { return 'Eclaircies et Orages';    }
			if (translatedesc=='light rain') { return 'L&eacute;g&egrave;re pluie';   }
			if (translatedesc=='rain') { return 'Pluie';	}
			if (translatedesc=='flurries') { return 'Flocons';	}
			if (translatedesc=='mostly cloudy with flurries') { return 'Nuages et Flocons';   }
			if (translatedesc=='partly sunny with flurries') { return 'Eclaircies et Flocons';    }
			if (translatedesc=='snow flurries') { return 'Averses de neige';    }
			if (translatedesc=='snow showers') { return 'Averses de neige';    }
			if (translatedesc=='snow') { return 'Neige';	}
			if (translatedesc=='mostly cloudy with snow') { return 'Tr&egrave;s nuageux et neige';	  }
			if (translatedesc=='ice') { return 'Très froid';	}
			if (translatedesc=='sleet') { return 'Neige fondue';	}
			if (translatedesc=='freezing rain') { return 'Pluie vergla&ccedil;ante';	 }
			if (translatedesc=='rain and snow mixed') { return 'Pluie et neige m&eacute;l&eacute;es';	}
			if (translatedesc=='Rain & Snow') { return 'Pluie et Neige';	}
			if (translatedesc=='Hot') { return 'Chaud';	  }
			if (translatedesc=='Cold') { return 'Froid';	  }
			if (translatedesc=='windy') { return 'Venteux';    }
			if (translatedesc=='clear') { return 'Clair';	 }
			if (translatedesc=='mostly clear') { return 'Passages nuageux'; }
			if (translatedesc=='partly cloudy') { return 'Partiellement Nuageux';	 }
			if (translatedesc=='hazy') { return 'Brume';	}
			if (translatedesc=='partly cloudy with showers') { return 'Partiellement nuageux et averses';	}
			if (translatedesc=='mostly cloudy with showers') { return 'Nuages et Averses';	  }
			if (translatedesc=='Mostly Cloudy w/Showers') { return 'Tr&egrave;s nuageux et averses';	  }
			if (translatedesc=='Mostly Cloudy w/Snow') { return 'Nuages et Neige';	  }
			if (translatedesc=='party cloudy with thunder showers') { return 'Partiellement nuageux et fortes averses';	 }
			if (translatedesc=='Partly Cloudy w/ T-Storms') { return 'Eclaircies et Orages';	 }
			if (translatedesc=='Partly Cloudy w/ Showers') { return 'Averses éparses';	 }
			if (translatedesc=='foggy') { return 'Brouillard';    }
			if (translatedesc=='light snow') { return 'Flocons de neige'; }
			if (translatedesc=='light snow showers') { return 'L&eacute;g&egrave;res chutes de neige'; }		
			if (translatedesc=='rain shower') { return 'Averses';	 }
			if (translatedesc=='light drizzle') { return 'L&eacute;g&egrave;re bruine';    }
			if (translatedesc=='mixed rain and sleet') { return 'Pluie et verglas';    }
			if (translatedesc=='mixed snow and sleet') { return 'Neige et verglas';    }
			if (translatedesc=='severe thunderstorms') { return 'Gros orages';    }
			if (translatedesc=='hurricane') { return 'Ouragan';    }
			if (translatedesc=='tropical storm') { return 'Orage tropical';    }
			if (translatedesc=='tornado') { return 'Tornade';    }
			if (translatedesc=='freezing drizzle') { return 'Bruine vergla&ccedil;ante';	}
			if (translatedesc=='blowing snow') { return 'Rafales de neige'; }
			if (translatedesc=='hail') { return 'Gr&ecirc;le'; }
			if (translatedesc=='dust') { return 'Poussi&eacute;reux';    }
			if (translatedesc=='smoky') { return 'Brumeux';    }
			if (translatedesc=='blustery') { return 'Temp&ecirc;te';    }
			if (translatedesc=='mixed rain and hail') { return 'Pluie et Gr&ecirc;le m&eacute;l&eacute;es';    }
			if (translatedesc=='isolated thunderstorms') { return 'Orages isol&eacute;s';	 }
			if (translatedesc=='isolated thundershowers') { return 'Averses isol&eacute;s';    }
			if (translatedesc=='scattered thunderstorms') { return 'Orages &eacute;parses';    }
			if (translatedesc=='scattered showers') { return 'Averses &eacute;parses';    }
			if (translatedesc=='scattered snow showers') { return 'Chutes de neige &eacute;parses';    }
			if (translatedesc=='light rain with thunder') { return 'Pluie l&eacute;g&egrave;re et &eacute;clairs';	  }
			if (translatedesc=='not available') { return 'Non disponible';	  }
			if (translatedesc=='drifting snow/windy') { return 'Neige poudreuse et vent';	 }
			if (translatedesc=='light rain shower') { return 'L&eacute;g&egrave;re averse'; }
			if (translatedesc=='thunder') { return 'Tonnerre'; }
			if (translatedesc=='mostly cloudy/windy') { return 'Tr&egrave;s nuageux et vent'; }
			if (translatedesc=='sandstorm') { return 'Temp&ecirc;te de sable'; }
			if (translatedesc=='squalls/windy') { return 'Rafales de vent'; }
			if (translatedesc=='sand') { return 'Sable'; }
			if (translatedesc=='sandstorm/windy') { return 'Temp&ecirc;te de sable et vent'; }
			if (translatedesc=='squalls') { return 'Rafales'; }
			if (translatedesc=='am clouds/pm sun') { return "Nuageux le matin/Ensoleill&eacute; l'apr&egrave;s midi"; }
			if (translatedesc=='am sun/pm clouds') { return "Ensoleill&eacute; le matin/Nuageux l'apr&egrave;s midi"; }
			if (translatedesc=='showers in the vicinity') { return "Averses &eacute;parses"; }
		break;
		case "ge":
		if (translatedesc=='cloudy/windy') { return 'bewölkt u. windig'; }
			if (translatedesc=='sunny') { return 'Sonnig'; }
			if (translatedesc=='drizzle') { return 'Nieselregen'; }
			if (translatedesc=='heavy snow') { return 'Starker Schneefall'; }	
			if (translatedesc=='heavy rain') { return 'Starker Regenschauer'; }	
			if (translatedesc=='rain and snow') { return 'Regen und Schnee'; }
			if (translatedesc=='mixed rain and snow') { return 'Regen und Schnee'; }
			if (translatedesc=='fair') { return 'Heiter'; }
			if (translatedesc=='mostly sunny') { return 'Meist Sonnig';	  }
			if (translatedesc=='partly sunny') { return 'Teilweise Sonnig';   }
			if (translatedesc=='intermittent clouds') { return 'Wechselnd Bew&ouml;lkt';	 }
			if (translatedesc=='hazy sunshine') { return 'Dunstiger Sonnenschein;'; }
			if (translatedesc=='haze') { return 'Dunstschleier'; }
			if (translatedesc=='mostly cloudy') { return 'Meist Bew&ouml;lkt'; }
			if (translatedesc=='cloudy') { return 'Bew&ouml;lkt'; }
			if (translatedesc=='fog') { return 'Nebel'; }
			if (translatedesc=='showers') { return 'Schauer'; }
			if (translatedesc=='partly sunny with showers') { return 'Sonnig mit Regenschauern';	}
			if (translatedesc=='thunderstorms') { return 'Gewitter'; }
			if (translatedesc=='thunderstorm') { return 'Gewitter'; }
			if (translatedesc=='mostly cloudy with thunder showers') { return 'Bew&ouml;lkt mit Gewitterschauern';	  }
			if (translatedesc=='partly sunny with thunder showers') { return 'Wechselnd bew&ouml;lkt mit Gewitterschauer';	  }
			if (translatedesc=='light rain') { return 'Leichter Regen'; }
			if (translatedesc=='rain') { return 'Regen'; }
			if (translatedesc=='flurries') { return 'Windst%F6%DFe';	}
			if (translatedesc=='mostly cloudy with flurries') { return 'Bew&ouml;lkt mit Windst%F6%DFe';	  }
			if (translatedesc=='partly sunny with flurries') { return 'Teilweise Sonnig mit Windst%F6%DFe';    }
			if (translatedesc=='snow flurries') { return 'Schneegest&ouml;ber'; }
			if (translatedesc=='snow showers') { return 'Scheeschauer'; }
			if (translatedesc=='snow') { return 'Schnee'; }
			if (translatedesc=='mostly cloudy with snow') { return 'Bew&ouml;lkt mit Schneeschauern';    }
			if (translatedesc=='ice') { return 'Gl%E4tte';	}
			if (translatedesc=='sleet') { return 'Schneeregen'; }
			if (translatedesc=='freezing rain') { return 'Gefrierender Regen'; }
			if (translatedesc=='rain and snow mixed') { return 'Schneeregen';	}
			if (translatedesc=='hot') { return 'Heiss'; }
			if (translatedesc=='cold') { return 'Kalt'; }
			if (translatedesc=='windy') { return 'Windig'; }
			if (translatedesc=='clear') { return 'Klar'; }
			if (translatedesc=='mostly clear') { return 'Meist Klar';	}
			if (translatedesc=='partly cloudy') { return 'Teilweise Bew&ouml;lkt';	 }
			if (translatedesc=='hazy') { return 'Nebelig';	  }
			if (translatedesc=='partly cloudy with showers') { return 'Teilweise Bew&ouml;lkt mit Regen';	}
			if (translatedesc=='mostly cloudy with showers') { return 'Stark Bew&ouml;lkt mit Regen';	  }
			if (translatedesc=='partly cloudy with thunder showers') { return 'Teilweise Bew&ouml;lkt mit Gewitter';	 }
			if (translatedesc=='foggy') { return 'Nebelig'; }
			if (translatedesc=='light snow') { return 'Leichter Schneefall'; }
			if (translatedesc=='light snow showers') { return 'Leichte Schneeschauer'; }
			if (translatedesc=='rain shower') { return 'Regenschauer'; }
			if (translatedesc=='light drizzle') { return 'Leichter Nieselregen'; }
			if (translatedesc=='mixed rain and sleet') { return 'Graupelschauer'; }
			if (translatedesc=='mixed snow and sleet') { return 'Schneeregen'; }
			if (translatedesc=='severe thunderstorms') { return 'Schwere Gewitter'; }
			if (translatedesc=='hurricane') { return 'Wirbelsturm'; }
			if (translatedesc=='tropical storm') { return 'Tropischer Sturm'; }
			if (translatedesc=='tornado') { return 'Tornado!'; }
			if (translatedesc=='freezing drizzle') { return 'Gefrierender Nieselregen'; }
			if (translatedesc=='blowing snow') { return 'Schneetreiben'; }
			if (translatedesc=='hail') { return 'Hagel'; }
			if (translatedesc=='dust') { return 'Staubig'; }
			if (translatedesc=='smoky') { return 'Dunstig'; }
			if (translatedesc=='blustery') { return 'St&uuml;rmisch'; }
			if (translatedesc=='mixed rain and hail') { return 'Regen und Hagel'; }
			if (translatedesc=='isolated thunderstorms') { return '&Ouml;rtliche Gewitter'; }
			if (translatedesc=='scattered thunderstorms') { return 'Vereinzelte Gewitter'; }
			if (translatedesc=='scattered showers') { return 'Vereinzelte Schauer'; }
			if (translatedesc=='scattered snow showers') { return 'Vereinzelte Schneeschauer'; }
			if (translatedesc=='light rain with thunder') { return 'Vereinzelte Regenschauer mit Gewitter';    }
			if (translatedesc=='not available') { return 'nicht verfuegbar'; }
			if (translatedesc=='drifting snow/windy') { return 'Heftiges Schneegest%F6ber';    }
			if (translatedesc=='light rain shower') { return 'Leichte Regenschauer'; }
			if (translatedesc=='thunder') { return 'Donner'; }
			if (translatedesc=='mostly cloudy/windy') { return 'Stark Bew&ouml;lkt und Windig'; }
			if (translatedesc=='sandstorm') { return 'Sandsturm'; }
			if (translatedesc=='squalls/windy') { return 'St&uuml;rmisch'; }
			if (translatedesc=='sand') { return 'Staubig'; }
			if (translatedesc=='sandstorm/windy') { return 'Sandsturm'; }
			if (translatedesc=='squalls') { return 'Sturmb%F6en'; }
			if (translatedesc=='light snow grains') { return 'Leichte Schneeschauer'; }
			if (translatedesc=='thundershowers') { return 'Gewitter'; }
			if (translatedesc=='isolated thundershowers') { return 'Ouml;rtliche Gewitterschauer'; }
			if (translatedesc=='showers in the vicinity') { return 'Schauer'; }
			if (translatedesc=='partly sunny') { return 'Teilweise Sonnig'; }
			if (translatedesc=='ground fog') { return 'Bodennebel'; }
			if (translatedesc=='mist') { return 'Nebel'; }
			if (translatedesc=='severe thunderstorm/windy') { return 'Schwere Gewitter/Windig'; }
		break;
		case "sp":
			if (translatedesc=='cloudy/windy') { return 'nublado y ventoso'; }
			if (translatedesc=='mist') { return 'Niebla'; }
			if (translatedesc=='sunny') { return 'Soleado'; }
			if (translatedesc=='drizzle') { return 'Llovizna'; }
			if (translatedesc=='heavy snow') { return 'Nieve fuerte'; }
			if (translatedesc=='heavy rain') { return 'Luvia fuerte'; }
			if (translatedesc=='rain and snow') { return 'Lluvia y nieve'; }
			if (translatedesc=='mixed rain and snow') { return 'Mezcla de lluvia y nieve'; }
			if (translatedesc=='fair') { return 'Despejado';    }
			if (translatedesc=='mostly sunny') { return 'Mayormente soleado';	  }
			if (translatedesc=='partly sunny') { return 'Parcialmente soleado';   }
			if (translatedesc=='intermittent clouds') { return 'Intermitente nublado';	 }
			if (translatedesc=='hazy sunshine') { return 'Sol brumoso';	}
			if (translatedesc=='haze') { return 'Bruma'; }
			if (translatedesc=='mostly cloudy') { return 'Mayormente nublado';	 }
			if (translatedesc=='cloudy') { return 'Nublado';    }
			if (translatedesc=='fog') { return 'Niebla';	  }
			if (translatedesc=='showers') { return 'Chubascos';	}
			if (translatedesc=='partly sunny with showers') { return 'Parcialmente soleado con chubascos';	  }
			if (translatedesc=='thunderstorms') { return 'Tormentas electricas';	}
			if (translatedesc=='thunderstorm') { return 'Tormenta electrica';    }
			if (translatedesc=='mostly cloudy with thunder showers') { return 'Mayormente nublado con tormentas de chubascos';	  }
			if (translatedesc=='partly sunny with thunder showers') { return 'Parcialmente soleado con tormentas de chubascos';    }
			if (translatedesc=='light rain') { return 'Lluvia ligera';	  }
			if (translatedesc=='rain') { return 'Lluvia';	 }
			if (translatedesc=='flurries') { return 'Rafagas';	}
			if (translatedesc=='mostly cloudy with flurries') { return 'Mayormente nublado con rafagas';   }
			if (translatedesc=='partly sunny with flurries') { return 'Parcialmente soleado con rafagas';	 }
			if (translatedesc=='snow flurries') { return 'Rafagas de nieve';    }
			if (translatedesc=='snow showers') { return 'Precipitaciones de nieve';    }
			if (translatedesc=='snow') { return 'Nieve';	}
			if (translatedesc=='mostly cloudy with snow') { return 'Mayormente nublado con nieve';	  }
			if (translatedesc=='ice') { return 'Hielo';	}
			if (translatedesc=='sleet') { return 'Aguanieve';    }
			if (translatedesc=='freezing rain') { return 'Lluvia bajo cero';	 }
			if (translatedesc=='rain and snow mixed') { return 'Mezcla de lluvia y nieve';	}
			if (translatedesc=='hot') { return 'Caluroso';	  }
			if (translatedesc=='cold') { return 'Frio';   }
			if (translatedesc=='windy') { return 'Vientoso';    }
			if (translatedesc=='clear') { return 'Despejado';    }
			if (translatedesc=='mostly clear') { return 'Mayormente despejado';	}
			if (translatedesc=='partly cloudy') { return 'Parcialmente despejado';	 }
			if (translatedesc=='hazy') { return 'Bruma';	}
			if (translatedesc=='partly cloudy with showers') { return 'Parcialmente nublado con chubascos'; }
			if (translatedesc=='mostly cloudy with showers') { return 'Mayormente nublado con chubascos';	  }
			if (translatedesc=='party cloudy with thunder showers') { return 'Parcialmente nublado con tormentas de chubascos';	 }
			if (translatedesc=='foggy') { return 'Neblina';  }
			if (translatedesc=='light snow') { return 'Nieve ligera'; }
			if (translatedesc=='light snow showers') { return 'Ligeras precipitaciones de nieve'; }       
			if (translatedesc=='rain shower') { return 'Precipitaciones de lluvia';    }
			if (translatedesc=='drizzle') { return 'Bruma';    }
			if (translatedesc=='mixed rain and sleet') { return 'Mezcla de lluvia y aguanieve';    }
			if (translatedesc=='mixed snow and sleet') { return 'Mezcla de nieve y aguanieve';    }
			if (translatedesc=='severe thunderstorms') { return 'Tormentas electricas severas';	 }
			if (translatedesc=='hurricane') { return 'Huracan';	  }
			if (translatedesc=='tropical storm') { return 'Tormenta tropical';    }
			if (translatedesc=='tornado') { return 'Tornado';	}
			if (translatedesc=='freezing drizzle') { return 'Llovizna helada';	  }
			if (translatedesc=='blowing snow') { return 'Viento y nieve'; }
			if (translatedesc=='hail') { return 'Granizo'; }
			if (translatedesc=='dust') { return 'Polvareda';	}
			if (translatedesc=='smoky') { return 'Humeado';    }
			if (translatedesc=='blustery') { return 'Tempestuoso';	  }
			if (translatedesc=='mixed rain and hail') { return 'Mezcla de lluvia y granizo';    }
			if (translatedesc=='isolated thunderstorms') { return 'Tormentas electricas aisladas';	  }
			if (translatedesc=='isolated thundershowers') { return 'Tormentas aisladas';	}
			if (translatedesc=='scattered thunderstorms') { return 'Tormentas electricas dispersas';    }
			if (translatedesc=='scattered showers') { return 'Chubascos dispersos';  }
			if (translatedesc=='scattered snow showers') { return 'Precipitaciones de nieve dispersas';    }
			if (translatedesc=='light rain with thunder') { return 'LLuvia y tormenta ligera';    }
			if (translatedesc=='not available') { return 'No disponible';	 }
			if (translatedesc=='drifting snow/windy') { return 'Acumulacion de nieve y viento';    }
			if (translatedesc=='light rain shower') { return 'Precipitaciones de lluvia ligera';	  }
			if (translatedesc=='thunder') { return 'Truenos'; }
			if (translatedesc=='mostly cloudy/windy') { return 'Mayormente nublado y ventoso'; }
			if (translatedesc=='sandstorm') { return 'Tormentas de arena'; }
			if (translatedesc=='squalls/windy') { return 'Chubascos y viento'; }
			if (translatedesc=='sand') { return 'Arena'; }
			if (translatedesc=='sandstorm/windy') { return 'Tormentas de arena y ventoso'; }
		break;
		default: 
			return desc;
		break;
	}
}

function ForecastDayNames(day) {
switch (day) {
    case "Sun": { return days[0]; }
    case "Mon": { return days[1]; }
    case "Tue": { return days[2]; }
    case "Wed": { return days[3]; }
    case "Thu": { return days[4]; }
    case "Fri": { return days[5]; }
    case "Sat": { return days[6]; }
    case "Today": { return "Today"; }
    case "Tonight": { return "Tonight"; }
	}
}


function TranslateAccu(icon, desc) {
switch (lang) {
	case "fr":
		switch(icon) {
		case 1: { return "Ensoleillé"; }
		case 2: { return "Dégagé"; }
		case 3: { return "Partiellement Nuageux"; }
		case 4: { return "Nuages Intermittents"; }
		case 5: { return "Légèrement voilé"; }
		case 6: { return "Très Nuageux"; }
		case 7: { return "Nuageux"; }
		case 8: { return "Couvert"; }
		case 9: { return "N/A"; }
		case 10: { return "N/A"; }
		case 11: { return "Brouillard"; }
		case 12: { return "Averses"; }
		case 13: { return "Nuages et Averses"; }
		case 14: { return "Eclaircies et Averses"; }
		case 15: { return "Orages"; }
		case 16: { return "Nuages et Orages"; }
		case 17: { return "Eclaircies et Orages"; }
		case 18: { return "Pluie"; }
		case 19: { return "Flocons"; }
		case 20: { return "Nuages et Flocons"; }
		case 21: { return "Eclaircies et Flocons"; }
		case 22: { return "Neige"; }
		case 23: { return "Nuages et Neige"; }
		case 24: { return "Très froid"; }
		case 25: { return "Neige fondue"; }
		case 26: { return "Pluie verglaçante"; }
		case 27: { return "N/A"; }
		case 28: { return "N/A"; }
		case 29: { return "Pluie et Neige"; }
		case 30: { return "Chaud"; }
		case 31: { return "Froid"; }
		case 32: { return "Venteux"; }
		case 33: { return "Clair"; }
		case 34: { return "Passages nuageux"; }
		case 35: { return "Partiellement Nuageux"; }
		case 36: { return "Nuages Intermittents"; }
		case 37: { return "Légèrement voilé"; }
		case 38: { return "Très Nuageux"; }
		case 39: { return "Averses éparses"; }
		case 40: { return "Nuages et Averses"; }
		case 41: { return "Eclaircies et Orages"; }
		case 42: { return "Très Nuageux et Orages"; }
		case 43: { return "Très nuageux et Flocons"; }
		case 44: { return "Très nuageux et Neige"; }
		}
	break;
	
	case "ge":
		switch(icon) {
		case 1: { return "Sonnig"; }
		case 2: { return "Meist Sonnig"; }
		case 3: { return "Teilweise Sonnig"; }
		case 4: { return "Wechselnd Bewölkt"; }
		case 5: { return "Sonnig mit Nebel"; }
		case 6: { return "Meist Bewölkt"; }
		case 7: { return "Bewölkt"; }
		case 8: { return "trübe"; }
		case 9: { return "N/A"; }
		case 10: { return "N/A"; }
		case 11: { return "Nebel"; }
		case 12: { return "Schauer"; }
		case 13: { return "Meist Bewölkt mit Regenschauern"; }
		case 14: { return "Teilweise Sonnig mit Regenschauern"; }
		case 15: { return "Gewitter"; }
		case 16: { return "Meist Bewölkt mit Gewittern"; }
		case 17: { return "Teilweise Sonnig mit Gewittern"; }
		case 18: { return "Regen"; }
		case 19: { return "Windstöße"; }
		case 20: { return "Meist Bewölkt mit Windstößen"; }
		case 21: { return "Teilweise Sonnig mit Windstößen"; }
		case 22: { return "Schnee"; }
		case 23: { return "Meist Bewölkt mit Schneefall"; }
		case 24: { return "gefrierend"; }
		case 25: { return "Schneeregen"; }
		case 26: { return "gefrierender Regen"; }
		case 27: { return "N/A"; }
		case 28: { return "N/A"; }
		case 29: { return "Regen und Schnee"; }
		case 30: { return "Heiss"; }
		case 31: { return "Kalt"; }
		case 32: { return "Windig"; }
		case 33: { return "Klar"; }
		case 34: { return "Überwiegend Klar"; }
		case 35: { return "Teilweise Bewölkt"; }
		case 36: { return "vereinzelt Bewölkt"; }
		case 37: { return "trüber Mondschein"; }
		case 38: { return "Meist Bewölkt"; }
		case 39: { return "Teilweise Bewölkt mit Regenschauern"; }
		case 40: { return "Meist Bewölkt mit Regenschauern"; }
		case 41: { return "Teilweise Bewölkt mit Gewittern"; }
		case 42: { return "Meist Bewölkt mit Gewittern"; }
		case 43: { return "Meist Bewölkt mit Windstößen"; }
		case 44: { return "Meist Bewölkt mit Schneefall"; }
		}
	break;
	default:
		return desc;
	break;	
	
	}
}









































