/*
.____                                   __
|    |   _____    ____    ____         |__| ______
|    |   \__  \  /    \  / ___\        |  |/  ___/
|    |___ / __ \|   |  \/ /_/  >       |  |\___ \
|_______ (____  /___|  /\___  / /\ /\__|  /____  >
        \/    \/     \//_____/  \/ \______|    \/

** Creator: JunesiPhone
** Website: http://junesiphone.com/libraries
** Languages for clocks and weather.

*/

"use strict";
var current = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'en',
    $$ = function (el) {
        return document.getElementById(el);
    },
    translate = {
        en: {
            weekday: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
            sday: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            month: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"],
            smonth: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],

            condition: ["Tornado", "Tropical St.", "Hurricane", "T.storm", "T.storm", "Snow", "Sleet", "Sleet", "F.Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "T.storms", "T.storms", "T.storms", "Showers", "HeavySnow", "LightSnow", "Heavy Snow", "Part.Cloudy", "T.storm", "Snow", "T.storm", "blank"]
        },
        nl: {
            weekday: ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"],
            sday: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"],
            month: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"],
            smonth: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],

            condition: ["Tornado", "Tropical St.", "Hurricane", "T.storm", "T.storm", "Snow", "Sleet", "Sleet", "F.Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "T.storms", "T.storms", "T.storms", "Showers", "HeavySnow", "LightSnow", "Heavy Snow", "Part.Cloudy", "T.storm", "Snow", "T.storm", "blank"]

        },
        ru: {
            weekday: ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"],
            sday: ["Вос", "Пон", "Вто", "Сре", "Чет", "Пят", "Суб"],
            month: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"],
            smonth: ["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"],

            condition: ["Tornado", "Tropical St.", "Hurricane", "T.storm", "T.storm", "Snow", "Sleet", "Sleet", "F.Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "T.storms", "T.storms", "T.storms", "Showers", "HeavySnow", "LightSnow", "Heavy Snow", "Part.Cloudy", "T.storm", "Snow", "T.storm", "blank"]

        },
        cz: {
            weekday: ["Neděle", "Pondělí", "Úterý", "Středa", "Čtvrtek", "Pátek", "Sobota"],
            sday: ["Ne", "Po", "Út", "St", "Čt", "Pá", "So"],
            month: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"],
            smonth: ["Led", "Úno", "Bře", "Dub", "Kvě", "Čen", "Čec", "Srp", "Zář", "Říj", "Lis", "Pro"],

            condition: ["Tornado", "Tropical St.", "Hurricane", "T.storm", "T.storm", "Snow", "Sleet", "Sleet", "F.Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "T.storms", "T.storms", "T.storms", "Showers", "HeavySnow", "LightSnow", "Heavy Snow", "Part.Cloudy", "T.storm", "Snow", "T.storm", "blank"]

        },
        it: {
            weekday: ['Domenica', 'Luned&#236', 'Marted&#236', 'Mercoled&#236', 'Gioved&#236', 'Venerd&#236', 'Sabato'],
            sday: ["Sun", "Mon", "Mar", "Mer", "Gio", "Ven", "Sat"],
            month: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"],
            smonth: ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"],

            condition: ["Tornado", "Tropical St.", "Hurricane", "T.storm", "T.storm", "Snow", "Sleet", "Sleet", "F.Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "T.storms", "T.storms", "T.storms", "Showers", "HeavySnow", "LightSnow", "Heavy Snow", "Part.Cloudy", "T.storm", "Snow", "T.storm", "blank"]

        },
        sp: {
            weekday: ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"],
            sday: ["Sol", "Mon", "Mar", "Mie", "Jue", "Vie", "Sat"],
            month: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"],
            smonth: ["Ene", "Feb", "Mar", "Abr", "Mayo", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dic"],

            condition: ["Tornado", "Tropical St.", "Hurricane", "T.storm", "T.storm", "Snow", "Sleet", "Sleet", "F.Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "T.storms", "T.storms", "T.storms", "Showers", "HeavySnow", "LightSnow", "Heavy Snow", "Part.Cloudy", "T.storm", "Snow", "T.storm", "blank"]

        },
        de: {
            weekday: ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"],
            sday: ["Son", "Mon", "Die", "Mit", "Don", "Fre", "Sam"],
            month: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"],
            smonth: ["Jan", "Feb", "Mä", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez "],

            condition: ["Tornado", "Tropical St.", "Hurricane", "T.storm", "T.storm", "Snow", "Sleet", "Sleet", "F.Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "T.storms", "T.storms", "T.storms", "Showers", "HeavySnow", "LightSnow", "Heavy Snow", "Part.Cloudy", "T.storm", "Snow", "T.storm", "blank"]

        },
        fr: {
            weekday: ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"],
            sday: ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"],
            month: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"],
            smonth: ["Jan", "Fév", "Mar", "Avr", "Mai", "Jui", "Jui", "Aoû", "Sep", "Oct", "Nov", "Déc"],

            condition: ["Tornado", "Tropical St.", "Hurricane", "T.storm", "T.storm", "Snow", "Sleet", "Sleet", "F.Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "T.storms", "T.storms", "T.storms", "Showers", "HeavySnow", "LightSnow", "Heavy Snow", "Part.Cloudy", "T.storm", "Snow", "T.storm", "blank"]

        },
        zh: {
            weekday: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
            sday: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'],
            month: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
            smonth: ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '十一', '十二'],
            condition: ["龙卷风", "热带风暴", "飓风", "雷暴", "雷暴", "雪", "雨雪", "雨雪", "冻毛毛雨", "细雨", "冻雨", "淋浴", "淋浴", "飘雪", "雪", "雪", "雪", "Hail", "雨雪", "尘", "牙齿", "阴霾", "烟", "风起云涌", "有风", "冷", "多云", "多云", "多云", "多云", "多云", "明确", "晴朗", "公平", "公平", "雨雪", "Hot", "雷暴", "雷暴", "雷暴", "淋浴", "大雪", "小雪", "大雪", "半 多云", "雷暴", "雪", "雷暴", "空白"]
        },
        he: {
            weekday: ["שבת", "שישי", "חמיש", "רביעי", "שלישי", "שני", "ראשון"],
            sday: ["ז’", "ו’", "ה", "ד’", "ג’", "ב’", "א’"],
            month: ["ינואר", "פברואר", "מרץ", "אפריל", "מאי", "יוני", "יולי", "אוגוסט", "ספטמבר", "אוקטובר", "נובמבר", "דצמבר"],
            smonth: ["ינו", "פבר", "מרץ", "אפריל", "מאי", "יוני", "יולי", "אוג", "ספט", "אוקט", "נוב", "דצמ"],
            condition: ["טורנדו", "סופה טרופית", "הוריקן", "סופת-רעמים", "סופת-רעמים", "שלג", "ברד קל", "ברד קל", "ברד", "טפטוף", "טפטוף", "מקלחת", "מקלחת", "משב רוח", "שלג", "שלג", "שלג", "ברד", "ברד קל", "Dust", "ערפל", "אובך", "אובך", "סוער", "סוער", "קר", "מעונן", "מעונן", "מעונן", "מעונן", "מעונן", "בהיר", "שמשי", "נאה", "נאה", "ברד קל", "חם", "סופת-רעמים", "סופת-רעמים", "סופת-רעמים", "מקלחת", "שלג כבד", "שלג קל", "שלג כבד", "מעונן חלקית", "סופת-רעמים", "שלג", "סופת-רעמים", "ריק"]
        },
        pl: {
            weekday: ["Niedziela", "Poniedzialek", "Wtorek", "Sroda", "Czwartek", "Piatek", "Sobota"],
            sday: ["Nie", "Pon", "Wto", "Sro", "Czw", "Pia", "Sob"],
            month: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"],
            smonth: ["Sty", "Lut", "Mar", "Kwi", "Maj", "Cze", "Lip", "Sie", "Wrz", "Paz", "Lis", "Gru"],

            condition: ["Tornado", "Tropical St.", "Hurricane", "T.storm", "T.storm", "Snow", "Sleet", "Sleet", "F.Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "T.storms", "T.storms", "T.storms", "Showers", "HeavySnow", "LightSnow", "Heavy Snow", "Part.Cloudy", "T.storm", "Snow", "T.storm", "blank"]

        },
        pt: {
            weekday: ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"],
            sday: ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"],
            month: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"],
            smonth: ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"],

            condition: ["Tornado", "Tropical St.", "Hurricane", "T.storm", "T.storm", "Snow", "Sleet", "Sleet", "F.Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "T.storms", "T.storms", "T.storms", "Showers", "HeavySnow", "LightSnow", "Heavy Snow", "Part.Cloudy", "T.storm", "Snow", "T.storm", "blank"]

        }
    };
if (!translate[current]) {
    current = 'en';
}