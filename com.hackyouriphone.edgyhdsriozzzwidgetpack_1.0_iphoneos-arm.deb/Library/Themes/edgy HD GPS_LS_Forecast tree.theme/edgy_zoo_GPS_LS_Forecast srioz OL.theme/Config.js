// Configuration here ! //
// Made by Dacal for Durben
// For weather code, go to http://weather.yahoo.com/ and search for your city. The correct zip code is in the URL (only numbers)

var ampm = false; // Set to true for 12h format
var gps = true; // You NEED to install crazyvivek's "GPS Weather Lockscreen" for GPS localization
var locale = 9807; // Yahoo Weather (used if gps set to false or myLocation.txt file not found)
var tempUnit = "c"; // f for fahrenheit
var updateInterval = 15; // in minutes
var lang = "en"; // (fr) for french, (de) for german, (sp) for spanish, (it) for italian, (en) or anything else for english,(am) for us
var SecDisplay = false; // true to display seconds

/*
Interactive LockScreen Widget are incompatible with LockInfo !
In some case, forecast don't display even without LockInfo.
You can try to put the variable below to true, not perfect
(slower response on animation), but better than nothing !
*/
var ChangeClick = false; // True ONLY if you have problem to show forecast when touch the screen
