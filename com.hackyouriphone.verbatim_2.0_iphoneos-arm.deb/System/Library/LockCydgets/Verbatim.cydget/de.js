/*********************************************

TIPP für Fortgeschrittene:
--- Du kannst html tags verwenden
    um den Verbatim Text anzupassen.
    Nachfolgend ein Beispiel zur Anpassung des Textinhalts:

    MSG_SINGULAR_EMAIL = "<i>%</i> ungelesene e-mail"
        
        oder, zur Anpassung der Farbgestaltung:

     MSG_SINGULAR_EMAIL = "<font color='red'>%</font> ungelesene e-mail"

*********************************************/
var
ERROR_WORD = "Fehler!",
ERROR_INTERJECTION = "Oh, oh.",
WRONG_CITY_CODE = "Falscher Städtecode",
NO_CITY_CODE = "Kein Städtecode ausgewählt",
CONNECTION_PROBLEM = "Verbindungsproblem",
WELCOME_SP1 = "Willkommen bei Verbatim! Lass mich Dir bei den ersten Schritten behilflich sein!",
WELCOME_SP2 = "1.) Um Wetterdaten abrufen zu können, trage bitte Deinen Städtecode in den Einstellungen ein! ... 2.) Um mehr Platz zu erhalten, kannst Du die Statusbar verbergen. Alle dafür benötigten Informationen werden von mir zur Verfügung gestellt, und 3.) Gehe in die Einstellungen, um weitere Details zu den individuellen Anpassungsmöglichkeiten zu finden. Dort findest Du auch meine Kontaktdaten, über die Du mich bei Problemen und für Anregungen erreichen kannst.",
WELCOME_SP3 = "Genieße das Erlebnis dieser Klarheit!",
WELCOME_TXT0 = "Willkommen bei <b>Verbatim</b>!",
WELCOME_TXT1 = "<b>Bitte</b>! Hör mir zu.",
WELCOME_TXT2 = "Lege Deinen Städtecode fest <b>Einstellungen</b>",
WELCOME_TXT3 = "Die verfügbaren <b>Optionen</b> sind:",
WELCOME_TXT4 = "- Text <b>Animationen</b> wie diese",
WELCOME_TXT5 = "- <b>Verberge</b> Statusbar für mehr Platz",
WELCOME_TXT6 = "<b>Vorschlag</b>: Verberge Dinge vom Sperrbildschirm",
WELCOME_TXT7 = "wie z.B. den <b>Entsperren</b> Text,",
WELCOME_TXT8 = "oder <b>personalisiere</b> sie einfach",
MSG_SINGULAR_EMAIL = "<b>%</b> ungelesene e-mail",
MSG_PLURAL_EMAIL = "<b>%</b> ungelesene e-mails",
MSG_SINGULAR_APPS = "<b>%</b> zu aktualisierende App",
MSG_PLURAL_APPS = "<b>%</b> ausstehende Aktualisierungen",
MSG_SINGULAR_SMS = "<b>%</b> ungelesene Nachricht",
MSG_PLURAL_SMS = "<b>%</b> ungelesene Nachrichten",
MSG_SINGULAR_CALLS = "sowie, <b>%</b> verpasster Anruf",
MSG_PLURAL_CALLS = "sowie, <b>%</b> verpasste Anrufe",
MSG_BATTERY_ALMOST_FULL = " Akku <b>fast</b> vollständig geladen",
MSG_BATTERY_FULL_PLUGGED = " Akku <b>vollständig</b> geladen, vom Ladegerät trennen",
MSG_BATTERY_FULL = " Akku <b>vollständig</b> geladen",
MSG_BATTERY_CHARGING = " Akku bei <b>%</b> und lädt",
MSG_BATTERY_DRAINING = " Akku bei <b>%</b> und entlädt",

/* !, @, #: hour, minute, second */
TIME_TEXT = "Jetzt beträgt ! stunden und @ minuten",

/* Formatierung siehe http://en.wikipedia.org/wiki/ISO_8601 */
DATE_FORMAT = "EEEEdMMMM",


end_of_definitions = 'de'; 


WEATHER_CONDITION = [
"Tornado",
"Tropensturm",
"Hurrikan",
"Schweres Unwetter",
"Gewitter",
"Schneeregen",
"Graupelschauer",
"Graupelschauer",
"Gefrierender Nieselregen",
"Nieselregen",
"Gefrierender Regen",
"Regen",
"Regen",
"Schneetreiben",
"Leichter Schneefall",
"Schneegestöber",
"Schnee",
"Hagel",
"Graupel",
"dunstig",
"nebelig",
"trübe",
"diesig",
"stürmisch",
"windig",
"kalt",
"bewölkt",
"überwiegend bewölkt",
"überwiegend bewölkt",
"teilweise bewölkt",
"teilweise bewölkt",
"klar",
"sonnig",
"schön",
"schön",
"Regen mit Hagel",
"warm",
"vereinzelt Gewitter",
"vereinzelt Gewitter",
"vereinzelt Gewitter",
"vereinzelt Regen",
"heftiger Schneefall",
"vereinzelt Schneefall",
"starker Schneefall",
"teilweise bewölkt",
"Gewitterregen",
"Schneeschauer",
"vereinzelt Gewitterregen"];

WEATHER_CONDITION[3200] ="nicht verfügbar";
/*
	(Stern 		*	Wettersituation)
	(Prozent	%	Temperatur)
	(Raute		#	Stadtname)
*/
var
WEATHER_TXT = "<b>*</b> bei <b>%</b>",
WEATHER_ICON_LINE = " in <b>#</b>",
WEATHER_DEGREE = "grad";
