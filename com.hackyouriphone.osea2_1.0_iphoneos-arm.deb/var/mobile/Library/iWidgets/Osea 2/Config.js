var Scale = "1"; 
var Clock = "12h"; // choose between "12h" or "24h"
var Color = "dimgrey";
var TextColor = "khaki";
var HideDay = false;
var HideWeather = false;
var HideBattery = false;
