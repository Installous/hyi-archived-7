// UniAW6.4LS By Ian Nicoll and Dacal

var forecastdisplay = true;
var slideshow = false;
var optiondisplay = false;
var weatherdisplay = true;
var weatherBGdisplay = true;
var clockdisplay = true;
var timedwalls = false;
var disabletouch = false;
var windeffectdisplay = true;
var prev_wind_effects = wind_effects; // TO REVERT BACK...

if (ChangeClick == false) { var touchmode = "touchend"; } else { var touchmode = "click"; }

function StartTouch() {
document.getElementById("TouchLayer").addEventListener(touchmode, touchEnd, false); // FOR THE FORECAST
document.getElementById("TouchLayer2").addEventListener(touchmode, touchEnd2, false); // FOR THE OPTIONS
}

function touchEnd() {
	if (forecastdisplay == false) {
		document.getElementById('TouchForecast').className = "forecastMoveUp";
		forecastdisplay = true;
	} else {
		document.getElementById('TouchForecast').className = "forecastMoveDown";
		forecastdisplay = false;
	}
	if (updateTimer != 0) { createOptionsCookie(); }
}

function touchEnd2(event) {
	event.preventDefault();
	if (optiondisplay == false) {
		document.getElementById("optionContainer").style.zIndex= "1000";
		document.getElementById("optionContainer").className = "fade-in-option";
		StartButtons();
		optiondisplay = true;
	} else {
		document.getElementById("optionContainer").style.zIndex= "800";
		document.getElementById("optionContainer").className = "fade-out-option";
		StopButtons();
		optiondisplay = false;
	}
}

function StartButtons() {
	document.getElementById("refresh").addEventListener(touchmode, touchRefresh, false);
	document.getElementById("timedwall").addEventListener(touchmode, touchTimewall, false);
	document.getElementById("slideshow").addEventListener(touchmode, touchSlideShow, false);
	document.getElementById("hideweatherInfo").addEventListener(touchmode, touchHideWeather, false);
	document.getElementById("hideweatherBG").addEventListener(touchmode, touchHideWeatherBG, false);
	document.getElementById("hideclock").addEventListener(touchmode, touchHideClock, false);
	document.getElementById("disableforcasttouch").addEventListener(touchmode, touchDisableForecast, false);
	document.getElementById("windeffect").addEventListener(touchmode, touchWindeffect, false);
	document.getElementById("version").addEventListener(touchmode, touchchoose, false);
	document.getElementById("refresh").innerHTML = "Reload (for a fresh start)";
	document.getElementById("timedwall").innerHTML = "Launch Timed Walls";
	document.getElementById("slideshow").innerHTML = "Launch the Slideshow";
	document.getElementById("hideweatherInfo").innerHTML = "Hide all weather information";
	document.getElementById("hideweatherBG").innerHTML = "Hide all overlay";
	document.getElementById("hideclock").innerHTML = "Hide the clock";
	document.getElementById("disableforcasttouch").innerHTML = "Disable forecast touch";
	document.getElementById("windeffect").innerHTML = "Disable Wind Effect";
	if (useAccuweather == true) { document.getElementById("version").innerHTML = "Switch to Yahoo"; }
	else { document.getElementById("version").innerHTML = "Switch to Accuweather"; }
}

function StopButtons() {
	document.getElementById("refresh").removeEventListener(touchmode, touchRefresh, false);
	document.getElementById("timedwall").removeEventListener(touchmode, touchTimewall, false);
	document.getElementById("slideshow").removeEventListener(touchmode, touchSlideShow, false);
	document.getElementById("hideweatherInfo").removeEventListener(touchmode, touchHideWeather, false);
	document.getElementById("hideweatherBG").removeEventListener(touchmode, touchHideWeatherBG, false);
	document.getElementById("hideclock").removeEventListener(touchmode, touchHideClock, false);
	document.getElementById("disableforcasttouch").removeEventListener(touchmode, touchDisableForecast, false);
	document.getElementById("windeffect").removeEventListener(touchmode, touchWindeffect, false);
	document.getElementById("version").removeEventListener(touchmode, touchchoose, false);
}

function touchRefresh() {
	event.preventDefault();
	$.removeCookie('optionsCookie');
	window.location.reload();
}

function touchTimewall() {
    if (timedwalls == false) {
        if (slideshow == true) { touchSlideShow(); }
        timedwalls = true;
        Wallpaper_options = 'timedwalls';
		document.getElementById("backgroundContainer").className = "fade-out-wall";
        document.getElementById("timedwall").className = "TextColorGreen";
    } else {
        timedwalls = false;
        wpidx = "-1";
        WPfade_inTW.className='fade-out-wall';
        WPfade_outTW.className='fade-out-wall';
        document.getElementById("backgroundContainer").className = "fade-in-wall";
        document.getElementById("timedwall").className = "TextColorWhite";
    }
    if (optiondisplay == true) { createOptionsCookie(); } // SAVE THE CONFIGURATION
}

function touchSlideShow() {
	if (slideshow == false) {
		if (timedwalls == true) { touchTimewall(); } // STOP THE TIMED WALL
		widgetStart();
		slideshow = true;
		Wallpaper_options = 'slideshow';
		document.getElementById("slideshow").className = "TextColorGreen";
		if (filename != "") {
			DemoOn = false;
			clearInterval(meteorTimer);
			delelement("astronautContainer");
			delelement("fogContainer");
			delelement("starContainer");
			delelement("meteorContainer");
			delelement("frameContainer");
			delelement("cloudContainer");
			delelement("dropContainer");
			delelement("circleContainer");
			delelement("wiperContainer");
			delelement("starsBGContainer");
			delelement("windContainer");
			delelement("windmillContainer");
			delelement("big_balloonContainer");
			delelement("small_balloonContainer");
			delelement("birdsContainer");
            delelement("frostContainer");
			if (Show_wind_effects == true) {
					removejscssfile("Weather/"+iPhoneType, wind_effects+"_effects", "css");
					removejscssfile("Weather/"+iPhoneType, wind_effects+"_effects", "js");
					Show_wind_effects = false;					
			}
			if (Show_frost == true) {
					removejscssfile("Weather/" + iPhoneType, "frost_effect", "css");
					removejscssfile("Weather/" + iPhoneType, "frost_effect", "js");
					Show_frost = false;
			}	
			removejscssfile("Weather/"+iPhoneType, filename, "css");
			removejscssfile("Weather/"+iPhoneType, filename, "js");
		}
		document.getElementById("sun_moonContainer").className = "fade-out-wall";
		document.getElementById("backgroundContainer").className = "fade-out-wall";
	} else {
		widgetStop();
		slideshow = false;
		if (filename != "") {
			loadjscssfile ("Weather/"+iPhoneType, filename, "css");
			loadjscssfile ("Weather/"+iPhoneType, filename, "js");
			if (Start_wind_effects == true) {
				loadjscssfile ("Weather/"+iPhoneType, wind_effects+"_effects", "css");
				loadjscssfile ("Weather/"+iPhoneType,wind_effects+"_effects", "js");
				Show_wind_effects = true;
			}
			if (Start_frost == true) {
				loadjscssfile("Weather/" + iPhoneType, "frost_effect", "css");
				loadjscssfile("Weather/" + iPhoneType, "frost_effect", "js");
				Show_frost = true;
			}			
		} else {
			demo();
		}
		document.getElementById("sun_moonContainer").className = "fade-in-wall";
		document.getElementById("backgroundContainer").className = "fade-in-wall";
		document.getElementById("slideshow").className = "TextColorWhite";
	}
	if (optiondisplay == true) { createOptionsCookie(); } // SAVE THE CONFIGURATION
}

function touchHideWeather() {
	if (weatherdisplay == true) {
		document.getElementById("WeatherInfo").className = "fade-out-wall";
		document.getElementById("forecastInfo").className = "fade-out-wall";
		weatherdisplay = false;
		document.getElementById("hideweatherInfo").className = "TextColorGreen";
	} else {
		document.getElementById("WeatherInfo").className = "fade-in-wall";
		document.getElementById("forecastInfo").className = "fade-in-wall";
		weatherdisplay = true;		
		document.getElementById("hideweatherInfo").className = "TextColorWhite";
	}
	if (optiondisplay == true) { createOptionsCookie(); } // SAVE THE CONFIGURATION
}


function touchHideClock() {
    if (clockdisplay == true) {            
        document.getElementById("analogclock").style.display = 'none';
        document.getElementById("calendar").style.display = 'none';
        document.getElementById("Digitalclock").style.display = 'none';
        document.getElementById("SingleLineDate").style.display = 'none';
        clockdisplay = false;                      
        document.getElementById("hideclock").className = "TextColorGreen";
    } else {
        if (AnalogClock == true) { document.getElementById("analogclock").style.display = 'block'; }
        if (AnalogClock_Calendar == true) { document.getElementById("calendar").style.display = 'block'; }
        if (Single_Line_Date == true) { document.getElementById("SingleLineDate").style.display = 'block'; }
        if (DigitalClock == true) { document.getElementById("Digitalclock").style.display = 'block'; }
        clockdisplay = true;                       
        document.getElementById("hideclock").className = "TextColorWhite";
    }
    if (optiondisplay == true) { createOptionsCookie(); } // SAVE THE CONFIGURATION
}


function touchHideWeatherBG() {
	if (weatherBGdisplay == true) {
		document.getElementById("forecastbg").style.display = 'none';
		document.getElementById("WeatherInfoBG").style.display = 'none';
		weatherBGdisplay = false;			
		document.getElementById("hideweatherBG").className = "TextColorGreen";
	} else {
		document.getElementById("forecastbg").style.display = 'block';
		document.getElementById("WeatherInfoBG").style.display = 'block';
		weatherBGdisplay = true;		
		document.getElementById("hideweatherBG").className = "TextColorWhite";
	}
	if (optiondisplay == true) { createOptionsCookie(); } // SAVE THE CONFIGURATION
}

function touchDisableForecast() {
	if (disabletouch == true) {
		document.getElementById("TouchLayer").addEventListener(touchmode, touchEnd, false);
		disabletouch = false;		
		document.getElementById("disableforcasttouch").className = "TextColorWhite";
	} else {
		document.getElementById("TouchLayer").removeEventListener(touchmode, touchEnd, false);
		disabletouch = true;		
		document.getElementById("disableforcasttouch").className = "TextColorGreen";
	}
	if (optiondisplay == true) { createOptionsCookie(); } // SAVE THE CONFIGURATION
}

function touchWindeffect() {
	if (windeffectdisplay == true) {
		prev_wind_effects = wind_effects;
		wind_effects = "none";
		Start_wind_effects = false;
        windeffectdisplay = false;
		document.getElementById("windeffect").className = "TextColorGreen";
		if (Show_wind_effects == true) {
			delelement("windContainer");
			delelement("windmillContainer");
			removejscssfile("Weather/"+iPhoneType, wind_effects+"_effects", "css");
			removejscssfile("Weather/"+iPhoneType, wind_effects+"_effects", "js");
			Show_wind_effects = false;		
		}
	} else {
		wind_effects = prev_wind_effects;
		if ((filename != "") && (slideshow == false) && (Show_wind_effects == false)) {
			if ((Math.round(obj.windspeed) >= Strong_Wind) && (filename != "windy")  && (wind_effects != "none")) { Start_wind_effects = true; } else { Start_wind_effects = false; }			
			if (Start_wind_effects == true) {
				loadjscssfile ("Weather/"+iPhoneType, wind_effects+"_effects", "css");
				loadjscssfile ("Weather/"+iPhoneType, wind_effects+"_effects", "js");
				Show_wind_effects = true;
			}
		}
		windeffectdisplay = true;
		document.getElementById("windeffect").className = "TextColorWhite";
	}
	if (optiondisplay == true) { createOptionsCookie(); } // SAVE THE CONFIGURATION
}

function touchchoose() {
	if (useAccuweather == false) {
		useAccuweather = true;
	} else {
		useAccuweather = false;
	}
	createOptionsCookie(); // SAVE THE CONFIGURATION
	window.location.reload();
}

function createOptionsCookie() {
	var options = {};
	options.slideshow = slideshow;
	options.clockdisplay = clockdisplay;
	options.weatherdisplay = weatherdisplay;
	options.timedwalls = timedwalls;
	options.weatherBGdisplay = weatherBGdisplay;
	options.disabletouch = disabletouch;
	options.forecastdisplay = forecastdisplay;
	options.windeffectdisplay = windeffectdisplay;
	options.useAccuweather = useAccuweather;	
	var optionsTmp = JSON.stringify(options);
	$.cookie('optionsCookie', optionsTmp, {expires: 365});
}
