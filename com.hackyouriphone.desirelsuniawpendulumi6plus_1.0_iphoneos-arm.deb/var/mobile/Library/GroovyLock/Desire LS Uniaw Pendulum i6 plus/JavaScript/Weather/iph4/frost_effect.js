// Frost condition iph4
// UniAW6.4 By Ian Nicoll and Dacal

var container = document.getElementById("frostContainer");
container.appendChild(createACloud());

function createACloud() {
    var image = document.createElement("img");
    image.id = "frost";	
    image.src = "Images/Weather/frost/frost.png";
    return image;
}
