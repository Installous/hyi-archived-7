var InvertWidget = false; // Invert Widget
var FromBottom = "50"; // Position of Widget
var ShowWallpaper = true; // Show the Animated Wallpaper
var ShowWidget = true; // Show the Widget
var ShowAMPM = true; // Show AM/PM
var Use24Hour = true; // Use 24 Hour Time
var WidgetWidth = "60"; // Width of Widget in %
