// Configuration here ! //
// Made by Dacal for Durben
// For weather code, go to http://weather.yahoo.com/ and search for your city. The correct zip code is in the URL (only numbers)

var ampm = true; // Set to true for 12h format
var gps = false; // You NEED to install crazyvivek's "GPS Weather Lockscreen" for GPS localization


 // Yahoo Weather (used if gps set to false or myLocation.txt file not found)

var updateInterval = 15; // in minutes
var lang = "am"; // (fr) for french, (de) for german, (sp) for spanish, (it) for italian, (en) or anything else for english,(am) for us
var SecDisplay = false; // true to display seconds

