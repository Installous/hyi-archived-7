var MainColor = "Black";
var YourName = "Frank";
var TimeColor = "linear-gradient(to top, #606c88, #3f4c6b)";
var DarkIcon = true;
var ZoomLevel = 100;