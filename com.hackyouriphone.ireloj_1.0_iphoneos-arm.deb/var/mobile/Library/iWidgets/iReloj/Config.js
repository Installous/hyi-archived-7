var scle = 1.0; // choose the widget size from "0.1 to 3.0"
var Lang = "en"; // choose between "en", "sp", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh", "jp", "kr", "tr"
