//Translation for major components. Originally by Junesiphone, modified by Evelyn (@ev_ynw) and iLuCh0 (@luis9_49)//

if (Lang == "en") {
    var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = 
["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    var shortdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    var months=["January","February","March","April","May","June","July","August","September","October","November","December"];
    var shortmonths = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var battery = ["Battery", "Battery", "Battery", "Battery", "Battery", "Battery", "Battery", "Battery", "Battery", "Battery", "Battery", "Battery"];
    var hourtext = ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve"];
    var weatherdesc = ["Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank"];
} 
if (Lang == "cz") {
    var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
   var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = ["Neděle", "Pondělí", "Úterý", "Středa", "Čtvrtek", "Pátek", "Sobota"];
    var months = ["Leden", "Únor", "Březen", "Duben", "Květen", "Červen", "Červenec", "Srpen", "Září", "Říjen", "Listopad", "Prosinec"];
    var shortmonths = ["Led", "Úno", "Bře", "Dub", "Kvě", "Čen", "Čec", "Srp", "Zář", "Říj", "Lis", "Pro"];
    var shortdays = ["Ne", "Po", "Út", "St", "Čt", "Pá", "So"];
    var battery = ["Baterie", "Baterie", "Baterie", "Baterie", "Baterie", "Baterie", "Baterie", "Baterie", "Baterie", "Baterie", "Baterie", "Baterie"];
    var weatherdesc = ["Tornádo", "Tropická bouře", "Hurikán", "Bouře", "Bouře", "Sněžení", "Déšť a sníh", "Déšť a sníh", "Mrznoucí mrholení", "Mrholení", "Mrznoucí déšť", "Přeháňky", "Přeháňky", "Poryvy větru", "Sněžení", "Sněžení", "Sněžení", "Kroupy", "Déšť a sníh", "Prach", "Mlhy", "Řídké mlhy", "Kouř", "Větrno s bouřkami", "Větrno", "Chladno", "Oblačno", "Oblačno", "Oblačno", "Oblačno", "Oblačno", "Jasno", "Slunečno", "Krásně", "Krásně", "Déšť a sníh", "Horko", "Bouře", "Bouře", "Bouře", "Přeháňky", "Husté sněžení", "Lehké sněžení", "Husté sněžení", "Polojasno", "Bouře", "Sněžení", "Bouře", "prázdné"];
} 
if (Lang == "it") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
   var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = ["Domenica", "Lunedi", "Martedì", "Mercoledì", "Giovedi", "Venerdì", "Sabato"];
    var months = ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"];
    var shortmonths = ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"];
    var shortdays = ["Sun", "Mon", "Mar", "Mer", "Gio", "Ven", "Sat"];
    var battery = ["Batteria", "Batteria", "Batteria", "Batteria", "Batteria", "Batteria", "Batteria", "Batteria", "Batteria", "Batteria", "Batteria", "Batteria"];
    var weatherdesc = ["Tornado", "Tempesta Tropicale", "Uragano", "Temporali Forti", "Temporali", "Pioggia mista a Neve", "Nevischio", "Nevischio", "Pioggia Gelata", "Pioggerella", "Pioggia Ghiacciata", "Pioggia", "Pioggia", "Neve a Raffiche", "Neve Leggera", "Tempesta di Neve", "Neve", "Grandine", "Nevischio", "Irregolare", "Nebbia", "Foschia", "Fumoso", "Raffiche di Vento", "Ventoso", "Freddo", "Nuvoloso", "Molto Nuvoloso", "Molto Nuvoloso", "Nuvoloso", "Nuvoloso", "Sereno", "Sereno", "Bel Tempo", "Bel Tempo", "Pioggia e Grandine", "Caldo", "Temporali Isolati", "Temporali Sparsi", "Temporali Sparsi", "Rovesci Sparsi", "Neve Forte", "Nevicate Sparse", "Neve Forte", "Nuvoloso", "Rovesci Temporaleschi", "Rovesci di Neve", "Temporali isolati", "Non Disponibile"];
}
if (Lang == "sp") {
    var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var days = ["Domingo", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado"];
    var months = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
    var shortmonths = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
    var shortdays = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
    var battery = ["Batería", "Batería", "Batería", "Batería", "Batería", "Batería", "Batería", "Batería", "Batería", "Batería", "Batería", "Batería"];
    var hourtext = ["doce", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce"];
    var today = ["Ten una Buena", "Ten una Buena", "Ten una Buena", "Ten una Buena", "Ten una Buena", "Ten una Buena", "Ten una Buena", "Ten una Buena", "Ten una Buena", "Ten una Buena", "Ten una Buena", "Ten una Buena"];
    var today1 = ["Mañana!!", "Mañana!!", "Mañana!!", "Mañana!!", "Mañana!!", "Mañana!!", "Mañana!!", "Mañana!!", "Mañana!!", "Mañana!!", "Mañana!!", "Mañana!!", "Tarde!!", "Tarde!!", "Tarde!!", "Tarde!!", "Tarde!!", "Tarde!!", "Tarde!!", "Noche!!", "Noche!!", "Noche!!", "Noche!!", "Noche!!", "Noche!!"];
    var weatherdesc = ["Tornado", "Tormenta Tropical", "Huracan", "Tormentas Electricas Severas", "Tormentas Electricas", "Mezcla de Lluvia y Nieve", "Mezcla de lluvia y aguanieve", "Mezcla de nieve y aguaniev", "Llovizna helada", "Llovizna", "Lluvia bajo cero", "Chubascos", "Chubascos", "Rafagas de nieve", "Ligeras precipitaciones de nieve", "Viento y nieve", "Nieve", "Granizo", "Aguanieve", "Polvareda", "Neblina", "Bruma", "Humeado", "Tempestuoso", "Vientoso", "Frio", "Nublado", "Mayormente nublado", "Mayormente nublado", "despejado", "despejado", "Despejado", "Soleado", "Lindo", "Lindo", "Mezcla de lluvia y granizo", "Caluroso", "Tormentas electricas aisladas", "Tormentas electricas dispersas", "Tormentas electricas dispersas", "Chubascos dispersos", "Nieve fuerte", "Precipitaciones de nieve dispersas", "Nieve fuerte", "despejado", "Lluvia con truenos y relampagos", "Precipitaciones de nieve", "Tormentas aisladas", "No disponible"];
}
if (Lang == "de") {
    var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
   var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
    var months = ["Januar", "Februar", "MÃ¤rz", "April", "Mai", "Juni", "Ju li", "August", "September", "Oktober", "November", "Dez ember"];
    var shortmonths = ["Jan", "Feb", "MÃ¤", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez "];
    var shortdays = ["Son", "Mon", "Die", "Mit", "Don", "Fre", "Sam"];
    var battery = ["Batterie", "Batterie", "Batterie", "Batterie", "Batterie", "Batterie", "Batterie", "Batterie", "Batterie", "Batterie", "Batterie", "Batterie"];
    var hourtext = ["null", "ein", "zwei", "drei", "vier", "f¸nf", "sechs", "sieben", "acht", "neun", "zehn", "elf", "zwˆlf", "dreizehn", "vierzehn", "f¸nfzehn", "sechzehn", "siebzehn", "achtzehn", "neunzehn", "zwanzig", "einundzwanzig", "zweiundzwanzig", "dreiundzwanzig", "null"];
    var weatherdesc = ["Tornado", "Tropischer Sturm", "Wirbelsturm", "Schwere Gewitter", "Gewitter", "Regen und Schnee", "Graupelschauer", "Schneeregen", "Gefrierender Nieselregen", "Nieselregen", "Gefrierender Regen", "Schauer", "Schauer", "Schneegestöber", "Leichte Schneeschauer", "Schneetreiben", "Schnee", "Hagel", "Schneeregen", "Staubig", "Nebelig", "Dunstschleier", "Dunstig", "Stürmisch", "Windig", "Kalt", "Bewölkt", "Meist Bewölkt", "Meist Bewölkt", "Bewölkt", "Bewölkt", "Klar", "Sonnig", "Heiter", "Heiter", "Regen und Hagel", "Heiss", "Örtliche Gewitter", "Vereinzelte Gewitter", "Vereinzelte Gewitter", "Vereinzelte Schauer", "Starker Schneefall", "Vereinzelte Schneeschauer", "Starker Schneefall", "Bewölkt", "Gewitter", "Scheeschauer", "Örtliche Gewitterschauer", "Nicht Verfügbar"];
}
if (Lang == "fr") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
    var months = ["Janvie", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
    var shortmonths = ["Jan", "Fév", "Mar", "Avr", "Mai", "Jui", "Jui", "Aoû", "Sep", "Oct", "Nov", "Déc"];
    var shortdays = ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
    var battery = ["Batterie", "Batterie", "Batterie", "Batterie", "Batterie", "Batterie", "Batterie", "Batterie", "Batterie", "Batterie", "Batterie", "Batterie"];
    var hourtext = ["minuit", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "midi", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "minuit"];
    var weatherdesc = ["Tornade", "Tropical", "Ouragan", "Orages Violents", "Orages", "Pluie", "Pluie", "Neige", "Bruine", "Bruine", "Pluie", "Averses", "Averses", "Quelques Flocons", "Faibles Chutes de Neige", "Rafales de Neige", "Neige", "GrÃƒÂªle", "Neige Fondue", "PoussiÃƒÂ©reux", "Brouillard", "Brume", "Brumeux", "TempÃƒÂªte", "Vent", "Temps Froid", "Temps Nuageux ", "TrÃƒÂ¨s Nuageux", "TrÃƒÂ¨s Nuageux", "Nuageux", "Nuageux", "Temps Clair", "Ensoleille", "Beau Temps", "Beau Temps", "Pluie et GrÃƒÂªles", "Temps Chaud", "Orages IsolÃƒÂ©s", "Orages Eparses", "Orages Eparses", "Averses Eparses", "Fortes Chutes de Neige", "Chutes de Neige Eparses", "Fortes Chutes de Neige", "Nuageux", "Orages", "Chute de Neige", "Orages IsolÃƒÂ©s", "Non Disponible"];
}
if (Lang == "ru") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
   var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days =  ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"];
    var shortdays = ["Вос", "Пон", "Вто", "Сре", "Чет", "Пят", "Суб"];
    var months = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"];
    var shortmonths = ["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"];
    var battery = ["побои", "побои", "побои", "побои", "побои", "побои", "побои", "побои", "побои", "побои", "побои", "побои"];
    var weatherdesc = ["Торнадо", "Тропический шторм", "Ураган", "Гроза", "Гроза", "Снег", "Мокрый снег", "Мокрый снег", "Изморозь", "Морось", "Ледяной дождь", "Ливень", "Ливень", "Сильные порывы ветра", "Снег", "Снег", "Снег", "Град", "Мокрый снег", "Пыль", "Туман", "Легкий туман", "Туманно", "Порывисто", "Ветренно", "Холодно", "Облачно", "Облачно", "Облачно", "Облачно", "Облачно", "Ясно", "Солнечно", "Ясно", "Ясно", "Мокрый снег", "Жарко", "Гроза", "Гроза", "Гроза", "Ливень", "Снегопад", "Небольшой снег", "Снегопад", "Переменная облачность", "Гроза", "Снег", "Гроза", "пусто"];
}
if (Lang == "pl") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
   var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = ["Niedziela", "Poniedzialek", "Wtorek", "Sroda", "Czwartek", "Piatek", "Sobota"];
    var shortdays = ["Nie", "Pon", "Wto", "Sro", "Czw", "Pia", "Sob"];
    var months = ["Styczen", "Luty", "Marzec", "Kwiecien", "Maj", "Czerwiec", "Lipiec", "Sierpien", "Wrzesien", "Pazdziernik", "Listopad", "Grudzien"];
    var shortmonths = ["Sty", "Lut", "Mar", "Kwi", "Maj", "Cze", "Lip", "Sie", "Wrz", "Paz", "Lis", "Gru"];
    var battery = ["Bateria", "Bateria", "Bateria", "Bateria", "Bateria", "Bateria", "Bateria", "Bateria", "Bateria", "Bateria", "Bateria", "Bateria"];
    var weatherdesc = ["Tornado", "Tropikalna Burza", "Huragan", "Burza Z Piorunami", "Burza Z Piorunami", "Snieg", "Deszcz Ze Sniegiem", "Deszcz Ze Sniegiem", "Zamarzajaca Mzawka", "Mzawka", "Zamarzajacy Deszcz", "Przelotny Deszcz", "Przelotny Deszcz", "Przelotny Deszcz", "Snieg", "Snieg", "Snieg", "Grad", "Deszcz Ze Sniegiem", "Pyl", "Mgla", "Mgla", "Zadymiony", "Wietrznie", "Wietrznie", "Zimno", "Pochmurnie", "Pochmurnie", "Pochmurnie", "Pochmurnie", "Pochmurnie", "Czyste Niebo", "Slonecznie", "Slonecznie", "Slonecznie", "Deszcz Ze Sniegiem", "Cieplo", "Burze z Piorunami", "Burze z Piorunami", "Burze z Piorunami", "Przelotny Deszcz", "Mocny Snieg", "Lekki Snieg", "Mocny Snieg", "Czesciowo Pochmurnie", "Burza Z Piorunami", "Snieg", "Burza Z Piorunami", "puste"];
}
if (Lang == "pt") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sabado"];
    var shortdays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"];
    var months = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
    var shortmonths = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
    var battery = ["Pilha", "Pilha", "Pilha", "Pilha", "Pilha", "Pilha", "Pilha", "Pilha", "Pilha", "Pilha", "Pilha", "Pilha"];
    var weatherdesc = ["Tornado", "Tempestade Tropical", "Furacão", "Trovoada", "Trovoada", "Neve", "Chuva com Neve", "Chuva com Neve", "Geada", "Garoa", "Chuva Gélida", "Pancadas de Chuva", "Pancadas de Chuva", "Rajadas", "Neve", "Neve", "Neve", "Granizo", "Chuva Gélida", "Poeira", "Névoa", "Névoa", "Nebuloso", "Vendaval", "Ventando", "Frio", "Nublado", "Nublado", "Nublado", "Nublado", "Nublado", "Céu Limpo", "Ensolarado", "Bom Tempo", "Bom Tempo", "Chuva Gélida", "Quente", "Trovoadas", "Trovoadas", "Trovoadas", "Pancadas de Chuva", "Nevasca Pesada", "Nevasca Leve", "Nevasca Pesada", "Parcialmente Nublado", "Trovoada", "Neve", "Trovoada", "em branco"];
}
if (Lang == "no") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
   var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"];
    var shortdays = ["Søn", "Man", "Tir", "Ons", "Tor", "Fre", "Lør"];
    var months = ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"];
    var shortmonths = ["Jan", "Feb", "Mar", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Des"];
   var battery = ["Batteri", "Batteri", "Batteri", "Batteri", "Batteri", "Batteri", "Batteri", "Batteri", "Batteri", "Batteri", "Batteri", "Batteri"];
    var weatherdesc = ["Tornado",  "Tropisk Storm", "Orkan", "Kraftige Tordenbyger", "Tordenbyger", "Blandet Regn og Snø", "Blandet Regn og Sludd", "Blandet Snø og Sludd", "Underkjølt Duskregn", "Duskregn", "Underkjølt regn", "Regnbyger", "Regnbyger", "Snøbyger", "Lette Snøbyger", "Snøfokk", "Snø", "Hagl", "Sludd", "Støv", "Tåke", "Dis", "Røykfylt", "Mye Vind", "Vindkuler", "Frost", "Skyet ", "Muligheter For Regn", "Muligheter For Regn", "Delvis Skyet", "Delvis Skyet", "Klart", "Solskinn", "Lettskyet", "Lettskyet", "Blandet Regn og Hagl", "Varmt", "Isolerte Tordenbyger", "Spredte Tordenbyger", "Spredte Tordenbyger", "Spredte Regnbyger", "Kraftig Snøfall", "Spredte Snøbyger", "Kraftig Snøfall", "Delvis Skyet", "Regn og Torden", "Snøbyger", "Isolerte Regn og Torden", "ikke mottak"];
}
if (Lang == "nl") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
   var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"];
    var shortdays = ["Zon", "Maa", "Din", "Woe", "Don", "Vri", "Zat"];
    var months = ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"];
    var shortmonths = ["Jan", "Feb", "Maa", "Apr", "Mei", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"];
    var battery = ["Batterij", "Batterij", "Batterij", "Batterij", "Batterij", "Batterij", "Batterij", "Batterij", "Batterij", "Batterij", "Batterij", "Batterij"];
    var weatherdesc = ["Tornado", "Tropische Storm", "Wervelwind", "Zware Onweersbuien", "Onweersbuien", "Regen en Sneeuw", "Regen en Ijzel", "Sneeuw en Ijzel", "Bevriezende Motregen", "Motregen", "Ijzel", "Buien", "Buien", "Sneeuwvlagen", "Lichte Sneeuwbuien", "Sneeuw Drift", "Sneeuw", "Hagel", "Ijzel", "Stoffig", "Mistig", "Wazig", "Wazig", "Stormachtig", "Winderig", "Koud", "Bewolkt ", "Algemeen Bewolkt", "Algemeen Bewolkt", "Gedeeltelijk Bewolkt", "Gedeeltelijk Bewolkt", "Helder", "Zonnig", "Bewolkt Weer", "Bewolkt Weer", "Regen en Hagel", "Heet", "Geisoleerde Onweersbuien", "Verspreide Onweersbuien", "Verspreide Onweersbuien", "Verspreide Buien", "Zware Sneeuw", "Verspreide Sneeuwbuien", "Zware Sneeuw", "Gedeeltelijk Bewolkt", "Onweersbuien", "Sneeuwbuien", "Geisoleerde Onweersbuien", "Niet Beschikbaar"];
}
if (Lang == "fi") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = ["Sunnuntai", "Maanantai", "Tiistai", "Keskiviikko", "Torstai", "Perjantai", "Lauantai"];
    var shortdays = ["Sun", "Maa", "Tii", "Kes", "Tor", "Per", "Lau"];
    var months = ["Tammikuu", "Helmikuu", "Maaliskuu", "Huhtikuu", "Toukokuu", "Kesäkuu", "Heinäkuu", "Elokuu", "Syyskuu", "Lokakuu", "Marraskuu", "Joulukuu"];
    var shortmonths = ["Tam", "Hel", "Maa", "Huh", "Tou", "Kes", "Hei", "Elo", "Syy", "Lok", "Mar", "Jou"];
    var battery = ["Akku", "Akku", "Akku", "Akku", "Akku", "Akku", "Akku", "Akku", "Akku", "Akku", "Akku", "Akku"];
    var weatherdesc = ["Tornaado", "Trooppinen myrsky", "Wervelwind", "Rankkoja ukkoskuuroja", "Ukkosmyrskyj&auml;", "Vesisadetta ja r&auml;nt&auml;&auml;", "Vesi ja r&auml;nt&auml;sadetta", "Lumi ja r&auml;nt&auml;sadetta", "J&auml;&auml;t&auml;v&auml;&auml; tihkusadetta", "Tihkusadetta", "J&auml;&auml;t&auml;v&auml;&auml; sadetta", "Sadekuuroja", "Sadekuuroja", "Lumisadetta", "Heikkoja lumikuuroja", "Lumituisku", "Lumisadetta", "Rakeita", "R&auml;nt&auml;&auml;", "P&ouml;lyist&auml;", "Sumuista", "Utuista", "Utuista", "Ei tietoja", "Tuulista", "kylm&auml;&auml;", "Pilvist&auml;", "Enimm&auml;kseen pilvist&auml;", "Enimm&auml;kseen pilvist&auml;", "Puolipilvist&auml;", "Puolipilvist&auml;", "Selke&auml;&auml;", "Aurinkoista", "Selke&auml;&auml;", "Selke&auml;&auml;", "Vesisadetta ja raekuuroja", "Hellett&auml;", "Paikallisia ukkoskuuroja", "Hajanaisia ukkoskuuroja", "Hajanaisia ukkoskuuroja", "Hajanaisia sadekuuroja", "Rankkaa lumisadetta", "Hajanaisia lumikuuroja", "Rankkaa lumisadetta", "Puolipilvist&auml;", "Ukkoskuuroja", "Lumikuuroja", "Paikallisia ukkoskuuroja", "Ei tietoja"];
}
if (Lang == "cn") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
    var shortdays = ["周日","周一","周二","周三","周四","周五","周六"];
    var months = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var shortmonths = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var battery = ["电池", "电池", "电池", "电池", "电池", "电池", "电池", "电池", "电池", "电池", "电池", "电池"];
    var weatherdesc = ["风卷残云", "热带风暴", "狂风暴雨", "电闪雷鸣", "电闪雷鸣", "雨雪霏霏", "雨雪霏霏", "雨雪纷纷", "寒风冷雨", "蒙蒙细雨", "凄风冷雨", "疾风骤雨", "疾风骤雨", "俄而雪骤", "流风回雪", "狂风暴雪", "大雪纷飞", "天降冰雹", "雨雪霏霏", "飞沙走石", "云迷雾锁", "十面霾伏", "烟雾弥漫", "风起云涌", "风和日丽", "天寒地冻", "乌云蔽日", "浮云蔽日", "浮云蔽日", "云淡风轻", "云淡风轻", "晴空万里", "阳光明媚", "天朗气清", "天朗气清", "冰雹带雨", "霹雳列缺", "电闪雷鸣", "电闪雷鸣", "急风骤雨", "大雪纷飞", "骤雪初歇", "大雪纷飞", "云淡风轻", "雷阵雨", "雨雪霏霏", "霹雳列缺", "自行判断"];
}
if (Lang == "zh") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
    var shortdays = ["週日","週一","週二","週三","週四","週五","週六"];
    var months = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var shortmonths = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var battery = ["电池", "电池", "电池", "电池", "电池", "电池", "电池", "电池", "电池", "电池", "电池", "电池"];
    var weatherdesc = ["風捲殘雲", "熱帶風暴", "狂風暴雨", "電閃雷鳴", "電閃雷鳴", "雨雪霏霏", "雨雪霏霏", "雨雪紛紛", "寒風冷雨", "蒙蒙細雨", "淒風冷雨", "疾風驟雨", "疾風驟雨", "俄而雪驟", "流風回雪", "狂風暴雪", "大雪紛飛", "天降冰雹", "雨雪霏霏", "飛沙走石", "雲迷霧鎖", "十面霾伏", "煙霧瀰漫", "風起雲湧", "風和日麗", "天寒地凍", "烏雲蔽日", "浮雲蔽日", "浮雲蔽日", "雲淡風輕", "雲淡風輕", "晴空萬里", "陽光明媚", "天朗氣清", "天朗氣清", "冰雹帶雨", "霹靂列缺", "電閃雷鳴", "電閃雷鳴", "急風驟雨", "大雪紛飛", "驟雪初歇", "大雪紛飛", "雲淡風輕", "雷陣雨", "雨雪霏霏", "霹靂列缺", "自行判斷"];
}
if (Lang == "jp") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = ["日曜日", "月曜日", "火曜日", "水曜日", "木曜日", "金曜日", "土曜日"];
    var shortdays = ["日", "月", "火", "水", "木", "金", "土"];
    var months = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var shortmonths = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
    var battery = ["電池", "電池", "電池", "電池", "電池", "電池", "電池", "電池", "電池", "電池", "電池", "電池"];
    var weatherdesc = ["竜巻",  "熱帯低気圧",  "ハリケーン",  "雷雨",  "雪",  "雪",  "眠り",  "凍結霧雨",  "霧雨",  "凍結雨",  "シャワー ", "シャワー ", "フラワー ", "雪 ", "雪 ", "雪 ", "ひょう ", "曇り ", "霧 ", "曇り ", "スモーキー ", "曇り ", "風が強い", "寒い", "曇り", "曇り", "曇り", "曇り", "晴れ", "晴れ", "晴れ", "晴れ", "暑い", "暑い", "雷雨", "雷雨", "雷雨", "大雪", "小雪", "大雪", "曇り", "雷雨", "雪", "雷雨", "ブランク"];
}
if (Lang == "kr") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"];
    var shortdays = ["일", "월", "화", "수", "목", "금", "토"];
    var months = ["1등", "2등", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"];
    var shortmonths = ["1등", "2등", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"];
    var battery = ["배터리", "배터리", "배터리", "배터리", "배터리", "배터리", "배터리", "배터리", "배터리", "배터리", "배터리", "배터리"];
    var weatherdesc = ["토네이도", "열대성 폭풍", "허리케인", "뇌우", "눈", "슬리 트", "슬리 트", "이슬비가 내린다", "이슬비가 내린다", "눈", "눈", "눈", "우박", "슬리", "먼지", "안개", "안개", "연기가 자욱한", "세차게 쓴 소리", "바람", "추위", "흐림", "흐림", "흐림", "흐림", "흐림", "맑음", "맑음", "공정한", "공정한", "슬리 트", "뜨거운", "눈", "눈", "눈", "폭설", "일부 흐림", "뇌우", "눈", "뇌우", "뇌우", "뇌우", "공백"];
}
if (Lang == "tr") {
   var date = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th","10th","11th","12th","13th","14th","15th","16th","17th","18th","19th","20th","21st","22nd","23rd","24th","25th","26th","27th","28th","29th","30th","31st"];
    var secondll = [":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", "", ":", ""];
    var today = ["Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice", "Have a nice"];
    var today1 = ["Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Morning!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Afternoon!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!", "Evening!!"];
    var days = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"];
    var shortdays = ["Paz", "Paz.", "Sal", "Çar", "Per", "Cum", "Cum."];
    var months = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
    var shortmonths = ["Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara"];
    var battery = ["pil", "pil", "pil", "pil", "pil", "pil", "pil", "pil", "pil", "pil", "pil", "pil"];
    var weatherdesc = ["Kasırga", "Tropik Fırtına", "Kasırga", "Fırtına", "Fırtına", "Kar", "Karla karışık", "Karla karışık", "Dondurucu Çiseleyen", "Çiseleyen", "Dondurucu Yağmur", "Sağanak Yağmur", "Sağanak", "Flurries", "Kar", " Kar", "Kar", "Dolu", "Karla karışık", "Toz", "Sis", "Pus", "Dumanlı", "Allık ", "Rüzgarlı", "Soğuk", "Bulutlu", "Bulutlu", "Bulutlu", "Bulutlu", "Bulutlu", "Açık", "Güneşli", "Adil", "Adil", "Klozet", "Sıcak", "Fırtına", "Fırtına ", "Fırtına", "Sağanak", "Şiddetli Kar", "Hafif Kar", "Şiddetli Kar", "Parçalı Bulutlu", "Fırtına", "Kar", "Fırtına", "boş"];
}

