var Clock = "12h"; // Choose between "12h" or "24h"
var Scale = "1"; // Change Size Widget
var BGColor = "#6E2DFD"; // Choose any Color to background widget
var TextColor = "white"; // Choose any Color to Text
var GreenBattery = false; 
