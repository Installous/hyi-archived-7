/* Digital Clock Config */

var DisplayTwentyFourHourClock = true; 

var DisplayAMPM = false;

/*---------------------------------- Display Language Options ----------------------------------*/

var English = false;
var French = false;
var German = false;
var Italian = false;
var Spanish = false;
var Dutch = false;
var Turkish = true;

/*---------------------------------- Calendar Display Option 1 ----------------------------------*/

var DisplayDayMonthDate = false;
var DisplayDayMonth = false;
var DisplayDay = true;
var DisplayDayDate = false;
var DisplayMonthDate = false;
var DisplayDateMonth = false;
var DisplayYear = false;

/*--------------------------------- Calendar Display Option 2 ----------------------------------*/

var DisplayDayMonthDateAlt = false;
var DisplayDayMonthAlt = false;
var DisplayDayAlt = false;
var DisplayDayDateAlt = false;
var DisplayMonthDateAlt = false;
var DisplayDateMonthAlt = true;
var DisplayYearAlt = false;
var DisplayDateAlt = false;