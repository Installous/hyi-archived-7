

if (English == true){
var this_weekday_name_array = new Array( "Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday" )
var this_month_name_array = new Array( "January","February","March","April","May","June","July","August","September","October","November","December" )
}

if (French == true){
var this_weekday_name_array = new Array( "Dimanche","lundi","mardi","mercredi","jeudi","vendredi","samedi" )
var this_month_name_array = new Array( "Janvier","f�vrier","mars","avril","peut","juin","juillet","ao�t","septembre","octobre","novembre","d�cembre" )
}

if (German == true){
var this_weekday_name_array = new Array( "Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag" )
var this_month_name_array = new Array( "Januar","Februar","M�rz","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember" )
}

if (Italian == true){
var this_weekday_name_array = new Array( "Domenica","luned�","marted�","mercoled�","gioved�","venerd�","sabato" )
var this_month_name_array = new Array( "Gennaio","febbraio","marzo","aprile","pu�","giugno","luglio","agosto","settembre","ottobre","novembre","dicembre" )
}

if (Spanish == true){
var this_weekday_name_array = new Array( "Domingo","lunes","martes","mi�rcoles","jueves","viernes","s�bado" )
var this_month_name_array = new Array( "Enero","febrero","marcha","abril","puede","junio","julio","agosto","septiembre","octubre","noviembre","diciembre" )
}

if (Dutch == true){
var this_weekday_name_array = new Array( "Zondag","Maandag","Dinsdag","Woensdag","Donderdag","Vrijdag","Zaterdag" )
var this_month_name_array = new Array( "Januari","Februari","Maart","April","Mei","Juni","Juli","Augustus","September","Oktober","November","December" )
}

function init ( )
{
  timeDisplay = document.createTextNode ( "" );
  document.getElementById("clock").appendChild ( timeDisplay );
}

function updateClock ( )
{
  var currentTime = new Date ( );

  var currentHours = currentTime.getHours ( );
  var currentMinutes = currentTime.getMinutes ( );
  var currentSeconds = currentTime.getSeconds ( );

  // Pad the minutes and seconds with leading zeros, if required
  currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
  currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;


if (DisplayTwentyFourHourClock == false) {
  currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;

}

  var currentTimeString = currentHours + ":" + currentMinutes;
  document.getElementById("clock").firstChild.nodeValue = currentTimeString;
}

function init2 ( )
{
  timeDisplay = document.createTextNode ( "" );
  document.getElementById("ampm").appendChild ( timeDisplay );
}

function amPm ( )
{
  var currentTime = new Date ( );

  var currentHours = currentTime.getHours ( );

if (DisplayAMPM == true){
  var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
}
if (DisplayAMPM == false){
  var timeOfDay = ( currentHours < 12 ) ? "" : "";
}
  var currentTimeString = timeOfDay;
  document.getElementById("ampm").firstChild.nodeValue = currentTimeString;
}

function init3 ( )
{
  timeDisplay = document.createTextNode ( "" );
  document.getElementById("DayUpdate").appendChild ( timeDisplay );
}

function DayUpdate ( )
{

var this_date_timestamp = new Date()	

var this_weekday = this_date_timestamp.getDay()    
var this_date = this_date_timestamp.getDate()	 
var this_month = this_date_timestamp.getMonth()    
var this_year = this_date_timestamp.getYear()	 

if (this_year < 1000)
    this_year+= 1900;
if (this_year==101)
    this_year=2001;	

if (DisplayDayMonthDate == true){
	document.getElementById("DayUpdate").firstChild.nodeValue = this_weekday_name_array[this_weekday] + ", " + this_month_name_array[this_month] + " " + this_date;
}
if (DisplayDayMonth == true){
	document.getElementById("DayUpdate").firstChild.nodeValue = this_weekday_name_array[this_weekday] + ", " + this_month_name_array[this_month];
}
if (DisplayDay == true){
	document.getElementById("DayUpdate").firstChild.nodeValue = this_weekday_name_array[this_weekday];
}
if (DisplayDayDate == true){
	document.getElementById("DayUpdate").firstChild.nodeValue = this_weekday_name_array[this_weekday] + ", " + this_date;
}
if (DisplayMonthDate == true){
	document.getElementById("DayUpdate").firstChild.nodeValue = this_month_name_array[this_month] + " " + this_date;
}
if (DisplayDateMonth == true){
	document.getElementById("DayUpdate").firstChild.nodeValue = this_date + ", " + this_month_name_array[this_month];
}
if (DisplayYear == true){
	document.getElementById("DayUpdate").firstChild.nodeValue = this_year;
}
}

function init4 ( )
{
  timeDisplay = document.createTextNode ( "" );
  document.getElementById("calendar").appendChild ( timeDisplay );
}

function calendarDate ( )
{

var this_date_timestamp = new Date()	

var this_weekday = this_date_timestamp.getDay()    
var this_date = this_date_timestamp.getDate()	 
var this_month = this_date_timestamp.getMonth()    
var this_year = this_date_timestamp.getYear()	 

if (this_year < 1000)
    this_year+= 1900;
if (this_year==101)
    this_year=2001;

if (DisplayDayMonthDateAlt == true){
	document.getElementById("calendar").firstChild.nodeValue = this_weekday_name_array[this_weekday] + ", " + this_month_name_array[this_month] + " " + this_date;
}
if (DisplayDayMonthAlt == true){
	document.getElementById("calendar").firstChild.nodeValue = this_weekday_name_array[this_weekday] + ", " + this_month_name_array[this_month];
}
if (DisplayDayAlt == true){
	document.getElementById("calendar").firstChild.nodeValue = this_weekday_name_array[this_weekday];
}
if (DisplayDayDateAlt == true){
	document.getElementById("calendar").firstChild.nodeValue = this_weekday_name_array[this_weekday] + ", " + this_date;
}
if (DisplayMonthDateAlt == true){
	document.getElementById("calendar").firstChild.nodeValue = this_month_name_array[this_month] + " " + this_date;
}
if (DisplayDateMonthAlt == true){
	document.getElementById("calendar").firstChild.nodeValue = this_date + ", " + this_month_name_array[this_month];
}
if (DisplayYearAlt == true){
	document.getElementById("calendar").firstChild.nodeValue = this_year;
}
if (DisplayDateAlt == true){
	document.getElementById("calendar").firstChild.nodeValue = this_date;
}
}