#!/bin/bash

if [ -a "Wallpaper.png" ]
then
echo "Already Exists"
else
echo "Creating Link"
ln -s "/private/var/mobile/Library/SpringBoard/HomeBackground.jpg" "Wallpaper.png"
fi

