/* Weather Config */
/*---------------------------------- SringBoard options ----------------------------------*/

/* SringBoard weather Enabled?

Not used here

var enableWallpaper = true
*/
 
/* SytleSheets Pick one from the list and imput its name after var stylesheetWall = "***** */  /* NEW!! */

var stylesheetWall = "Top-(White)"

/* 
                                          Style sheets

1. Bottom
2. Bottom-(White)
3. Top
4. Top-(White)
5. split

*/
 

/* Icon Styles Pick one from the list and imput its name after var iconSetWall = "***** */  /* NEW!! */

var iconSetWall = "klear"

/* 
                                          Icon Sets

1. klear
2. tango
3. rycon
4. mau
5. HTC

*/

/* Icon Extensions Pick one from the list and imput its name after var iconExtWall = "***** */  /* NEW!! */


var iconExtWall = ".png"

/* 
                                          Icon Extensions

1. .png
2. .gif

*/


/*---------------------------------- Lockscreen options ----------------------------------*/

/* Lockscreen Enabled? */

var enableLockScreen = true

/* SytleSheets Pick one from the list and imput its name after var stylesheetLock = "***** */  /* NEW!! */

var stylesheetLock = "LockScreen"

/* 
                                          Style sheets

1. LockScreen

*/
 

/* Icon Styles Pick one from the list and imput its name after var iconSetLock = "***** */  /* NEW!! */

var iconSetLock = "tango"

/* 
                                          Icon Sets

1. klear
2. tango
3. rycon

*/


/* Icon Extensions Pick one from the list and imput its name after var iconExtLock = "***** */  /* NEW!! */


var iconExtLock = ".png"

/* 
                                          Icon Extensions

1. .png
2. .gif

*/


/*---------------------------------- options ----------------------------------*/

/* There are two sources available, 'appleAccuweatherStolen' and 'yahooWeather'. */

var source = "yahooWeather"


/*  Two methodes to set up your location depending on the source:
    accuWeather: 'City, State' (e.g. 'Karlsruhe, Germany')
    yahooWeather: 'US zip' or 'location code' (e.g. Uk Dumbarton = UKXX0663 ) */

var locale = "42276"

/* Set to 'false' for Farenheit. */

var isCelsius = false

/* AccuWeather RealFeel Temperature Enabled? */

var useRealFeel = false

/* Update interval */

var updateInterval = 60