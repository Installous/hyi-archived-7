
// boolean variables for options
// set blnAbbreviateMonth to true if you want it to abbreviate the month
var blnAbbreviateMonth = true;

// set blnAbbreviateDay to true if you want it to abbreviate the day
var blnAbbreviateDay = true;

// set blnShowSeconds to true if you want to show the seconds
var blnShowSeconds = false;

// declare our day of week names
var arrWeekday = new Array(7);
arrWeekday[0]=  "Sunday";
arrWeekday[1] = "Monday";
arrWeekday[2] = "Tuesday";
arrWeekday[3] = "Wednesday";
arrWeekday[4] = "Thursday";
arrWeekday[5] = "Friday";
arrWeekday[6] = "Saturday";

// declare our month names
var arrMonth = new Array(12);
arrMonth[0]=  "January";
arrMonth[1] = "February";
arrMonth[2] = "March";
arrMonth[3] = "April";
arrMonth[4] = "May";
arrMonth[5] = "June";
arrMonth[6] = "July";
arrMonth[7]=  "August";
arrMonth[8] = "September";
arrMonth[9] = "October";
arrMonth[10] = "November";
arrMonth[11] = "December";

function startOnLoad()
{
	setInterval ( "setDateAndTime()", 1000);
}

function setDateAndTime() {
  var dtCurrentDate = new Date();
  var intHours = dtCurrentDate.getHours();
  var intMinutes = dtCurrentDate.getMinutes();
  var intSeconds = dtCurrentDate.getSeconds();

  intMinutes = checkTime(intMinutes);
  intSeconds = checkTime(intSeconds);

  document.getElementById('tdAMPM').innerHTML = (intHours >= 12) ? "PM":"AM";

  if (intHours > 12) { intHours = intHours - 12;}
  if (intHours == 0) { intHours = intHours + 12;}

  var strTimeToDisplay = intHours + ":" + intMinutes;
	strTimeToDisplay = (blnShowSeconds == true) ? strTimeToDisplay + ":" + intSeconds:strTimeToDisplay;
  document.getElementById('tdTime').innerHTML = strTimeToDisplay + document.getElementById('tdAMPM').innerHTML;

  setMonthAndDay(dtCurrentDate);

	// set line
  var intMainContainerRight = document.getElementById('tblMainContainer').getBoundingClientRect().right;
  var intMainContainerLeft = document.getElementById('tblMainContainer').getBoundingClientRect().left;
  var intMainContainerTop = document.getElementById('tblMainContainer').getBoundingClientRect().top;
  var intMainContainerBottom = document.getElementById('tblMainContainer').getBoundingClientRect().bottom;

	var intMainLineWidth = intMainContainerRight - document.getElementById('divMonthAndDay').getBoundingClientRect().right - 5;

  var intLineWidth = intMainContainerRight - intMainContainerLeft;
  var intLine1Top = document.getElementById('divMonthAndDay').getBoundingClientRect().top + (document.getElementById('divMonthAndDay').getBoundingClientRect().bottom - document.getElementById('divMonthAndDay').getBoundingClientRect().top)/2;
  document.getElementById('imgUnderline1-2').style.width = intMainLineWidth;
  document.getElementById('spnUnderline1-2').style.left = document.getElementById('divMonthAndDay').getBoundingClientRect().right + 5;
  document.getElementById('spnUnderline1-2').style.top = intLine1Top;

	// show seconds
	document.getElementById('spnSeconds').style.left = document.getElementById('spnUnderline1-2').getBoundingClientRect().left;
	document.getElementById('spnSeconds').style.top = document.getElementById('spnUnderline1-2').getBoundingClientRect().top;

	// get increments
	var intIncrement = (intMainLineWidth/60);
	document.getElementById('imgSeconds').style.height = 1;
	document.getElementById('imgSeconds').style.width = (intIncrement * intSeconds);
}

function checkTime(intDigit) {
    if (intDigit < 10) { intDigit = "0" + intDigit};  // add zero in front of numbers < 10
    return intDigit;
}

function setMonthAndDay(dtCurrentDate)
{
  // get day of week
  var intDayOfWeek = dtCurrentDate.getDay();
  var strDayOfWeek = arrWeekday[intDayOfWeek];
	strDayOfWeek = (blnAbbreviateDay == true) ? strDayOfWeek.substring(0,3):strDayOfWeek;

  // get month name
  var strMonth = arrMonth[dtCurrentDate.getMonth()];
  strMonth = (blnAbbreviateMonth == true) ? strMonth.substring(0,3):strMonth;

  var strDayOfMonth = dtCurrentDate.getDate().toString();

  // get wording for day of month
  var intLastNumberOfDay = strDayOfMonth.slice(-1);

  var strDayOfMonthAppend = "";

	switch (intLastNumberOfDay) {
		case 1:
			strDayOfMonthAppend = "st";
			break;
		case 2:
			strDayOfMonthAppend = "nd";
			break;
		case 3:
			strDayOfMonthAppend = "rd";
			break;
		default:
			strDayOfMonthAppend = "th";
	}

	strDayOfMonth = strDayOfMonth + strDayOfMonthAppend;

  // show the Month and Day in our div
  document.getElementById('divMonthAndDay').innerHTML = strMonth + " " + strDayOfMonth;
  document.getElementById('tdDayOfWeek').innerHTML = strDayOfWeek;

}
