var twentyfourh = true; // True for 24 hour.
var pad = true; // True to pad zero in hour.
var textcolor = "#c0c0c0"; // Do not change
var IconSet = "Le0n"; // Do not change
