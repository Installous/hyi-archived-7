$("#widgetone").click(function () {
          createwidgetclock();
$("#settingspanel,#settingsclose").css('left', '-1000px');
$("#widgetfour,#widgetclosemenu,#widgetfive,#widgetthree,#widgettwo,#widgetone,#widgetsmenu").css('left', '-500px');
$("#nobg,#closemenu").css('left', '-500px');
$('#iframe').css("left", '0px');
$(".movewidgettext").css('left', '40px');
$('#widget1').css("display", 'block');
        widget1on=$('#widget1').css('display');
        localStorage.setItem('widget1switch',widget1on);
});

setwidget1=localStorage.getItem('widget1switch');
if(setwidget1=="block"){
    createwidgetclock();
    $('#widget1').css("display", 'block');
}
else{removewidgetclock();}


function createwidgetclock(){
$("<iframe></iframe>").attr('id','widget1' ).appendTo('body'); 
$("#widget1").attr('src','Widget/HTC/WidgetHTC.html' ).appendTo('widget1'); 
$("#widget1").attr('style','width:320px;height:480px;z-index:2;position:absolute;visibility:hidden;border:none;' ).appendTo('widget1'); 
$("#widget1").attr('onLoad','visible()' ).appendTo('widget1'); 
}


function visible(){
  $("#widget1").css('visibility', 'visible');
}

function removewidgetclock(){
  $('#widget1').css("display", 'none');
  widget1on=$('#widget1').css('display');
  localStorage.setItem('widget1switch',widget1on);
   $("#widget1").remove();
   
}

    $(function () {
        $("#iframe").draggable();
        $("#iframe").bind("drag", function (event, ui) {
            var div = $("#widget1");
            div.text("Top: " + div.css("top") + ", Left: " + div.css("left"));
            div.css({
                top: ui.offset.top,
                left: ui.offset.left
            });
            widget1left=$(this).css('left');
            widget1top=$(this).css('top');
            localStorage.setItem('widgetoneleft',widget1left);
            localStorage.setItem('widgetonetop',widget1top);
       });
});

  widgetonel=localStorage.getItem('widgetoneleft');
  widgetonet=localStorage.getItem('widgetonetop');
    if(widgetonel!=null){
        $('#widget1').css('left',widgetonel);
    }
    if(widgetonet!=null){
        $('#widget1').css('top',widgetonet);
    }

step = "0";
$("#iframe").click(function () {
step++
if(step == "2"){
  location.reload();
}
});
    $("#closewidget1").click(function () {
removewidgetclock();
        $("#messengertext,#phonetext,#date,#twittertext").css('-webkit-filter', 'blur(0px)');
$("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#Time,#emailbuttontext,#messagebuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(0px)');
 $('#iframe').css("left", '500px');
        $('#widget1').css("display", 'none');
         $("#closemenu").css('left', '500px');
        $("#widgetsmenu").css('left', '-500px');

    });




////



function createwidgetforecast(){
$("<iframe></iframe>").attr('id','widget2' ).appendTo('body'); 
$("#widget2").attr('src','Widget/WeatherWidget/WeatherWidget.html').appendTo('widget2'); 
$("#widget2").attr('style','width:320px;height:480px;z-index:2;position:absolute;visibility:hidden;border:none;' ).appendTo('widget2'); 
$("#widget2").attr('onLoad','visible2()' ).appendTo('widget2'); 

}
function visible2(){
  $("#widget2").css('visibility', 'visible');
}
function removewidgetforecast(){
  $('#widget2').css("display", 'none');
  w2s=$('#widget2').css("display");
  localStorage.setItem('widget2save',w2s);
   $("#widget2").remove();
}

        tap="0";
$("#iframetwo").click(function () {
        tap++
        if(tap=="2"){
        $("#iframetwo").css('left', '500px');
        tap="0";
    }
    });



    $("#widgettwo").click(function () {
$("#settingspanel,#settingsclose").css('left', '-1000px');
  createwidgetforecast();
$("#widgetfour,#widgetclosemenu,#widgetfive,#widgetthree,#widgetone,#widgettwo").css('left', '-500px');
        $(".movewidgettext").css('top', '280px');
        $('#iframetwo').css("left", '0px');
        $('#iframe,#nobg,#closemenu').css("left", '500px');
        $("#widgetsmenu").css('left', '-2500px');
        $('#widget2').css("display", 'block');
        $('#widget2').css("left", '-13px');

        w2s=$('#widget2').css("display");
        localStorage.setItem('widget2save',w2s);
    
    });

    w2ss=localStorage.getItem('widget2save');
    if(w2ss=="block"){createwidgetforecast();$('#widget2').css("display", 'block');}
    else{removewidgetforecast();}




$(function () {
        $("#iframetwo").draggable();
        $("#iframetwo").bind("drag", function (event, ui) {
            var div = $("#widget2");
            div.text("Top: " + div.css("top") + ", Left: " + div.css("left"));
            div.css({
                top: ui.offset.top,
                left: ui.offset.left
            });
            widgettwoleft=$(this).css('left');
            widgettwotop=$(this).css('top');
            localStorage.setItem('widget2left',widgettwoleft);
            localStorage.setItem('widget2top',widgettwotop);

         });
});

            w2left=localStorage.getItem('widget2left');
            w2top=localStorage.getItem('widget2top');
            if(w2left!=null){$("#widget2").css('left',w2left);}
            if(w2top!=null){$("#widget2").css('top',w2top);}


///

  function createuni(){
$("<iframe></iframe>").attr('id','widget3' ).appendTo('body'); 
$("#widget3").attr('src','Widget/UniAW5.0 by IanNichol/LockBackground.html').appendTo('widget2'); 
$("#widget3").attr('style','border:none;width:320px;z-index:2;height:583px;display:inline-block;visibility:hidden;position:absolute;' ).appendTo('widget3'); 
$("#widget3").attr('onLoad','visible3()' ).appendTo('widget3'); 

}
 function visible3(){
  $("#widget3").css('visibility', 'visible');
}
function removeuni(){
  $('#widget3').css("display", 'none');
  w3s=$('#widget3').css("display");
  localStorage.setItem('widget3save',w3s);
   $("#widget3").remove();
}



$("#widgetthree").click(function () {
$("#settingspanel,#settingsclose").css('left', '-1000px');
 createuni();
       

$("#widgetfour,#widgetclosemenu,#widgetfive,#widgetthree,#widgetone,#widgettwo").css('left', '-500px');
$("#widgetsmenu").css('left', '-2500px');

        $('#widget3').css("display", 'block');
        $("#widgetthree").css('left', '-500px');

        w3s=$('#widget3').css("display");
        localStorage.setItem('widget3save',w3s);

    });



    w3ss=localStorage.getItem('widget3save');
    if(w3ss=="block"){createuni();$('#widget3').css("display", 'block');}
    else{removeuni();}

    $("#widgetfour").click(function () {
      localStorage.setItem('twitterstart','yes');


        $("#settingspanel,#settingsclose").css('left', '-1000px');
$("#widgetclosemenu,#widgetsmenu,#widgetfive,#widgetfour,#widgetthree,#widgetone,#widgettwo").css('left', '-500px');
        $('#iframefour').css("left", '0px');
        $("#nobg,#closemenu").css('left', '500px');
        $('.twittertweet').css("display", 'block');
        starttwitter();
    
    });
starttwitters=localStorage.getItem('twitterstart');
if(starttwitters=="yes"){
  $('.twittertweet').css('display', 'block');
  starttwitter();
}
if(starttwitters=="no"){
$('.twittertweet').css('display', 'none');
}
if(starttwitters=="null"){
  $('.twittertweet').css('display', 'none');
}
if(starttwitters==null){
  $('.twittertweet').css('display', 'none');
}




function starttwitter(){

 
  !function(d,s,id)
  {var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';
  if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");

}

$("#widgetfive").click(function () {
  $("#settingspanel,#settingsclose").css('left', '-1000px');
$("#widgetfour,#widgetclosemenu,#widgetthree,#widgetone,#widgettwo,#widgetfive").css('left', '-500px');
 $("#messengertext,#phonetext,#date,#twittertext").css('-webkit-filter', 'blur(0px)');
$("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#Time,#emailbuttontext,#messagebuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(0px)');
$("#weather").css('-webkit-transform', 'scale(1)');
localStorage.setItem('analogclock','yes');
   startanalog();

});

widgeton=localStorage.getItem('analogclock');

if(widgeton=="yes"){
  startanalog();

}
else{

}


function startanalog(){
  $("#widget5attach").css('display','block');
$("<iframe></iframe>").attr('id','widget5' ).appendTo('.widgetmover'); 
$("#widget5").attr('src','Widget/Analog Clock/Widget.html').appendTo('widget5'); 
$("#widget5").attr('style','border:none;width:200px;z-index:2;height:200px;display:inline-block;visibility:hidden;position:absolute;' ).appendTo('widget5'); 
$("#widget5").attr('onLoad','visible5()' ).appendTo('widget5'); 

}
 function visible5(){
  $("#widget5").css('visibility', 'visible');
}

function removeanalog(){

  $('#widget5').css("display", 'none');
localStorage.removeItem('analogclock');
localStorage.removeItem('widget5attachscaled');
localStorage.removeItem('analogleft');
localStorage.removeItem('analogtop');
localStorage.removeItem('whichface');
   $("#widget5").remove();
   $("#widget5attach").remove();

}


clicking="0";
function changeface(){
clicking++

if(clicking=="1"){
  $("#widget5attach").css('display','block');
  faceone();
  localStorage.setItem('whichface',"1");
}


if(clicking=="2"){
  $("#widget5attach").css('display','block');
facetwo();
localStorage.setItem('whichface',"2");
}

if(clicking=="3"){
  $("#widget5attach").css('display','block');
facethree();
localStorage.setItem('whichface',"3");
}

if(clicking=="4"){
  $("#widget5attach").css('display','block');
facefour();
localStorage.setItem('whichface',"4");
}

if(clicking=="5"){
  $("#widget5attach").css('display','block');
facefive();
localStorage.setItem('whichface',"5");
}

}

face=localStorage.getItem('whichface')

if(face=="1"){faceone();}

if(face=="2"){facetwo();}

if(face=="3"){facethree();}

if(face=="4"){facefour();}

if(face=="5"){facefive();}


function faceone(){
    $("<iframe></iframe>").attr('id','widget5' ).appendTo('.widgetmover'); 
$("#widget5").attr('src','Widget/Ziiro Clock/Widget.html').appendTo('widget5'); 
$("#widget5").attr('style','border:none;width:200px;z-index:2;height:200px;display:inline-block;visibility:hidden;position:absolute;' ).appendTo('widget5'); 
$("#widget5").attr('onLoad','visible5()' ).appendTo('widget5'); 
  analogleft=localStorage.getItem('analogleft');
  analogtop=localStorage.getItem('analogtop');

    if(analogleft!=null){ $('#widget5attach').css('left', analogleft);}
    if(analogleft!=null){ $('#widget5').css('left', analogleft);}
    if(analogtop!=null){ $('#widget5attach').css('top', analogtop);}
    if(analogtop!=null){ $('#widget5').css('top', analogtop);}

    widget5scaled=localStorage.getItem('widget5attachscaled');

if(widget5scaled!=null){
$('#widget5').css('-webkit-transform', widget5scaled);
$('#widget5attach').css('-webkit-transform', widget5scaled);
}
}

function facetwo(){
    $("<iframe></iframe>").attr('id','widget5' ).appendTo('.widgetmover'); 
$("#widget5").attr('src','Widget/Mysteri Clock/Widget.html').appendTo('widget5'); 
$("#widget5").attr('style','border:none;width:200px;z-index:2;height:200px;display:inline-block;visibility:hidden;position:absolute;' ).appendTo('widget5'); 
$("#widget5").attr('onLoad','visible5()' ).appendTo('widget5'); 
  analogleft=localStorage.getItem('analogleft');
  analogtop=localStorage.getItem('analogtop');

    if(analogleft!=null){ $('#widget5attach').css('left', analogleft);}
    if(analogleft!=null){ $('#widget5').css('left', analogleft);}
    if(analogtop!=null){ $('#widget5attach').css('top', analogtop);}
    if(analogtop!=null){ $('#widget5').css('top', analogtop);}

    widget5scaled=localStorage.getItem('widget5attachscaled');

if(widget5scaled!=null){
$('#widget5').css('-webkit-transform', widget5scaled);
$('#widget5attach').css('-webkit-transform', widget5scaled);
}
}

function facethree(){
    $("<iframe></iframe>").attr('id','widget5' ).appendTo('.widgetmover'); 
$("#widget5").attr('src','Widget/Light Clock/Widget.html').appendTo('widget5'); 
$("#widget5").attr('style','border:none;width:200px;z-index:2;height:200px;display:inline-block;visibility:hidden;position:absolute;' ).appendTo('widget5'); 
$("#widget5").attr('onLoad','visible5()' ).appendTo('widget5'); 
  analogleft=localStorage.getItem('analogleft');
  analogtop=localStorage.getItem('analogtop');

    if(analogleft!=null){ $('#widget5attach').css('left', analogleft);}
    if(analogleft!=null){ $('#widget5').css('left', analogleft);}
    if(analogtop!=null){ $('#widget5attach').css('top', analogtop);}
    if(analogtop!=null){ $('#widget5').css('top', analogtop);}

    widget5scaled=localStorage.getItem('widget5attachscaled');

if(widget5scaled!=null){
$('#widget5').css('-webkit-transform', widget5scaled);
$('#widget5attach').css('-webkit-transform', widget5scaled);
}
}

function facefour(){
    $("<iframe></iframe>").attr('id','widget5' ).appendTo('.widgetmover'); 
$("#widget5").attr('src','Widget/Futuristic Clock/Widget.html').appendTo('widget5'); 
$("#widget5").attr('style','border:none;width:200px;z-index:2;height:200px;display:inline-block;visibility:hidden;position:absolute;' ).appendTo('widget5'); 
$("#widget5").attr('onLoad','visible5()' ).appendTo('widget5'); 
  analogleft=localStorage.getItem('analogleft');
  analogtop=localStorage.getItem('analogtop');

    if(analogleft!=null){ $('#widget5attach').css('left', analogleft);}
    if(analogleft!=null){ $('#widget5').css('left', analogleft);}
    if(analogtop!=null){ $('#widget5attach').css('top', analogtop);}
    if(analogtop!=null){ $('#widget5').css('top', analogtop);}

    widget5scaled=localStorage.getItem('widget5attachscaled');

if(widget5scaled!=null){
$('#widget5').css('-webkit-transform', widget5scaled);
$('#widget5attach').css('-webkit-transform', widget5scaled);
}
}


function facefive(){
    $("<iframe></iframe>").attr('id','widget5' ).appendTo('.widgetmover'); 
$("#widget5").attr('src','Widget/Analog Clock/Widget.html').appendTo('widget5'); 
$("#widget5").attr('style','border:none;width:200px;z-index:2;height:200px;display:inline-block;visibility:hidden;position:absolute;' ).appendTo('widget5'); 
$("#widget5").attr('onLoad','visible5()' ).appendTo('widget5'); 
clicking="0"
  analogleft=localStorage.getItem('analogleft');
  analogtop=localStorage.getItem('analogtop');

    if(analogleft!=null){ $('#widget5attach').css('left', analogleft);}
    if(analogleft!=null){ $('#widget5').css('left', analogleft);}
    if(analogtop!=null){ $('#widget5attach').css('top', analogtop);}
    if(analogtop!=null){ $('#widget5').css('top', analogtop);}

    widget5scaled=localStorage.getItem('widget5attachscaled');

if(widget5scaled!=null){
$('#widget5').css('-webkit-transform', widget5scaled);
$('#widget5attach').css('-webkit-transform', widget5scaled);
}
}


//widget5attach
$('#widget5attach').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});


$('#widget5attach').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;
if(e.type == 'gesturechange'){
     //Change
    e.preventDefault();

    var div = $("#widget5");
    var div2 = $("#widget5attach");
    scaler=orig.scale;
    var hscale = "scale("+scaler+")";
     div.css({"-webkit-transform":hscale});
     div2.css({"-webkit-transform":hscale});    
    
    node = $("#widget5")[0];
var curTransform = new WebKitCSSMatrix(window.getComputedStyle(node).webkitTransform);
 localStorage.setItem('widget5attachscaled',curTransform);
}
});

widget5scaled=localStorage.getItem('widget5attachscaled');

if(widget5scaled!=null){
$('#widget5').css('-webkit-transform', widget5scaled);
$('#widget5attach').css('-webkit-transform', widget5scaled);
}