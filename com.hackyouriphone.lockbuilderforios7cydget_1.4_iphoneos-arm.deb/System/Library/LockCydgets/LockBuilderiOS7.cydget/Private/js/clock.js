calendarDate();
 function init ()
 {
   timeDisplay = document.createTextNode ( "" );
   document.getElementById("clock").appendChild ( timeDisplay );
 }
updateClock();
 setInterval('updateClock()', 1000 );
function updateClock(){
     var TwentyFourHourClock = localStorage.getItem('time'); 
   
if (TwentyFourHourClock == "true"){


   var currentTime = new Date ( );
   var currentHours = currentTime.getHours ( );

   var currentMinutes = currentTime.getMinutes ( );

   var currentSeconds = currentTime.getSeconds ( );

   currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;

   currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;

   var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";

   currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;

   currentHours = ( currentHours == 0 ) ? 12 : currentHours;

   var currentTimeString = currentHours + ":" + currentMinutes;

   document.getElementById("clock").firstChild.nodeValue = currentTimeString;



   var currentHours_name_array = new Array ("Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve")
   var currentMinutes_name_array = new Array ("o' clock", "o' one", "o' two", "o' three", "o' four", "o' five", "o' six", "o' seven", "o' eight", "o' nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty")
   var currentminutespart_name_array = new Array ("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "")

   var currentTime = new Date ( );
   var currentHours = currentTime.getHours ( );
   var currentMinutes = currentTime.getMinutes ( );
   var currentminutespart = currentTime.getMinutes ( );
   var currentSeconds = currentTime.getSeconds ( );
   var currentTimeString = currentHours_name_array[currentHours];
    var currentTimeString1 = currentMinutes_name_array[currentMinutes];
    var currentTimeString2 = currentminutespart_name_array[currentminutespart];
   document.getElementById("ttext").firstChild.nodeValue = currentTimeString +"\n"+ currentTimeString1 +"\n"+ currentTimeString2;


  
 }

if (TwentyFourHourClock == "false"){

   var currentTime = new Date ( );
   var currentHours = currentTime.getHours ( );

   var currentMinutes = currentTime.getMinutes ( );

  var currentSeconds = currentTime.getSeconds ( ); currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;
  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
  var currentTimeString = currentHours + ":" + currentMinutes;

   document.getElementById("clock").firstChild.nodeValue = currentTimeString;
 
  var currentHours_name_array = new Array ("Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty", "TwentyOne", "TwentyTwo", "TwentyThree", "TwetyFour")
   var currentMinutes_name_array = new Array ("o' clock", "o' one", "o' two", "o' three", "o' four", "o' five", "o' six", "o' seven", "o' eight", "o' nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty")
   var currentminutespart_name_array = new Array ("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "")

   var currentTime = new Date ();
   var currentHours = currentTime.getHours ();
   var currentMinutes = currentTime.getMinutes ();
   var currentminutespart = currentTime.getMinutes ();
   var currentSeconds = currentTime.getSeconds ();
   var currentTimeString = currentHours_name_array[currentHours];
    var currentTimeString1 = currentMinutes_name_array[currentMinutes];
    var currentTimeString2 = currentminutespart_name_array[currentminutespart];
   document.getElementById("ttext").firstChild.nodeValue = currentTimeString +"\n"+ currentTimeString1 +"\n"+ currentTimeString2;





}

}
 





 function init2 ( )

 {

   timeDisplay = document.createTextNode ( "" );

   document.getElementById("ampm").appendChild ( timeDisplay );

 }



 function amPm ( )

 {

   var currentTime = new Date ( );



   var currentHours = currentTime.getHours ( );




   var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";




   currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;




   currentHours = ( currentHours == 0 ) ? 12 : currentHours;





   var currentTimeString = timeOfDay;



   

   document.getElementById("ampm").firstChild.nodeValue = currentTimeString;

 }



 function init3 ( )

 {

   timeDisplay = document.createTextNode ( "" );

   document.getElementById("calendar").appendChild ( timeDisplay );

 }



 function calendarDate (){

var lang="en";

    get=localStorage.getItem("languages");
if(get!=null){
  lang=get;
}



switch (lang) {
case "fr":
  var this_weekday_name_array = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
  var this_month_name_array=['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre'];
break;
case "de":
  var this_weekday_name_array = ["Son","Mon","Die","Mit","Don","Fre","Sam"];
  var this_month_name_array=["Januar","Februar","Marz","April","Mai","Juni","Juli","August","September ","Oktober","November","Dezember"];     
break;
case "sp":
  var this_weekday_name_array = ["Dom","Lun","Mar","Mie","Jue","Vie","Sab"];
  var this_month_name_array=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Juliot','Agosto','Septiembre','Octubre','Novimbre','Decimbre'];
break;
case "it":
  var this_weekday_name_array = ["Dom","Lun","Mar","Mer","Gio","Ven","Sab"];
  var this_month_name_array=['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];
break;
default: 
  var this_weekday_name_array = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  var this_month_name_array=["January","February","March","April","May","June","July","August","September","October","November","December"];
break;
}

   var this_date_timestamp = new Date()



   var this_weekday = this_date_timestamp.getDay()

   var this_date = this_date_timestamp.getDate()

   var this_month = this_date_timestamp.getMonth()



   document.getElementById("calendar").firstChild.nodeValue = this_weekday_name_array[this_weekday] + ", " + this_month_name_array[this_month] + " " + this_date  //concat long date string

 }



