//Tweetbot
$('#Tweetbot').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});



var width = "60"; var rotation = 0;
    $('#Tweetbot').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;


if(e.type == 'gesturechange'){
     //Save rotation
     Tweetbotrotated = $("#Tweetbot").css('-webkit-transform');
     localStorage.setItem('Tweetbotrotated',Tweetbotrotated);
     //Save Scale
     Tweetbotscaled = $("#Tweetbot").css('width');
     localStorage.setItem('Tweetbotscaled',Tweetbotscaled);
     //Change
    e.preventDefault();
    $('.do #Tweetbot img').css("width", parseFloat(width) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

Tweetbotriptionrotation=localStorage.getItem('Tweetbotrotated');
Tweetbotriptionscaled=localStorage.getItem('Tweetbotscaled');

if(Tweetbotriptionrotation!=null){
    $('#Tweetbot').css('-webkit-transform', Tweetbotriptionrotation);
}
if(Tweetbotriptionscaled!=null){
    $('.do #Tweetbot img').css('width', Tweetbotriptionscaled);
}


//Phone
$('#Phone').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var width = "60"; var rotation = 0;
    $('#Phone').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     Phonerotated = $("#Phone").css('-webkit-transform');
     localStorage.setItem('Phonerotated',Phonerotated);
     //Save Scale
     Phonescaled = $("#Phone").css('width');
     localStorage.setItem('Phonescaled',Phonescaled);
     //Change
    e.preventDefault();
    $('.do #Phone img').css("width", parseFloat(width) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

Phoneriptionrotation=localStorage.getItem('Phonerotated');
Phoneriptionscaled=localStorage.getItem('Phonescaled');

if(Phoneriptionrotation!=null){
    $('#Phone').css('-webkit-transform', Phoneriptionrotation);
}
if(Phoneriptionscaled!=null){
    $('.do #Phone img').css('width', Phoneriptionscaled);
}


//Mail
$('#Mail').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var width = "60"; var rotation = 0;
    $('#Mail').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     Mailrotated = $("#Mail").css('-webkit-transform');
     localStorage.setItem('Mailrotated',Mailrotated);
     //Save Scale
     Mailscaled = $("#Mail").css('width');
     localStorage.setItem('Mailscaled',Mailscaled);
     //Change
    e.preventDefault();
    $('.do #Mail img').css("width", parseFloat(width) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

Mailriptionrotation=localStorage.getItem('Mailrotated');
Mailriptionscaled=localStorage.getItem('Mailscaled');

if(Mailriptionrotation!=null){
    $('#Mail').css('-webkit-transform', Mailriptionrotation);
}
if(Mailriptionscaled!=null){
    $('.do #Mail img').css('width', Mailriptionscaled);
}

//Facebook
$('#Facebook').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var width = "60"; var rotation = 0;
    $('#Facebook').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     Facebookrotated = $("#Facebook").css('-webkit-transform');
     localStorage.setItem('Facebookrotated',Facebookrotated);
     //Save Scale
     Facebookscaled = $("#Facebook").css('width');
     localStorage.setItem('Facebookscaled',Facebookscaled);
     //Change
    e.preventDefault();
    $('.do #Facebook img').css("width", parseFloat(width) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

Facebookriptionrotation=localStorage.getItem('Facebookrotated');
Facebookriptionscaled=localStorage.getItem('Facebookscaled');

if(Facebookriptionrotation!=null){
    $('#Facebook').css('-webkit-transform', Facebookriptionrotation);
}
if(Facebookriptionscaled!=null){
    $('.do #Facebook img').css('width', Facebookriptionscaled);
}
//Timer
$('#Timer').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var width = "60"; var rotation = 0;
    $('#Timer').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     Timerrotated = $("#Timer").css('-webkit-transform');
     localStorage.setItem('Timerrotated',Timerrotated);
     //Save Scale
     Timerscaled = $("#Timer").css('width');
     localStorage.setItem('Timerscaled',Timerscaled);
     //Change
    e.preventDefault();
    $('.do #Timer img').css("width", parseFloat(width) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

Timerriptionrotation=localStorage.getItem('Timerrotated');
Timerriptionscaled=localStorage.getItem('Timerscaled');

if(Timerriptionrotation!=null){
    $('#Timer').css('-webkit-transform', Timerriptionrotation);
}
if(Timerriptionscaled!=null){
    $('.do #Timer img').css('width', Timerriptionscaled);
}


//Messages
$('#Messages').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var width = "60"; var rotation = 0;
    $('#Messages').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     Messagesrotated = $("#Messages").css('-webkit-transform');
     localStorage.setItem('Messagesrotated',Messagesrotated);
     //Save Scale
     Messagessscaled = $("#Messages").css('width');
     localStorage.setItem('Messagesscaled',Messagessscaled);
     //Change
    e.preventDefault();
    $('.do #Messages img').css("width", parseFloat(width) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

Messagesriptionrotation=localStorage.getItem('Messagesrotated');
Messagesriptionscaled=localStorage.getItem('Messagesscaled');

if(Messagesriptionrotation!=null){
    $('#Messages').css('-webkit-transform', Messagesriptionrotation);
}
if(Messagesriptionscaled!=null){
        $('.do #Messages img').css('width', Messagesriptionscaled);
}
//Instagram
$('#Instagram').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var width = "60"; var rotation = 0;
    $('#Instagram').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     Instagramrotated = $("#Instagram").css('-webkit-transform');
     localStorage.setItem('Instagramrotated',Instagramrotated);
     //Save Scale
     Instagramscaled = $("#Instagram").css('width');
     localStorage.setItem('Instagramscaled',Instagramscaled);
     //Change
    e.preventDefault();
    $('.do #Instagram img').css("width", parseFloat(width) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

Instagramriptionrotation=localStorage.getItem('Instagramrotated');
Instagramriptionscaled=localStorage.getItem('Instagramscaled');

if(Instagramriptionrotation!=null){
    $('#Instagram').css('-webkit-transform', Instagramriptionrotation);
}
if(Instagramriptionscaled!=null){
    $('.do #Instagram img').css('width', Instagramriptionscaled);
}
//Line
$('#Line').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var width = "60"; var rotation = 0;
    $('#Line').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     Linerotated = $("#Line").css('-webkit-transform');
     localStorage.setItem('Linerotated',Linerotated);
     //Save Scale
     Linescaled = $("#Line").css('width');
     localStorage.setItem('Linescaled',Linescaled);
     //Change
    e.preventDefault();
    $('.do #Line img').css("width", parseFloat(width) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

Lineriptionrotation=localStorage.getItem('Linerotated');
Lineriptionscaled=localStorage.getItem('Linescaled');

if(Lineriptionrotation!=null){
    $('#Line').css('-webkit-transform', Lineriptionrotation);
}
if(Lineriptionscaled!=null){
    $('.do #Line img').css('width', Lineriptionscaled);
}






//city
$('#city').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "50px"; var rotation = 0;
    $('#city').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     cityrotated = $("#city").css('-webkit-transform');
     localStorage.setItem('cityrotated',cityrotated);
     //Save Scale
     cityscaled = $("#city").css('font-size');
     localStorage.setItem('cityscaled',cityscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

cityriptionrotation=localStorage.getItem('cityrotated');
cityriptionscaled=localStorage.getItem('cityscaled');

if(cityriptionrotation!=null){
    $('#city').css('-webkit-transform', cityriptionrotation);
}
if(cityriptionscaled!=null){
    $('#city').css('font-size', cityriptionscaled);
}


//temp
$('#temp').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "50px"; var rotation = 0;
    $('#temp').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     temprotated = $("#temp").css('-webkit-transform');
     localStorage.setItem('temprotated',temprotated);
     //Save Scale
     tempscaled = $("#temp").css('font-size');
     localStorage.setItem('tempscaled',tempscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

tempriptionrotation=localStorage.getItem('temprotated');
tempriptionscaled=localStorage.getItem('tempscaled');

if(tempriptionrotation!=null){
    $('#temp').css('-webkit-transform', tempriptionrotation);
}
if(tempriptionscaled!=null){
    $('#temp').css('font-size', tempriptionscaled);
}


//humidity
$('#humidity').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "50px"; var rotation = 0;
    $('#humidity').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     humidityrotated = $("#humidity").css('-webkit-transform');
     localStorage.setItem('humidityrotated',humidityrotated);
     //Save Scale
     humidityscaled = $("#humidity").css('font-size');
     localStorage.setItem('humidityscaled',humidityscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

humidityriptionrotation=localStorage.getItem('humidityrotated');
humidityriptionscaled=localStorage.getItem('humidityscaled');

if(humidityriptionrotation!=null){
    $('#humidity').css('-webkit-transform', humidityriptionrotation);
}
if(humidityriptionscaled!=null){
    $('#humidity').css('font-size', humidityriptionscaled);
}

//desc
$('#desc').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "50px"; var rotation = 0;
    $('#desc').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     descrotated = $("#desc").css('-webkit-transform');
     localStorage.setItem('descrotated',descrotated);
     //Save Scale
     descscaled = $("#desc").css('font-size');
     localStorage.setItem('descscaled',descscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

descriptionrotation=localStorage.getItem('descrotated');
descriptionscaled=localStorage.getItem('descscaled');

if(descriptionrotation!=null){
    $('#desc').css('-webkit-transform', descriptionrotation);
}
if(descriptionscaled!=null){
    $('#desc').css('font-size', descriptionscaled);
}


//calendar
$('#calendar').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "50px"; var rotation = 0;
    $('#calendar').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     calendarrotated = $("#calendar").css('-webkit-transform');
     localStorage.setItem('calendarrotated',calendarrotated);
     //Save Scale
     calendarscaled = $("#calendar").css('font-size');
     localStorage.setItem('calendarscaled',calendarscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

calendarriptionrotation=localStorage.getItem('calendarrotated');
calendarriptionscaled=localStorage.getItem('calendarscaled');

if(calendarriptionrotation!=null){
    $('#calendar').css('-webkit-transform', calendarriptionrotation);
}
if(calendarriptionscaled!=null){
    $('#calendar').css('font-size', calendarriptionscaled);
}

//hi
$('#hi').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "50px"; var rotation = 0;
    $('#hi').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     hirotated = $("#hi").css('-webkit-transform');
     localStorage.setItem('hirotated',hirotated);
     //Save Scale
     hiscaled = $("#hi").css('font-size');
     localStorage.setItem('hiscaled',hiscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

hiriptionrotation=localStorage.getItem('hirotated');
hiriptionscaled=localStorage.getItem('hiscaled');

if(hiriptionrotation!=null){
    $('#hi').css('-webkit-transform', hiriptionrotation);
}
if(hiriptionscaled!=null){
    $('#hi').css('font-size', hiriptionscaled);
}

//lo
$('#lo').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "50px"; var rotation = 0;
    $('#lo').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     lorotated = $("#lo").css('-webkit-transform');
     localStorage.setItem('lorotated',lorotated);
     //Save Scale
     loscaled = $("#lo").css('font-size');
     localStorage.setItem('loscaled',loscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

loriptionrotation=localStorage.getItem('lorotated');
loriptionscaled=localStorage.getItem('loscaled');

if(loriptionrotation!=null){
    $('#lo').css('-webkit-transform', loriptionrotation);
}
if(loriptionscaled!=null){
    $('#lo').css('font-size', loriptionscaled);
}

//weatherIcon2
$('#weatherIcon2').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var width = "100"; var rotation = 0;
    $('#weatherIcon2').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     weatherIcon2rotated = $("#weatherIcon2").css('-webkit-transform');
     localStorage.setItem('weatherIcon2rotated',weatherIcon2rotated);
     //Save Scale
     weatherIcon2scaled = $("#weatherIcon2").css('width');
     localStorage.setItem('weatherIcon2scaled',weatherIcon2scaled);
     //Change
    e.preventDefault();
    $(this).css("width", parseFloat(width) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

weatherIcon2riptionrotation=localStorage.getItem('weatherIcon2rotated');
weatherIcon2riptionscaled=localStorage.getItem('weatherIcon2scaled');

if(weatherIcon2riptionrotation!=null){
    $('#weatherIcon2').css('-webkit-transform', weatherIcon2riptionrotation);
}
if(weatherIcon2riptionscaled!=null){
    $('#weatherIcon2').css('width', weatherIcon2riptionscaled);
}


//clock
$('#clock').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "50px"; var rotation = 0;
    $('#clock').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     clockrotated = $("#clock").css('-webkit-transform');
     localStorage.setItem('clockrotated',clockrotated);
     //Save Scale
     clockscaled = $("#clock").css('font-size');
     localStorage.setItem('clockscaled',clockscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

clockriptionrotation=localStorage.getItem('clockrotated');
clockriptionscaled=localStorage.getItem('clockscaled');

if(clockriptionrotation!=null){
    $('#clock').css('-webkit-transform', clockriptionrotation);
}
if(clockriptionscaled!=null){
    $('#clock').css('font-size', clockriptionscaled);
}

//ttext
$('#ttext').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "50px"; var rotation = 0;
    $('#ttext').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;
    var num = orig.rotation;
num = Math.ceil(num * 10) / 10;

if(e.type == 'gesturechange'){
     //Save rotation
     ttextrotated = $("#ttext").css('-webkit-transform');
     localStorage.setItem('ttextrotated',ttextrotated);
     //Save Scale
     ttextscaled = $("#ttext").css('font-size');
     localStorage.setItem('ttextscaled',ttextscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

ttextriptionrotation=localStorage.getItem('ttextrotated');
ttextriptionscaled=localStorage.getItem('ttextscaled');

if(ttextriptionrotation!=null){
    $('#ttext').css('-webkit-transform', ttextriptionrotation);
}
if(ttextriptionscaled!=null){
    $('#ttext').css('font-size', ttextriptionscaled);
}

//utext
$('#utext').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "20px"; var rotation = 0;
    $('#utext').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     utextrotated = $("#utext").css('-webkit-transform');
     localStorage.setItem('utextrotated',utextrotated);
     //Save Scale
     utextscaled = $("#utext").css('font-size');
     localStorage.setItem('utextscaled',utextscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

utextriptionrotation=localStorage.getItem('utextrotated');
utextriptionscaled=localStorage.getItem('utextscaled');

if(utextriptionrotation!=null){
    $('#utext').css('-webkit-transform', utextriptionrotation);
}
if(utextriptionscaled!=null){
    $('#utext').css('font-size', utextriptionscaled);
}


//untext
$('#untext').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "20px"; var rotation = 0;
    $('#untext').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     untextrotated = $("#untext").css('-webkit-transform');
     localStorage.setItem('untextrotated',untextrotated);
     //Save Scale
     untextscaled = $("#untext").css('font-size');
     localStorage.setItem('untextscaled',untextscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

untextriptionrotation=localStorage.getItem('untextrotated');
untextriptionscaled=localStorage.getItem('untextscaled');

if(untextriptionrotation!=null){
    $('#untext').css('-webkit-transform', untextriptionrotation);
}
if(untextriptionscaled!=null){
    $('#untext').css('font-size', untextriptionscaled);
}




//messagetext
$('#messagetext').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "50px"; var rotation = 0;
    $('#messagetext').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     messagetextrotated = $("#messagetext").css('-webkit-transform');
     localStorage.setItem('messagetextrotated',messagetextrotated);
     //Save Scale
     messagetextscaled = $("#messagetext").css('font-size');
     localStorage.setItem('messagetextscaled',messagetextscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

messagetextriptionrotation=localStorage.getItem('messagetextrotated');
messagetextriptionscaled=localStorage.getItem('messagetextscaled');

if(messagetextriptionrotation!=null){
    $('#messagetext').css('-webkit-transform', messagetextriptionrotation);
}
if(messagetextriptionscaled!=null){
    $('#messagetext').css('font-size', messagetextriptionscaled);
}

//emailtext
$('#emailtext').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "50px"; var rotation = 0;
    $('#emailtext').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     emailtextrotated = $("#emailtext").css('-webkit-transform');
     localStorage.setItem('emailtextrotated',emailtextrotated);
     //Save Scale
     emailtextscaled = $("#emailtext").css('font-size');
     localStorage.setItem('emailtextscaled',emailtextscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

emailtextriptionrotation=localStorage.getItem('emailtextrotated');
emailtextriptionscaled=localStorage.getItem('emailtextscaled');

if(emailtextriptionrotation!=null){
    $('#emailtext').css('-webkit-transform', emailtextriptionrotation);
}
if(emailtextriptionscaled!=null){
    $('#emailtext').css('font-size', emailtextriptionscaled);
}

//phonetext
$('#phonetext').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "50px"; var rotation = 0;
    $('#phonetext').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     phonetextrotated = $("#phonetext").css('-webkit-transform');
     localStorage.setItem('phonetextrotated',phonetextrotated);
     //Save Scale
     phonetextscaled = $("#phonetext").css('font-size');
     localStorage.setItem('phonetextscaled',phonetextscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

phonetextriptionrotation=localStorage.getItem('phonetextrotated');
phonetextriptionscaled=localStorage.getItem('phonetextscaled');

if(phonetextriptionrotation!=null){
    $('#phonetext').css('-webkit-transform', phonetextriptionrotation);
}
if(phonetextriptionscaled!=null){
    $('#phonetext').css('font-size', phonetextriptionscaled);
}

//twittertext
$('#twittertext').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "50px"; var rotation = 0;
    $('#twittertext').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     twittertextrotated = $("#twittertext").css('-webkit-transform');
     localStorage.setItem('twittertextrotated',twittertextrotated);
     //Save Scale
     twittertextscaled = $("#twittertext").css('font-size');
     localStorage.setItem('twittertextscaled',twittertextscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

twittertextriptionrotation=localStorage.getItem('twittertextrotated');
twittertextriptionscaled=localStorage.getItem('twittertextscaled');

if(twittertextriptionrotation!=null){
    $('#twittertext').css('-webkit-transform', twittertextriptionrotation);
}
if(twittertextriptionscaled!=null){
    $('#twittertext').css('font-size', twittertextriptionscaled);
}

//messengertext
$('#messengertext').live("touchstart touchmove touchend", function(e){
    if(e.originalEvent.touches.length > 1)
        return;
});

var font = "50px"; var rotation = 0;
    $('#messengertext').live("gesturechange gestureend", function(e){
    var orig = e.originalEvent;

if(e.type == 'gesturechange'){
     //Save rotation
     messengertextrotated = $("#messengertext").css('-webkit-transform');
     localStorage.setItem('messengertextrotated',messengertextrotated);
     //Save Scale
     messengertextscaled = $("#messengertext").css('font-size');
     localStorage.setItem('messengertextscaled',messengertextscaled);
     //Change
    e.preventDefault();
    $(this).css("font-size", parseFloat(font) * orig.scale);
    $(this).css("-webkit-transform","rotate(" + ((parseFloat(rotation) + orig.rotation) % 360) + "deg)");
}
});

messengertextriptionrotation=localStorage.getItem('messengertextrotated');
messengertextriptionscaled=localStorage.getItem('messengertextscaled');

if(messengertextriptionrotation!=null){
    $('#messengertext').css('-webkit-transform', messengertextriptionrotation);
}
if(messengertextriptionscaled!=null){
    $('#messengertext').css('font-size', messengertextriptionscaled);
}







