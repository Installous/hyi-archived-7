

$(window).load(function () {
    //This first part of the code is just the plugin. Ignore it and scroll down!

    /**
     * jQuery Cookie plugin
     *
     * Copyright (c) 2010 Klaus Hartl (stilbuero.de)
     * Dual licensed under the MIT and GPL licenses:
     * http://www.opensource.org/licenses/mit-license.php
     * http://www.gnu.org/licenses/gpl.html
     *
     */
    jQuery.cookie = function (key, value, options) {

        // key and at least value given, set cookie...
        if (arguments.length > 1 && String(value) !== "[object Object]") {
            options = jQuery.extend({}, options);

            if (value === null || value === undefined) {
                options.expires = -1;
            }

            if (typeof options.expires === 'number') {
                var days = options.expires,
                    t = options.expires = new Date();
                t.setDate(t.getDate() + days);
            }

            value = String(value);

            return (document.cookie = [
            encodeURIComponent(key), '=',
            options.raw ? value : encodeURIComponent(value),
            options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
            options.path ? '; path=' + options.path : '',
            options.domain ? '; domain=' + options.domain : '',
            options.secure ? '; secure' : ''].join(''));
        }

        // key and possibly options given, get cookie...
        options = value || {};
        var result, decode = options.raw ? function (s) {
                return s;
            } : decodeURIComponent;
        return (result = new RegExp('(?:^|; )' + encodeURIComponent(key) + '=([^;]*)').exec(document.cookie)) ? decode(result[1]) : null;
    };

    //------------------------------------------------END of plugin!---------------------------------




    //------------------------------------------------Start Widget control---------------------------------

    $("#widgets").click(function () {
        closemenu();
        submenu();
      $(".mainwidgets").css('left', '0px');
      $(".mainwidgets").css('top', '-40px');
      $("#widgetclosemenu").css('top', '325px');
      $("#widgetone").css('top', '104px');
      $("#widgettwo").css('top', '140px');
      $("#widgetthree").css('top', '175px');
      $("#widgetfour").css('top', '210px');
      $("#widgetfive").css('top', '245px');
$("#widgetclosemenu,#widgetone,#widgettwo,#widgetthree,#widgetfour,#widgetfive,").css('left', '55px');
    });




function closepanels(){
   $("#settingspanel,#settingsclose").css('left', '-1000px');
}



$("#widgetclosemenu").click(function () { ///open menu to close widgets

        $("#themes").css('left', '-800px');
        $("#closewidgetclosemenu,#closewidget1,#closewidget2,#closewidget3,#closewidget4,#closewidget5").css('left', '0px');
        $("#closewidgetclosemenu").css('opacity', '0.7');
        $("#widgetfour,#widgetfive,#widgetclosemenu,#closewidget,#widgetfour").css('left', '-500px');
        $("#closewidget1,#closewidget2,#closewidget3,#closewidget4").css('opacity', '0.7');
        $("#closemenu,.settingspanelcolors,.fontcolors").css('left', '-500px');
        $("#widgetsmenu,#widgetthree,#widgetone,#widgettwo,#settingspanel,#settingsclose,.settingspanelfallingobjects").css('left', '-500px');
    });


$("#closewidgetclosemenu").click(function () {

$("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#calendar,#Time,#emailbuttontext,#messagebuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(5px)');

$("#weather").css('-webkit-transform', 'scale(1)');
        $("#themes").css('left', '-800px');
        $('#iframe').css("left", '500px');
        $("#widgetsmenu,#widgetone,#widgetfive,#widgetfive,#closewidgetclosemenu,#widgetfour").css('left', '-500px');
        $('#closewidget1,#closewidget2,#closewidget5,#closewidget3,#closewidget4').css("left", '-500px');
        $("#closemenu,#widgetsmenu,.settingspanelfallingobjects,#settingspanel,#settingsclose").css('left', '-500px');
        $(".settingspanelcolors,.fontcolors").css('left', '-500px');
    });



    $("#closewidget2").click(function () {
        removewidgetforecast();
        $("#messengertext,#phonetext,#date,#twittertext").css('-webkit-filter', 'blur(0px)');
$("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#Time,#emailbuttontext,#messagebuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(0px)');
 $('#iframe,#closemenu').css("left", '-500px');
        $('#widget2').css("display", 'none');

         
    });

    $("#closewidget3").click(function () {
               removeuni();
      var union = null;
        $("#messengertext,#phonetext,#date,#twittertext").css('-webkit-filter', 'blur(0px)');
$("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#Time,#emailbuttontext,#messagebuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(0px)');
  $('#iframe,#closemenu').css("left", '-500px');
        $('#widget3').css("display", 'none');
        //$.cookie('widget3', $("#widget3").css('display'),{ expires: 365,  path:'/'});
        //$.cookie('closewidget3', $("#closewidget3").css('left'),{ expires: 365,  path:'/'});
    });

    $("#closewidget4").click(function () {
        $("#themes,,#widgetsmenu,#closewidget4,#closewidget5,#widgetfour,#widgetfive,#closewidgetclosemenu,#widgetsmenu,#closewidget4,#closewidget3,#closewidget2,#closewidget1").css('left', '-800px');
        $('#iframe,#closemenu').css("left", '-500px');
        $('#widget4').css("display", 'none');
        $('.twittertweet').css('display', 'none');
        localStorage.setItem('twitterstart','no');
       $("#messengertext,#phonetext,#date,#twittertext").css('-webkit-filter', 'blur(0px)');
$("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#Time,#emailbuttontext,#messagebuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(0px)');
$("#weather").css('-webkit-transform', 'scale(1)');

    });

    $("#closewidget5").click(function () {

        $("#themes,,#widgetsmenu,#closewidget4,#closewidget5,#widgetfour,#widgetfive,#closewidgetclosemenu,#widgetsmenu,#closewidget4,#closewidget3,#closewidget2,#closewidget1").css('left', '-800px');
        $("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#date,#Time,#emailbuttontext,#messagebuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(0px)');
$("#weather").css('-webkit-transform', 'scale(1)');
removeanalog();

    });






    $("#closemenu").click(function () {

        $(".settingspanelcolors,.fontcolors,#closemenu").css('left', '-500px');
   
        $("#themes").css('left', '-800px');
        $('#closewidget4,#widgetfour,#closewidget,#widgetsmenu,#widgetthree,#widgetfive,#widgettwo,#widgetone,#widgetclosemenu,.settingspanelfallingobjects,#settingspanel,#settingsclose').css("left", '-500px');
        //$.cookie('closewidget', $("#closewidget").css('left'),{ expires: 365,  path:'/'},{ expires: 365,  path:'/'});
    });

  




  
$(function () {
        $("#twitterwidgetmove").draggable({
          stop: function (event, ui) {
          dleft=$(this).css('left');
            localStorage.setItem('twitterleft',dleft);
            dtop=$(this).css('top');
            localStorage.setItem('twittertop',dtop);
        }
    });
        $("#twitterwidgetmove").bind("drag", function (event, ui) {
            var div = $(".twittertweet");
            //div.text("Top: " + div.css("top") + ", Left: " + div.css("left"));
            div.css({
                top: ui.offset.top,
                left: ui.offset.left
            });
         


         });
});

   twitterleft=localStorage.getItem('twitterleft');

    twittertop=localStorage.getItem('twittertop');

    if(twitterleft!=null){ $('#twitterwidgetmove').css('left', twitterleft);}
    if(twitterleft!=null){ $('.twittertweet').css('left', twitterleft);}
    if(twittertop!=null){ $('#twitterwidgetmove').css('top', twittertop);}
    if(twittertop!=null){ $('.twittertweet').css('top', twittertop);}
    starttwitters=localStorage.getItem('twitterstart');
if(starttwitters=="yes"){
  $('.twittertweet').css('display', 'block');
}
if(starttwitters=="no"){
$('.twittertweet').css('display', 'none');
}


$(function () {
      $(".widgetmover").draggable({

      stop: function (event, ui) {
          dleft=$(this).css('left');
            localStorage.setItem('analogleft',dleft);
            dtop=$(this).css('top');
            localStorage.setItem('analogtop',dtop);
        }
    });
        $(".widgetmover").bind("drag", function (event, ui) {
            var div = $("#widget5");
            var div2 = $("#widget5attach");
            //div.text("Top: " + div.css("top") + ", Left: " + div.css("left"));
            div.css({
                top: ui.offset.top,
                left: ui.offset.left
            });
             div2.css({
                top: ui.offset.top,
                left: ui.offset.left
            });


         });
});

  analogleft=localStorage.getItem('analogleft');
  analogtop=localStorage.getItem('analogtop');

    if(analogleft!=null){ $('#widget5attach').css('left', analogleft);}
    if(analogleft!=null){ $('#widget5').css('left', analogleft);}
    if(analogtop!=null){ $('#widget5attach').css('top', analogtop);}
    if(analogtop!=null){ $('#widget5').css('top', analogtop);}
    if(analogleft!=null){ $('.widgetmover').css('left', analogleft);}
    if(analogleft!=null){ $('.widgetmover').css('top', analogtop);}






$(function () {
        $("#scroller").draggable({axis: 'y'});
        $("#scroller").bind("drag", function (event, ui) {
            var div = $(".newclass");
            //div.text("Top: " + div.css("top") + ", Left: " + div.css("left"));
            div.css({
                top: ui.offset.top,
                //left: ui.offset.left
            });


         });
});
$(function () {
        $("#scroller2").draggable({axis: 'y'});
        $("#scroller2").bind("drag", function (event, ui) {
            var div = $(".newclass2");
            //div.text("Top: " + div.css("top") + ", Left: " + div.css("left"));
            div.css({
                top: ui.offset.top,
                //left: ui.offset.left
            });


         });
});
$(function () {
        $("#scroller3").draggable({axis: 'y'});
        $("#scroller3").bind("drag", function (event, ui) {
            var div = $(".newclass3");
            //div.text("Top: " + div.css("top") + ", Left: " + div.css("left"));
            div.css({
                top: ui.offset.top,
                //left: ui.offset.left
            });


         });
});
    $("#calendar").draggable({
         containment: "#container6",
          scroll: false,
        stop: function (event, ui) {
          dleft=$(this).css('left');
            localStorage.setItem('calendarleft',dleft);
            dtop=$(this).css('top');
            localStorage.setItem('calendartop',dtop);
        }
    });

    calendarleft=localStorage.getItem('calendarleft');
    calendartop=localStorage.getItem('calendartop');
    if(calendarleft!=null){ $('#calendar').css('left', calendarleft);}
    if(calendartop!=null){ $('#calendar').css('top', calendartop);}




    //------------------------------------------------Make iframes Draggable---------------------------------


    $(function () {
        $("#iframefour").draggable();
        $("#iframefour").bind("drag", function (event, ui) {
            var div = $("#widget4");
            div.text("Top: " + div.css("top") + ", Left: " + div.css("left"));
            div.css({
                top: ui.offset.top,
                left: ui.offset.left
            });
            });
    });


   
    //------------------------------------------------End iframe Drag---------------------------------

    //------------------------------------------------Begin element choices---------------------------------


    $("#description").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            dleft=$(this).css('left');
            localStorage.setItem('descriptionleft',dleft);
            dtop=$(this).css('top');
            localStorage.setItem('descriptiontop',dtop);
           }
    });

    descriptionleft=localStorage.getItem('descriptionleft');
    descriptiontop=localStorage.getItem('descriptiontop');
    if(descriptionleft!=null){ $('#description').css('left', descriptionleft);}
    if(descriptiontop!=null){ $('#description').css('top', descriptiontop);}





    //// Yep lock apps

locker=localStorage.getItem('islocked');


///move icons to place

  tweetbotleft=localStorage.getItem('tweetbotleft');
    tweetbottop=localStorage.getItem('tweetbottop');
    if(tweetbotleft!=null){ $('#Tweetbot').css('left', tweetbotleft);}
    else{$('#Tweetbot').css('left',"-500px");}
    if(tweetbottop!=null){ $('#Tweetbot').css('top', tweetbottop);}
    if(tweetbotleft=="undefined"){$('#Tweetbot').css('left',"-500px");}
    if(tweetbotleft=="null"){$('#Tweetbot').css('left',"-500px");}

    phoneleft=localStorage.getItem('phoneleft');
    phonetop=localStorage.getItem('phonetop');
    if(phoneleft!=null){ $('#Phone').css('left', phoneleft);}
    else{$('#Phone').css('left',"-500px");}
    if(phonetop!=null){ $('#Phone').css('top', phonetop);}
    if(phoneleft=="undefined"){$('#Phone').css('left',"-500px");}
    if(phoneleft=="null"){$('#Phone').css('left',"-500px");}

    mailleft=localStorage.getItem('mailleft');
    mailtop=localStorage.getItem('mailtop');
    if(mailleft!=null){ $('#Mail').css('left', mailleft);}
    else{$('#Mail').css('left',"-500px");}
    if(mailtop!=null){ $('#Mail').css('top', mailtop);}
    if(mailleft=="undefined"){$('#Mail').css('left',"-500px");}
    if(mailleft=="null"){$('#Mail').css('left',"-500px");}

    facebookleft=localStorage.getItem('facebookleft');
    facebooktop=localStorage.getItem('facebooktop');
    if(facebookleft!=null){ $('#Facebook').css('left', facebookleft);}
    else{$('#Facebook').css('left',"-500px");}
    if(facebooktop!=null){ $('#Facebook').css('top', facebooktop);}
    if(facebookleft=="undefined"){$('#Facebook').css('left',"-500px");}
    if(facebookleft=="null"){$('#Facebook').css('left',"-500px");}

    timerleft=localStorage.getItem('timerleft');
    timertop=localStorage.getItem('timertop');
    if(timerleft!=null){ $('#Timer').css('left', timerleft);}
    else{$('#Timer').css('left',"-500px");}
    if(timertop!=null){ $('#Timer').css('top', timertop);}
    if(timerleft=="undefined"){$('#Timer').css('left',"-500px");}
    if(timerleft=="null"){$('#Timer').css('left',"-500px");}

    messagesleft=localStorage.getItem('messagesleft');
    messagestop=localStorage.getItem('messagestop');
    if(messagesleft!=null){ $('#Messages').css('left', messagesleft);}
    else{$('#Messages').css('left',"-500px");}
    if(messagestop!=null){ $('#Messages').css('top', messagestop);}
    if(messagesleft=="undefined"){$('#Messages').css('left',"-500px");}
    if(messagesleft=="null"){$('#Messages').css('left',"-500px");}

    lineleft=localStorage.getItem('lineleft');
    linetop=localStorage.getItem('linetop');
    if(lineleft!=null){ $('#Line').css('left', lineleft);}
    else{$('#Line').css('left',"-500px");}
    if(linetop!=null){ $('#Line').css('top', linetop);}
    if(lineleft=="undefined"){$('#Line').css('left',"-500px");}
    if(lineleft=="null"){$('#Line').css('left',"-500px");}

    instagramleft=localStorage.getItem('instagramleft');
    instagramtop=localStorage.getItem('instagramtop');
    if(instagramleft!=null){ $('#Instagram').css('left', instagramleft);}
    else{$('#Instagram').css('left',"-500px");}
    if(instagramtop!=null){ $('#Instagram').css('top', instagramtop);}
    if(instagramleft=="undefined"){$('#Instagram').css('left',"-500px");}
    if(instagramleft=="null"){$('#Instagram').css('left',"-500px");}


if(locker=="no"){


    $("#Tweetbot").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            tleft=$(this).css('left');
            localStorage.setItem('tweetbotleft',tleft);
            ttop=$(this).css('top');
            localStorage.setItem('tweetbottop',ttop);
           }
    });

  

b = "0";
$("#size1").click(function() {
b++
 $('#Tweetbot').css("left", '0px');
            tleft=$('#Tweetbot').css('left');
            localStorage.setItem('tweetbotleft',tleft);
if(b =="2"){
      $('#Tweetbot').css("left", '-400px');
      tleft=$('#Tweetbot').css('left');
      localStorage.setItem('tweetbotleft',tleft);
      b="0";
  }   
});

    $("#Phone").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            tleft=$(this).css('left');
            localStorage.setItem('phoneleft',tleft);
            ttop=$(this).css('top');
            localStorage.setItem('phonetop',ttop);
           }
    });



c = "0";
$("#size2").click(function() {
c++
 $('#Phone').css("left", '0px');
            tleft=$('#Phone').css('left');
            localStorage.setItem('phoneleft',tleft);
if(c =="2"){
      $('#Phone').css("left", '-400px');
      tleft=$('#Phone').css('left');
      localStorage.setItem('phoneleft',tleft);
      c="0";
  }   
});

    $("#Mail").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            tleft=$(this).css('left');
            localStorage.setItem('mailleft',tleft);
            ttop=$(this).css('top');
            localStorage.setItem('mailtop',ttop);
           }
    });



d = "0";
$("#size3").click(function() {
d++
 $('#Mail').css("left", '0px');
            tleft=$('#Mail').css('left');
            localStorage.setItem('mailleft',tleft);
if(d =="2"){
      $('#Mail').css("left", '-400px');
      tleft=$('#Mail').css('left');
      localStorage.setItem('mailleft',tleft);
      d="0";
  }   
});

    $("#Facebook").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            tleft=$(this).css('left');
            localStorage.setItem('facebookleft',tleft);
            ttop=$(this).css('top');
            localStorage.setItem('facebooktop',ttop);
           }
    });



e = "0";
$("#size4").click(function() {
e++
 $('#Facebook').css("left", '0px');
            tleft=$('#Facebook').css('left');
            localStorage.setItem('facebookleft',tleft);
if(e =="2"){
      $('#Facebook').css("left", '-400px');
      tleft=$('#Facebook').css('left');
      localStorage.setItem('facebookleft',tleft);
      e="0";
  }   
});

    $("#Timer").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            tleft=$(this).css('left');
            localStorage.setItem('timerleft',tleft);
            ttop=$(this).css('top');
            localStorage.setItem('timertop',ttop);
           }
    });



f = "0";
$("#size5").click(function() {
f++
 $('#Timer').css("left", '0px');
            tleft=$('#Timer').css('left');
            localStorage.setItem('timerleft',tleft);
if(f =="2"){
      $('#Timer').css("left", '-400px');
      tleft=$('#Timer').css('left');
      localStorage.setItem('timerleft',tleft);
      f="0";
  }   
});

    $("#Messages").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            tleft=$(this).css('left');
            localStorage.setItem('messagesleft',tleft);
            ttop=$(this).css('top');
            localStorage.setItem('messagestop',ttop);
           }
    });



g = "0";
$("#size6").click(function() {
g++
 $('#Messages').css("left", '0px');
            tleft=$('#Messages').css('left');
            localStorage.setItem('messagesleft',tleft);
if(g =="2"){
      $('#Messages').css("left", '-400px');
      tleft=$('#Messages').css('left');
      localStorage.setItem('messagesleft',tleft);
      g="0";
  }   
});

    $("#Instagram").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            tleft=$(this).css('left');
            localStorage.setItem('instagramleft',tleft);
            ttop=$(this).css('top');
            localStorage.setItem('instagramtop',ttop);
           }
    });



h = "0";
$("#size7").click(function() {
h++
 $('#Instagram').css("left", '0px');
            tleft=$('#Instagram').css('left');
            localStorage.setItem('instagramleft',tleft);
if(h =="2"){
      $('#Instagram').css("left", '-400px');
      tleft=$('#Instagram').css('left');
      localStorage.setItem('instagramleft',tleft);
      h="0";
  }   
});

    $("#Line").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            tleft=$(this).css('left');
            localStorage.setItem('lineleft',tleft);
            ttop=$(this).css('top');
            localStorage.setItem('linetop',ttop);
           }
    });



j = "0";
$("#size8").click(function() {
j++
 $('#Line').css("left", '0px');
            tleft=$('#Line').css('left');
            localStorage.setItem('lineleft',tleft);
if(j =="2"){
      $('#Line').css("left", '-400px');
      tleft=$('#Line').css('left');
      localStorage.setItem('lineleft',tleft);
      h="0";
  }   
});


}/// end if statement


    $("#humid").draggable({
         containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
            hleft=$(this).css('left');
            localStorage.setItem('humidleft',hleft);
            htop=$(this).css('top');
            localStorage.setItem('humidtop',htop);
            }
    });

    humidleft=localStorage.getItem('humidleft');
    humidtop=localStorage.getItem('humidtop');
    if(humidleft!=null){ $('#humid').css('left', humidleft);}
    if(humidtop!=null){ $('#humid').css('top', humidtop);}


    $("#low").draggable({
          scroll: false,
        stop: function (event, ui) {
             hleft=$(this).css('left');
            localStorage.setItem('lowleft',hleft);
            htop=$(this).css('top');
            localStorage.setItem('lowtop',htop);
            }
    });

    lowleft=localStorage.getItem('lowleft');
    lowtop=localStorage.getItem('lowtop');
    if(lowleft!=null){ $('#low').css('left', lowleft);}
    if(lowtop!=null){ $('#low').css('top', lowtop);}

    $("#high").draggable({
         containment: "#container3",
          scroll: false,
        stop: function (event, ui) {
         hleft=$(this).css('left');
            localStorage.setItem('highleft',hleft);
            htop=$(this).css('top');
            localStorage.setItem('hightop',htop);
            }
    });

    highleft=localStorage.getItem('highleft');
    hightop=localStorage.getItem('hightop');
    if(highleft!=null){ $('#high').css('left', highleft);}
    if(hightop!=null){ $('#high').css('top', hightop);}

    $("#degrees").draggable({
        containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
         hleft=$(this).css('left');
            localStorage.setItem('degreesleft',hleft);
            htop=$(this).css('top');
            localStorage.setItem('degreestop',htop);
            }
    });

    degreesleft=localStorage.getItem('degreesleft');
    degreestop=localStorage.getItem('degreestop');
    if(degreesleft!=null){ $('#degrees').css('left', degreesleft);}
    if(degreestop!=null){ $('#degrees').css('top', degreestop);}

    $("#iconoff").click(function () {
        $('#weatherIcon2').css("display", 'block');
        $.cookie('iconstate', $("#weatherIcon2").css('display'),{ expires: 365,  path:'/'});

    });

    $("#yourcity").draggable({
        containment: "#container2",
          scroll: false,
        stop: function (event, ui) {
         hleft=$(this).css('left');
            localStorage.setItem('yourcityleft',hleft);
            htop=$(this).css('top');
            localStorage.setItem('yourcitytop',htop);
            }
    });

    yourcityleft=localStorage.getItem('yourcityleft');
    yourcitytop=localStorage.getItem('yourcitytop');
    if(yourcityleft!=null){ $('#yourcity').css('left', yourcityleft);}
    if(yourcitytop!=null){ $('#yourcity').css('top', yourcitytop);}


    //------------------------------------------------Start fonts--------------------------------

    $("#setfont1").click(function () {
        $('#TextContainer').css("font-family", 'BU');
        fontstate= $("#TextContainer").css('font-family');
        localStorage.setItem('fontstate',fontstate);
        location.reload();
    });

 fontset=localStorage.getItem('fontstate');

 if(fontset!=null){$('#TextContainer').css("font-family", fontset);}
 if(fontset==null){$('#TextContainer').css("font-family", '-apple-system-font');} //reset
 if(fontset=="null"){$('#TextContainer').css("font-family", '-apple-system-font');} //upon reset


    $("#setfont2").click(function () {
        $('#TextContainer').css("font-family", 'CA');
        fontstate= $("#TextContainer").css('font-family');
        localStorage.setItem('fontstate',fontstate);
        location.reload();
    });


    $("#setfont3").click(function () {
        $('#TextContainer').css("font-family", 'JT');
        fontstate= $("#TextContainer").css('font-family');
        localStorage.setItem('fontstate',fontstate);
        location.reload();
    });

    $("#setfont4").click(function () {

        $('#TextContainer').css("font-family", 'TD');
       fontstate= $("#TextContainer").css('font-family');
        localStorage.setItem('fontstate',fontstate);
       location.reload();
    });


    $("#setfont5").click(function () {

        $('#TextContainer').css("font-family", 'BG');
        fontstate= $("#TextContainer").css('font-family');
        localStorage.setItem('fontstate',fontstate);
        location.reload();
    });


    $("#setfont6").click(function () {

        $('#TextContainer').css("font-family", 'WG');
       
       fontstate= $("#TextContainer").css('font-family');
        localStorage.setItem('fontstate',fontstate);
        location.reload();
    });

    $("#setfont7").click(function () {


        $('#TextContainer').css("font-family", 'SM');
        fontstate= $("#TextContainer").css('font-family');
        localStorage.setItem('fontstate',fontstate);
        location.reload();
    });



    $("#setfont8").click(function () {

        $('#TextContainer').css("font-family", 'NE');
       fontstate= $("#TextContainer").css('font-family');
        localStorage.setItem('fontstate',fontstate);
       location.reload();
    });



    $("#stockfont").click(function () {

        $('#TextContainer').css("font-family","-apple-system-font");

       fontstate= $("#TextContainer").css('font-family');
        localStorage.setItem('fontstate',fontstate);
       location.reload();
    });

    

    //------------------------------------------------Font colors--------------------------------




    //------------------------------------------------Start press buttons--------------------------------


var value=null;



$("#tempon").click(function () {
        $('#tempoff').css("left", '120px');
        $('#temp').css("display", 'none');
        state=$('#temp').css("display");
        toggle=$('#tempoff').css("left");
        localStorage.removeItem('degreesleft');
        localStorage.removeItem('degreesright');
        localStorage.setItem('tempstate',state);
        localStorage.setItem('buttoncook',toggle);
    });
        state=localStorage.getItem('tempstate');
        toggle=localStorage.getItem('buttoncook');
    if(state!=null){$('#temp').css('display',state);}
    else{$('#tempstate').css('display', 'none');}
    if(toggle!=null){$('#tempoff').css("left",toggle);}

$("#tempoff").click(function () {
        $('#tempoff').css("left", '95px');
        $('#temp').css("display", 'block');
        state=$('#temp').css("display");
        toggle=$('#tempoff').css("left");
        localStorage.removeItem('degreesleft');
        localStorage.removeItem('degreesright');
        localStorage.setItem('tempstate',state);
        localStorage.setItem('buttoncook',toggle);
   });
        state=localStorage.getItem('tempstate');
        toggle=localStorage.getItem('buttoncook');
    if(state!=null){$('#temp').css('display',state);}
    else{$('#tempstate').css('display', 'none');}
    if(toggle!=null){$('#tempoff').css("left",toggle);} 

    //------------------------------------------------icon-------------------------------

$("#iconon").click(function () {
        $('#iconoff').css("left", '120px');
        $('#weatherIcon2').css("display", 'none');
        state=$('#weatherIcon2').css("display");
        toggle=$('#iconoff').css("left");
        localStorage.removeItem('iconleft');
        localStorage.removeItem('iconright');
        localStorage.setItem('iconstate',state);
        localStorage.setItem('buttoncook1',toggle);
    });
        state=localStorage.getItem('iconstate');
        toggle=localStorage.getItem('buttoncook1');
    if(state!=null){$('#icon').css('display',state);}
    else{$('#iconstate').css('display', 'none');}
    if(toggle!=null){$('#iconoff').css("left",toggle);}

$("#iconoff").click(function () {
        $('#iconoff').css("left", '95px');
        $('#weatherIcon2').css("display", 'block');
        state=$('#weatherIcon2').css("display");
        toggle=$('#iconoff').css("left");
        localStorage.removeItem('iconleft');
        localStorage.removeItem('iconright');
        localStorage.setItem('iconstate',state);
        localStorage.setItem('buttoncook1',toggle);
   });
        state=localStorage.getItem('iconstate');
        toggle=localStorage.getItem('buttoncook1');
    if(state!=null){$('#weatherIcon2').css('display',state);}
    else{$('#iconstate').css('display', 'none');}
    if(toggle!=null){$('#iconoff').css("left",toggle);} 

    //------------------------------------------------city-------------------------------

$("#cityon").click(function () {
        $('#cityoff').css("left", '120px');
        $('#city').css("display", 'none');
        state=$('#city').css("display");
        toggle=$('#cityoff').css("left");
        localStorage.removeItem('cityleft');
        localStorage.removeItem('cityright');
        localStorage.setItem('citystate',state);
        localStorage.setItem('buttoncook2',toggle);
    });
        state=localStorage.getItem('citystate');
        toggle=localStorage.getItem('buttoncook2');
    if(state!=null){$('#city').css('display',state);}
    else{$('#citystate').css('display', 'none');}
    if(toggle!=null){$('#cityoff').css("left",toggle);}

$("#cityoff").click(function () {
        $('#cityoff').css("left", '95px');
        $('#city').css("display", 'block');
        state=$('#city').css("display");
        toggle=$('#cityoff').css("left");
        localStorage.removeItem('cityleft');
        localStorage.removeItem('cityright');
        localStorage.setItem('citystate',state);
        localStorage.setItem('buttoncook2',toggle);
   });
        state=localStorage.getItem('citystate');
        toggle=localStorage.getItem('buttoncook2');
    if(state!=null){$('#city').css('display',state);}
    else{$('#citystate').css('display', 'none');}
    if(toggle!=null){$('#cityoff').css("left",toggle);} 


    //------------------------------------------------humid-------------------------------

$("#humidon").click(function () {
        $('#humidoff').css("left", '120px');
        $('#humidity').css("display", 'none');
        state=$('#humidity').css("display");
        toggle=$('#humidoff').css("left");
        localStorage.removeItem('humidleft');
        localStorage.removeItem('humidright');
        localStorage.setItem('humidstate',state);
        localStorage.setItem('buttoncook3',toggle);
    });
        state=localStorage.getItem('humidstate');
        toggle=localStorage.getItem('buttoncook3');
    if(state!=null){$('#humidity').css('display',state);}
    else{$('#humidity').css('display', 'none');}
    if(toggle!=null){$('#humidoff').css("left",toggle);}

$("#humidoff").click(function () {
        $('#humidoff').css("left", '95px');
        $('#humidity').css("display", 'block');
        state=$('#humidity').css("display");
        toggle=$('#humidoff').css("left");
        localStorage.removeItem('humidleft');
        localStorage.removeItem('humidright');
        localStorage.setItem('humidstate',state);
        localStorage.setItem('buttoncook3',toggle);
   });
        state=localStorage.getItem('humidstate');
        toggle=localStorage.getItem('buttoncook3');
    if(state!=null){$('#humidity').css('display',state);}
    else{$('#humidity').css('display', 'none');}
    if(toggle!=null){$('#humidoff').css("left",toggle);} 
    //------------------------------------------------desc-------------------------------

$("#descon").click(function () {
        $('#descoff').css("left", '120px');
        $('#desc').css("display", 'none');
        state=$('#desc').css("display");
        toggle=$('#descoff').css("left");
        localStorage.removeItem('descleft');
        localStorage.removeItem('descright');
        localStorage.setItem('descstate',state);
        localStorage.setItem('buttoncook4',toggle);
    });
        state=localStorage.getItem('descstate');
        toggle=localStorage.getItem('buttoncook4');
    if(state!=null){$('#desc').css('display',state);}
    else{$('#desc').css('display', 'none');}
    if(toggle!=null){$('#descoff').css("left",toggle);}

$("#descoff").click(function () {
        $('#descoff').css("left", '95px');
        $('#desc').css("display", 'block');
        state=$('#desc').css("display");
        toggle=$('#descoff').css("left");
        localStorage.removeItem('descleft');
        localStorage.removeItem('descright');
        localStorage.setItem('descstate',state);
        localStorage.setItem('buttoncook4',toggle);
   });
        state=localStorage.getItem('descstate');
        toggle=localStorage.getItem('buttoncook4');
    if(state!=null){$('#desc').css('display',state);}
    else{$('#desc').css('display', 'none');}
    if(toggle!=null){$('#descoff').css("left",toggle);} 
    //------------------------------------------------city-------------------------------
$("#dateon").click(function () {
        $('#dateoff').css("left", '120px');
        $('#date').css("visibility", 'hidden');
        state=$('#date').css("visibility");
        toggle=$('#dateoff').css("left");
        localStorage.removeItem('dateleft');
        localStorage.removeItem('dateright');
        localStorage.setItem('datestate',state);
        localStorage.setItem('buttoncook5',toggle);
    });
        state=localStorage.getItem('datestate');
        toggle=localStorage.getItem('buttoncook5');
    if(state!=null){$('#date').css('visibility',state);}
    else{$('#date').css('visibility', 'hidden');}
    if(toggle!=null){$('#dateoff').css("left",toggle);}

$("#dateoff").click(function () {
        $('#dateoff').css("left", '95px');
        $('#date').css("visibility", 'visible');
        state=$('#date').css("visibility");
        toggle=$('#dateoff').css("left");
        localStorage.removeItem('dateleft');
        localStorage.removeItem('dateright');
        localStorage.setItem('datestate',state);
        localStorage.setItem('buttoncook5',toggle);
   });
        state=localStorage.getItem('datestate');
        toggle=localStorage.getItem('buttoncook5');
    if(state!=null){$('#date').css('visibility',state);}
    else{$('#date').css('visibility', 'hidden');}
    if(toggle!=null){$('#dateoff').css("left",toggle);} 
    //------------------------------------------------lo------------------------------

$("#lowon").click(function () {
        $('#lowoff').css("left", '120px');
        $('#lo').css("display", 'none');
        state=$('#lo').css("display");
        toggle=$('#lowoff').css("left");
        localStorage.removeItem('lowleft');
        localStorage.removeItem('lowright');
        localStorage.setItem('lowstate',state);
        localStorage.setItem('buttoncook6',toggle);
    });
        state=localStorage.getItem('lowstate');
        toggle=localStorage.getItem('buttoncook6');
    if(state!=null){$('#lo').css('display',state);}
    else{$('#lo').css('display', 'none');}
    if(toggle!=null){$('#lowoff').css("left",toggle);}

$("#lowoff").click(function () {
        $('#lowoff').css("left", '95px');
        $('#lo').css("display", 'block');
        state=$('#lo').css("display");
        toggle=$('#lowoff').css("left");
        localStorage.removeItem('lowleft');
        localStorage.removeItem('lowright');
        localStorage.setItem('lowstate',state);
        localStorage.setItem('buttoncook6',toggle);
   });
        state=localStorage.getItem('lowstate');
        toggle=localStorage.getItem('buttoncook6');
    if(state!=null){$('#lo').css('display',state);}
    else{$('#lo').css('display', 'none');}
    if(toggle!=null){$('#lowoff').css("left",toggle);} 
    //-----------------------------------------------high---------------------------

$("#highon").click(function () {
        $('#highoff').css("left", '120px');
        $('#hi').css("display", 'none');
        state=$('#hi').css("display");
        toggle=$('#highoff').css("left");
        localStorage.removeItem('highleft');
        localStorage.removeItem('highright');
        localStorage.setItem('highstate',state);
        localStorage.setItem('buttoncook7',toggle);
    });
        state=localStorage.getItem('highstate');
        toggle=localStorage.getItem('buttoncook7');
    if(state!=null){$('#hi').css('display',state);}
    else{$('#hi').css('display', 'none');}
    if(toggle!=null){$('#highoff').css("left",toggle);}

$("#highoff").click(function () {
        $('#highoff').css("left", '95px');
        $('#hi').css("display", 'block');
        state=$('#hi').css("display");
        toggle=$('#highoff').css("left");
        localStorage.removeItem('highleft');
        localStorage.removeItem('highright');
        localStorage.setItem('highstate',state);
        localStorage.setItem('buttoncook7',toggle);
   });
        state=localStorage.getItem('highstate');
        toggle=localStorage.getItem('buttoncook7');
    if(state!=null){$('#hi').css('display',state);}
    else{$('#hi').css('display', 'none');}
    if(toggle!=null){$('#highoff').css("left",toggle);} 
    //-----------------------------------------------Time---------------------------





    $("#timeoff").click(function () {
        $('#timeoff').css("left", '95px');
        $('#Time').css("left", '100px');
        state=$('#Time').css("left");
        toggle=$('#timeoff').css("left");
        localStorage.removeItem('timeleft');
        localStorage.removeItem('timeright');
        localStorage.setItem('timestate',state);
        localStorage.setItem('buttoncook8',toggle);
    });
        state=localStorage.getItem('timestate');
        toggle=localStorage.getItem('buttoncook8');
    if(state!=null){$('#Time').css('left',state);}
    else{$('#Time').css('left', '-800px');}
    if(state=="null"){$('#Time').css('left', '-800px');}
    if(toggle!=null){$('#timeoff').css("left",toggle);}

    $("#timeon").click(function () {
        $('#timeoff').css("left", '120px');
        $('#Time').css("left", '-800px');
        state=$('#Time').css("left");
        toggle=$('#timeoff').css("left");
        localStorage.removeItem('timeleft');
        localStorage.removeItem('timeright');
        localStorage.setItem('timestate',state);
        localStorage.setItem('buttoncook8',toggle);
   });
        state=localStorage.getItem('timestate');
        toggle=localStorage.getItem('buttoncook8');
    if(state!=null){$('#Time').css('left',state);}
    else{$('#Time').css('left', '-800px');}
    if(toggle!=null){$('#timeoff').css("left",toggle);} 


    //------------------------------------------------city-------------------------------

    $("#Time").draggable({
        containment: "#container4",
          scroll: false,
        stop: function (event, ui) {
         hleft=$(this).css('left');
            localStorage.setItem('timeleft',hleft);
            htop=$(this).css('top');
            localStorage.setItem('timetop',htop);
            }
    });

    timeleft=localStorage.getItem('timeleft');
    timetop=localStorage.getItem('timetop');
    if(timeleft!=null){ $('#Time').css('left', timeleft);}
    if(timetop!=null){ $('#Time').css('top', timetop);}


    $("#timetext").draggable({
        containment: "#container4",
          scroll: false,
        stop: function (event, ui) {
       hleft=$(this).css('left');
            localStorage.setItem('timetextleft',hleft);
            htop=$(this).css('top');
            localStorage.setItem('timetexttop',htop);
            }
    });

    timetextleft=localStorage.getItem('timetextleft');
    timetexttop=localStorage.getItem('timetexttop');
    if(timetextleft!=null){ $('#timetext').css('left', timetextleft);}
    if(timetexttop!=null){ $('#timetext').css('top', timetexttop);}



    $("#updatetext").draggable({
        containment: "#container4",
          scroll: false,
        stop: function (event, ui) {
         hleft=$(this).css('left');
            localStorage.setItem('updatetextleft',hleft);
            htop=$(this).css('top');
            localStorage.setItem('updatetexttop',htop);
            }
    });

    updatetextleft=localStorage.getItem('updatetextleft');
    updatetexttop=localStorage.getItem('updatetexttop');
    if(updatetextleft!=null){ $('#updatetext').css('left', updatetextleft);}
    if(updatetexttop!=null){ $('#updatetext').css('top', updatetexttop);}


    $("#unlockbuttontext").draggable({
        containment: "#container4",
          scroll: false,
        stop: function (event, ui) {
            hleft=$(this).css('left');
            localStorage.setItem('unlockbuttontextleft',hleft);
            htop=$(this).css('top');
            localStorage.setItem('unlockbuttontexttop',htop);
            }
    });

    unlockbuttontextleft=localStorage.getItem('unlockbuttontextleft');
    unlockbuttontexttop=localStorage.getItem('unlockbuttontexttop');
    if(unlockbuttontextleft!=null){ $('#unlockbuttontext').css('left', unlockbuttontextleft);}
    if(unlockbuttontexttop!=null){ $('#unlockbuttontext').css('top', unlockbuttontexttop);}


        $("#messagebuttontext").draggable({
        containment: "#container4",
          scroll: false,
        stop: function (event, ui) {
            hleft=$(this).css('left');
            localStorage.setItem('messagebuttontextleft',hleft);
            htop=$(this).css('top');
            localStorage.setItem('messagebuttontexttop',htop);
            }
    });

    messagebuttontextleft=localStorage.getItem('messagebuttontextleft');
    messagebuttontexttop=localStorage.getItem('messagebuttontexttop');
    if(messagebuttontextleft!=null){ $('#messagebuttontext').css('left', messagebuttontextleft);}
    if(messagebuttontexttop!=null){ $('#messagebuttontext').css('top', messagebuttontexttop);}



        $("#emailbuttontext").draggable({
        containment: "#container4",
          scroll: false,
        stop: function (event, ui) {
            hleft=$(this).css('left');
            localStorage.setItem('emailbuttontextleft',hleft);
            htop=$(this).css('top');
            localStorage.setItem('emailbuttontexttop',htop);
            }
    });

    emailbuttontextleft=localStorage.getItem('emailbuttontextleft');
    emailbuttontexttop=localStorage.getItem('emailbuttontexttop');
    if(emailbuttontextleft!=null){ $('#emailbuttontext').css('left', emailbuttontextleft);}
    if(emailbuttontexttop!=null){ $('#emailbuttontext').css('top', emailbuttontexttop);}

        $("#phonebuttontext").draggable({
        containment: "#container4",
          scroll: false,
        stop: function (event, ui) {
            hleft=$(this).css('left');
            localStorage.setItem('phonebuttontextleft',hleft);
            htop=$(this).css('top');
            localStorage.setItem('phonebuttontexttop',htop);
            }
    });

    phonebuttontextleft=localStorage.getItem('phonebuttontextleft');
    phonebuttontexttop=localStorage.getItem('phonebuttontexttop');
    if(phonebuttontextleft!=null){ $('#phonebuttontext').css('left', phonebuttontextleft);}
    if(phonebuttontexttop!=null){ $('#phonebuttontext').css('top', phonebuttontexttop);}

        $("#twitterbuttontext").draggable({
        containment: "#container4",
          scroll: false,
        stop: function (event, ui) {
            hleft=$(this).css('left');
            localStorage.setItem('twitterbuttontextleft',hleft);
            htop=$(this).css('top');
            localStorage.setItem('twitterbuttontexttop',htop);
            }
    });

    twitterbuttontextleft=localStorage.getItem('twitterbuttontextleft');
    twitterbuttontexttop=localStorage.getItem('twitterbuttontexttop');
    if(twitterbuttontextleft!=null){ $('#twitterbuttontext').css('left', twitterbuttontextleft);}
    if(twitterbuttontexttop!=null){ $('#twitterbuttontext').css('top', twitterbuttontexttop);}

        $("#messengerbuttontext").draggable({
        containment: "#container4",
          scroll: false,
        stop: function (event, ui) {
            hleft=$(this).css('left');
            localStorage.setItem('messengerbuttontextleft',hleft);
            htop=$(this).css('top');
            localStorage.setItem('messengerbuttontexttop',htop);
            }
    });

    messengerbuttontextleft=localStorage.getItem('messengerbuttontextleft');
    messengerbuttontexttop=localStorage.getItem('messengerbuttontexttop');
    if(messengerbuttontextleft!=null){ $('#messengerbuttontext').css('left', messengerbuttontextleft);}
    if(messengerbuttontexttop!=null){ $('#messengerbuttontext').css('top', messengerbuttontexttop);}


    

    $("#weatherIcon2").draggable({
        containment: "#container5",
          scroll: false,
        stop: function (event, ui) {
             hleft=$(this).css('left');
            localStorage.setItem('weatherIcon2left',hleft);
            htop=$(this).css('top');
            localStorage.setItem('weatherIcon2top',htop);
            }
    });

    weatherIcon2left=localStorage.getItem('weatherIcon2left');
    weatherIcon2top=localStorage.getItem('weatherIcon2top');
    if(weatherIcon2left!=null){ $('#weatherIcon2').css('left', weatherIcon2left);}
    if(weatherIcon2top!=null){ $('#weatherIcon2').css('top', weatherIcon2top);}
});