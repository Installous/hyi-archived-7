
// Font Menu

$("#fonts").click(function () {
closemenu();
submenu();

    $(".settingspanelfonts").css('left', '4px');
    $(".fonton").css('left', '155px');
    $(".fonton").css('top', '50px');
    $(".settingspanelfonts").css('top', '-80px');
});

function submenu(){

$("#weather").css('-webkit-transform', 'scale(1.2)');
$("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#date,#Time,#emailbuttontext,#messagebuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(5px)');
$("#settingspanel").css('left', '0px');
$("#settingspanel").css('left', '40px');
$("#settingsclose").css('left', '148px');
}

//font size

$("#iconsgo").click(function () {
    closemenu();
    submenu();
$("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#date,#Time,#emailbuttontext,#messagebuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(5px)');
$("#weather").css('-webkit-transform', 'scale(1.2)');


    $("#settingspanel").css('left', '0px');
    $("#presstext").css('left', '-130px');
    $(".iconsgo").css('left', '132px');
    $(".iconsgo").css('top', '60px');
});


//backgrounds
$("#bg").click(function () {
    closemenu();
    submenu();
 $("#bubble").css('left', '70px');
 $("#bubble").css('top', '315px');
    $("#bgwall").css('left', '4px');
    $("#nobg").css('left', '0px');
    $("#bgwall").css('top', '80px');
});







// Weather ENTRY.

$("#settings").click(function () {
   closemenu();
  submenu();
$(".usersettings").css('top', '-60px');
      $(".usersettings").css({
        left:50
    });
 
   
 

});



// reset button

$("#reload").click(function () {
    
 //remove everything
localStorage.clear();
location.reload();



});

// On off switches weather

$("#settingsmain").click(function () {
   closemenu();
  submenu();

    $(".settingspanel").css('left', '5px');
    $(".settingspanel").css('top', '-80px');
    $(".onandoff").css('left', '0px');
    $(".onandoff").css('top', '-80px');


      $("#menu2button").css('display', 'block');
});




// close button

