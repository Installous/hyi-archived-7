function save(which){
	var savename=prompt("Enter a name to call this save.","");//name
	$( '#save'+which ).html(savename);//change button
	var store="save"+which// unique name
	localStorage.setItem(store,savename);//save to storage
	getsettings(which);// save current settings pass number
}

function getsettings(number){
	/////background
	background=localStorage.getItem("userbg");//find original
	bg="save"+number+"background"; //set unique name
	localStorage.setItem(bg,background); //set to storage
	////end background

	////Description top/left
	 desclold=localStorage.getItem('descriptionleft');
 	 desctold=localStorage.getItem('descriptiontop');
 	 descl="save"+number+"descl";
 	 desct="save"+number+"desct";
 	 localStorage.setItem(descl,desclold);
 	 localStorage.setItem(desct,desctold);
 	 ////Description End Top/Left

 	 /////Description rotate/scale
 	 descrold=localStorage.getItem('descrotated');
     descsold=localStorage.getItem('descscaled');
 	 descr="save"+number+"descr";
 	 descs="save"+number+"descs";
 	 localStorage.setItem(descr,descrold);
 	 localStorage.setItem(descs,descsold);
 	 ///End description

 	 ////humid top/left
	 humidlold=localStorage.getItem('humidleft');
 	 humidtold=localStorage.getItem('humidtop');
 	 humidl="save"+number+"humidl";
 	 humidt="save"+number+"humidt";
 	 localStorage.setItem(humidl,humidlold);
 	 localStorage.setItem(humidt,humidtold);
 	 ////humid End Top/Left

 	 /////humidity rotate/scale
 	 humidrold=localStorage.getItem('humidityrotated');
     humidsold=localStorage.getItem('humidityscaled');
 	 humidityr="save"+number+"humidityr";
 	 humiditys="save"+number+"humiditys";
 	 localStorage.setItem(humidityr,humidrold);
 	 localStorage.setItem(humiditys,humidsold);
 	 ///End humidity

 	  ////low top/left
	 lowlold=localStorage.getItem('lowleft');
 	 lowtold=localStorage.getItem('lowtop');
 	 lowl="save"+number+"lowl";
 	 lowt="save"+number+"lowt";
 	 localStorage.setItem(lowl,lowlold);
 	 localStorage.setItem(lowt,lowtold);
 	 ////low End Top/Left

 	 /////lo rotate/scale
 	 lorold=localStorage.getItem('lorotated');
     losold=localStorage.getItem('loscaled');
 	 lor="save"+number+"lor";
 	 los="save"+number+"los";
 	 localStorage.setItem(lor,lorold);
 	 localStorage.setItem(los,losold);
 	 ///End lo

 	  ////high top/left
     highlold=localStorage.getItem('highleft');
     hightold=localStorage.getItem('hightop');
     highl="save"+number+"highl";
     hight="save"+number+"hight";
     localStorage.setItem(highl,highlold);
     localStorage.setItem(hight,hightold);
     ////high End Top/Left


     /////hi rotate/scale
     hirold=localStorage.getItem('hirotated');
     hisold=localStorage.getItem('hiscaled');
     hir="save"+number+"hir";
     his="save"+number+"his";
     localStorage.setItem(hir,hirold);
     localStorage.setItem(his,hisold);
     ///End hi

      ////degrees top/left
     degreeslold=localStorage.getItem('degreesleft');
     degreestold=localStorage.getItem('degreestop');
     degreesl="save"+number+"degreesl";
     degreest="save"+number+"degreest";
     localStorage.setItem(degreesl,degreeslold);
     localStorage.setItem(degreest,degreestold);
     ////degrees End Top/Left

      /////temp rotate/scale
     temprold=localStorage.getItem('temprotated');
     tempsold=localStorage.getItem('tempscaled');
     tempr="save"+number+"tempr";
     temps="save"+number+"temps";
     localStorage.setItem(tempr,temprold);
     localStorage.setItem(temps,tempsold);
     ///End temp

      ////yourcity top/left
     yourcitylold=localStorage.getItem('yourcityleft');
     yourcitytold=localStorage.getItem('yourcitytop');
     yourcityl="save"+number+"yourcityl";
     yourcityt="save"+number+"yourcityt";
     localStorage.setItem(yourcityl,yourcitylold);
     localStorage.setItem(yourcityt,yourcitytold);
     ////yourcity End Top/Left

      /////city rotate/scale
     cityrold=localStorage.getItem('cityrotated');
     citysold=localStorage.getItem('cityscaled');
     cityr="save"+number+"cityr";
     citys="save"+number+"citys";
     localStorage.setItem(cityr,cityrold);
     localStorage.setItem(citys,citysold);
     ///End city

           ////time top/left
     timelold=localStorage.getItem('timeleft');
     timetold=localStorage.getItem('timetop');
     timel="save"+number+"timel";
     timet="save"+number+"timet";
     localStorage.setItem(timel,timelold);
     localStorage.setItem(timet,timetold);
     ////time End Top/Left

           /////clock rotate/scale
     clockrold=localStorage.getItem('clockrotated');
     clocksold=localStorage.getItem('clockscaled');
     clockr="save"+number+"clockr";
     clocks="save"+number+"clocks";
     localStorage.setItem(clockr,clockrold);
     localStorage.setItem(clocks,clocksold);
     ///End clock

           ////timetext top/left
     timetextlold=localStorage.getItem('timetextleft');
     timetexttold=localStorage.getItem('timetexttop');
     timetextl="save"+number+"timetextl";
     timetextt="save"+number+"timetextt";
     localStorage.setItem(timetextl,timetextlold);
     localStorage.setItem(timetextt,timetexttold);
     ////timetext End Top/Left

                /////ttext rotate/scale
     ttextrold=localStorage.getItem('ttextrotated');
     ttextsold=localStorage.getItem('ttextscaled');
     ttextr="save"+number+"ttextr";
     ttexts="save"+number+"ttexts";
     localStorage.setItem(ttextr,ttextrold);
     localStorage.setItem(ttexts,ttextsold);
     ///End ttext

                ////updatetext top/left
     updatetextlold=localStorage.getItem('updatetextleft');
     updatetexttold=localStorage.getItem('updatetexttop');
     updatetextl="save"+number+"updatetextl";
     updatetextt="save"+number+"updatetextt";
     localStorage.setItem(updatetextl,updatetextlold);
     localStorage.setItem(updatetextt,updatetexttold);
     ////updatetext End Top/Left

                     /////utext rotate/scale
     utextrold=localStorage.getItem('utextrotated');
     utextsold=localStorage.getItem('utextscaled');
     utextr="save"+number+"utextr";
     utexts="save"+number+"utexts";
     localStorage.setItem(utextr,utextrold);
     localStorage.setItem(utexts,utextsold);
     ///End utext

                     ////unlockbuttontext top/left
     unlockbuttontextlold=localStorage.getItem('unlockbuttontextleft');
     unlockbuttontexttold=localStorage.getItem('unlockbuttontexttop');
     unlockbuttontextl="save"+number+"unlockbuttontextl";
     unlockbuttontextt="save"+number+"unlockbuttontextt";
     localStorage.setItem(unlockbuttontextl,unlockbuttontextlold);
     localStorage.setItem(unlockbuttontextt,unlockbuttontexttold);
     ////unlockbuttontext End Top/Left

                          /////untext rotate/scale
     untextrold=localStorage.getItem('untextrotated');
     untextsold=localStorage.getItem('untextscaled');
     untextr="save"+number+"untextr";
     untexts="save"+number+"untexts";
     localStorage.setItem(untextr,untextrold);
     localStorage.setItem(untexts,untextsold);
     ///End untext

                          ////messagebuttontext top/left
     messagebuttontextlold=localStorage.getItem('messagebuttontextleft');
     messagebuttontexttold=localStorage.getItem('messagebuttontexttop');
     messagebuttontextl="save"+number+"messagebuttontextl";
     messagebuttontextt="save"+number+"messagebuttontextt";
     localStorage.setItem(messagebuttontextl,messagebuttontextlold);
     localStorage.setItem(messagebuttontextt,messagebuttontexttold);
     ////messagebuttontext End Top/Left

                               /////messagetext rotate/scale
     messagetextrold=localStorage.getItem('messagetextrotated');
     messagetextsold=localStorage.getItem('messagetextscaled');
     messagetextr="save"+number+"messagetextr";
     messagetexts="save"+number+"messagetexts";
     localStorage.setItem(messagetextr,messagetextrold);
     localStorage.setItem(messagetexts,messagetextsold);
     ///End messagetext

                               ////emailbuttontext top/left
     emailbuttontextlold=localStorage.getItem('emailbuttontextleft');
     emailbuttontexttold=localStorage.getItem('emailbuttontexttop');
     emailbuttontextl="save"+number+"emailbuttontextl";
     emailbuttontextt="save"+number+"emailbuttontextt";
     localStorage.setItem(emailbuttontextl,emailbuttontextlold);
     localStorage.setItem(emailbuttontextt,emailbuttontexttold);
     ////emailbuttontext End Top/Left

                                    /////emailtext rotate/scale
     emailtextrold=localStorage.getItem('emailtextrotated');
     emailtextsold=localStorage.getItem('emailtextscaled');
     emailtextr="save"+number+"emailtextr";
     emailtexts="save"+number+"emailtexts";
     localStorage.setItem(emailtextr,emailtextrold);
     localStorage.setItem(emailtexts,emailtextsold);
     ///End emailtext

                                    ////weatherIcon2 top/left
     weatherIcon2lold=localStorage.getItem('weatherIcon2left');
     weatherIcon2told=localStorage.getItem('weatherIcon2top');
     weatherIcon2l="save"+number+"weatherIcon2l";
     weatherIcon2t="save"+number+"weatherIcon2t";
     localStorage.setItem(weatherIcon2l,weatherIcon2lold);
     localStorage.setItem(weatherIcon2t,weatherIcon2told);
     ////weatherIcon2 End Top/Left

                                         /////weatherIcon2 rotate/scale
     weatherIcon2rold=localStorage.getItem('weatherIcon2rotated');
     weatherIcon2sold=localStorage.getItem('weatherIcon2scaled');
     weatherIcon2r="save"+number+"weatherIcon2r";
     weatherIcon2s="save"+number+"weatherIcon2s";
     localStorage.setItem(weatherIcon2r,weatherIcon2rold);
     localStorage.setItem(weatherIcon2s,weatherIcon2sold);
     ///End weatherIcon2

                                         ////calendar top/left
     calendarlold=localStorage.getItem('calendarleft');
     calendartold=localStorage.getItem('calendartop');
     calendarl="save"+number+"calendarl";
     calendart="save"+number+"calendart";
     localStorage.setItem(calendarl,calendarlold);
     localStorage.setItem(calendart,calendartold);
     ////calendar End Top/Left

                                              /////calendar rotate/scale
     calendarrold=localStorage.getItem('calendarrotated');
     calendarsold=localStorage.getItem('calendarscaled');
     calendarr="save"+number+"calendarr";
     calendars="save"+number+"calendars";
     localStorage.setItem(calendarr,calendarrold);
     localStorage.setItem(calendars,calendarsold);
     ///End calendar

     ////color
     //shadowold=localStorage.getItem('shadows');
     horold=localStorage.getItem('horizontal');
     verold=localStorage.getItem('vertical');
     blurold=localStorage.getItem('blur');
     ccold=localStorage.getItem('picker');
          //shadow1="save"+number+"shadow1";
          hor1="save"+number+"hor1";
          ver1="save"+number+"ver1";
          blur1="save"+number+"blur1";
          cc1="save"+number+"cc1";
      //localStorage.setItem(shadow1,shadowold);
      localStorage.setItem(hor1,horold);
      localStorage.setItem(ver1,verold);
      localStorage.setItem(blur1,blurold);
      localStorage.setItem(cc1,ccold);
      //end color

      ///text color
       colorold=localStorage.getItem('bgcolor');
       newcolor="save"+number+"maincolor";
       localStorage.setItem(newcolor,colorold);

       /////////////////Start switches/////////////
       tempswitchold=localStorage.getItem('tempstate');
       tempswitch="save"+number+"tempswitch";
       localStorage.setItem(tempswitch,tempswitchold);

       temptoggleold=localStorage.getItem('buttoncook');
       temptoggle="save"+number+"temptoggle";
       localStorage.setItem(temptoggle,temptoggleold);
       //
       iconswitchold=localStorage.getItem('iconstate');
       iconswitch="save"+number+"iconswitch";
       localStorage.setItem(iconswitch,iconswitchold);

       icontoggleold=localStorage.getItem('buttoncook1');
       icontoggle="save"+number+"icontoggle";
       localStorage.setItem(icontoggle,icontoggleold);
       //
       cityswitchold=localStorage.getItem('citystate');
       cityswitch="save"+number+"cityswitch";
       localStorage.setItem(cityswitch,cityswitchold);

       citytoggleold=localStorage.getItem('buttoncook2');
       citytoggle="save"+number+"citytoggle";
       localStorage.setItem(citytoggle,citytoggleold);
       //
       humidswitchold=localStorage.getItem('humidstate');
       humidswitch="save"+number+"humidswitch";
       localStorage.setItem(humidswitch,humidswitchold);

       humidtoggleold=localStorage.getItem('buttoncook3');
       humidtoggle="save"+number+"humidtoggle";
       localStorage.setItem(humidtoggle,humidtoggleold);
       //
       descswitchold=localStorage.getItem('descstate');
       descswitch="save"+number+"descswitch";
       localStorage.setItem(descswitch,descswitchold);

       desctoggleold=localStorage.getItem('buttoncook4');
       desctoggle="save"+number+"desctoggle";
       localStorage.setItem(desctoggle,desctoggleold);
       //
       dateswitchold=localStorage.getItem('datestate');
       dateswitch="save"+number+"dateswitch";
       localStorage.setItem(dateswitch,dateswitchold);

       datetoggleold=localStorage.getItem('buttoncook5');
       datetoggle="save"+number+"datetoggle";
       localStorage.setItem(datetoggle,datetoggleold);
       //
       lowswitchold=localStorage.getItem('lowstate');
       lowswitch="save"+number+"lowswitch";
       localStorage.setItem(lowswitch,lowswitchold);

       lowtoggleold=localStorage.getItem('buttoncook6');
       lowtoggle="save"+number+"lowtoggle";
       localStorage.setItem(lowtoggle,lowtoggleold);
       //
       highswitchold=localStorage.getItem('highstate');
       highswitch="save"+number+"highswitch";
       localStorage.setItem(highswitch,highswitchold);

       hightoggleold=localStorage.getItem('buttoncook7');
       hightoggle="save"+number+"hightoggle";
       localStorage.setItem(hightoggle,hightoggleold);
       //
       timeswitchold=localStorage.getItem('timestate');
       timeswitch="save"+number+"timeswitch";
       localStorage.setItem(timeswitch,timeswitchold);

       timetoggleold=localStorage.getItem('buttoncook8');
       timetoggle="save"+number+"timetoggle";
       localStorage.setItem(timetoggle,timetoggleold);
       //
       texttimeoffswitchold=localStorage.getItem('timetexton');
       texttimeoffswitch="save"+number+"texttimeoffswitch";
       localStorage.setItem(texttimeoffswitch,texttimeoffswitchold);

       texttimeofftoggleold=localStorage.getItem('buttoncook9');
       texttimeofftoggle="save"+number+"texttimeofftoggle";
       localStorage.setItem(texttimeofftoggle,texttimeofftoggleold);
       //
       updatetimeoffswitchold=localStorage.getItem('updatetexton');
       updatetimeoffswitch="save"+number+"updatetimeoffswitch";
       localStorage.setItem(updatetimeoffswitch,updatetimeoffswitchold);

       updatetimeofftoggleold=localStorage.getItem('buttoncook10');
       updatetimeofftoggle="save"+number+"updatetimeofftoggle";
       localStorage.setItem(updatetimeofftoggle,updatetimeofftoggleold);
       //
       unlockbuttonoffswitchold=localStorage.getItem('unlockbuttonon');
       unlockbuttonoffswitch="save"+number+"unlockbuttonoffswitch";
       localStorage.setItem(unlockbuttonoffswitch,unlockbuttonoffswitchold);

       unlockbuttonofftoggleold=localStorage.getItem('buttoncook11');
       unlockbuttonofftoggle="save"+number+"unlockbuttonofftoggle";
       localStorage.setItem(unlockbuttonofftoggle,unlockbuttonofftoggleold);
       //
       messagebuttonoffswitchold=localStorage.getItem('messagebuttonon');
       messagebuttonoffswitch="save"+number+"messagebuttonoffswitch";
       localStorage.setItem(messagebuttonoffswitch,messagebuttonoffswitchold);

       messagebuttonofftoggleold=localStorage.getItem('buttoncook12');
       messagebuttonofftoggle="save"+number+"messagebuttonofftoggle";
       localStorage.setItem(messagebuttonofftoggle,messagebuttonofftoggleold);
       //
       emailbuttonoffswitchold=localStorage.getItem('emailbuttonon');
       emailbuttonoffswitch="save"+number+"emailbuttonoffswitch";
       localStorage.setItem(emailbuttonoffswitch,emailbuttonoffswitchold);

       emailbuttonofftoggleold=localStorage.getItem('buttoncook13');
       emailbuttonofftoggle="save"+number+"emailbuttonofftoggle";
       localStorage.setItem(emailbuttonofftoggle,emailbuttonofftoggleold);
       //

       iconssetold=localStorage.getItem("iconset");
       iconsset="save"+number+"iconsset";
       localStorage.setItem(iconsset,iconssetold);
       //
       widgetonold=localStorage.getItem("widget1switch");
       widgetonnew="save"+number+"widget1";
       localStorage.setItem(widgetonnew,widgetonold);

       widgetonelold=localStorage.getItem("widgetoneleft");
       widgetonel="save"+number+"widget1L";
       localStorage.setItem(widgetonel,widgetonelold);

       widgetonetold=localStorage.getItem("widgetonetop");
       widgetonet="save"+number+"widget1T";
       localStorage.setItem(widgetonet,widgetonetold);
       //
        widget2old=localStorage.getItem("widget2save");
       widget2new="save"+number+"widget2";
       localStorage.setItem(widget2new,widget2old);

       widget2lold=localStorage.getItem("widget2left");
       widget2l="save"+number+"widget2L";
       localStorage.setItem(widget2l,widget2lold);

       widget2told=localStorage.getItem("widget2top");
       widget2t="save"+number+"widget2T";
       localStorage.setItem(widget2t,widget2told);
       //
       widget3old=localStorage.getItem("widget3save");
       widget3new="save"+number+"widget3";
       localStorage.setItem(widget3new,widget3old);
       //
      fshadowold=localStorage.getItem("fullshadow");
       fshadownew="save"+number+"FullShadow";
       localStorage.setItem(fshadownew,fshadowold);
       //

       GLS=localStorage.getItem("lockscreenchosen");
       GLSnew="save"+number+"GroovyLock";
       localStorage.setItem(GLSnew,GLS);
       //

       tweetbotlold=localStorage.getItem("tweetbotleft");
       tweetbotl="save"+number+"tweetbotL";
       localStorage.setItem(tweetbotl,tweetbotlold);

       tweetbottold=localStorage.getItem("tweetbottop");
       tweetbott="save"+number+"tweetbotT";
       localStorage.setItem(tweetbott,tweetbottold);
       //
       phonelold=localStorage.getItem("phoneleft");
       phonel="save"+number+"phoneL";
       localStorage.setItem(phonel,phonelold);

       phonetold=localStorage.getItem("phonetop");
       phonet="save"+number+"phoneT";
       localStorage.setItem(phonet,phonetold);
       //
       maillold=localStorage.getItem("mailleft");
       maill="save"+number+"mailL";
       localStorage.setItem(maill,maillold);

       mailtold=localStorage.getItem("mailtop");
       mailt="save"+number+"mailT";
       localStorage.setItem(mailt,mailtold);
       //
       facebooklold=localStorage.getItem("facebookleft");
       facebookl="save"+number+"facebookL";
       localStorage.setItem(facebookl,facebooklold);

       facebooktold=localStorage.getItem("facebooktop");
       facebookt="save"+number+"facebookT";
       localStorage.setItem(facebookt,facebooktold);
       //
       timerlold=localStorage.getItem("timerleft");
       timerl="save"+number+"timerL";
       localStorage.setItem(timerl,timerlold);

       timertold=localStorage.getItem("timertop");
       timert="save"+number+"timerT";
       localStorage.setItem(timert,timertold);
       //
       messageslold=localStorage.getItem("messagesleft");
       messagesl="save"+number+"messagesL";
       localStorage.setItem(messagesl,messageslold);

       messagestold=localStorage.getItem("messagestop");
       messagest="save"+number+"messagesT";
       localStorage.setItem(messagest,messagestold);
       //
       instagramlold=localStorage.getItem("instagramleft");
       instagraml="save"+number+"instagramL";
       localStorage.setItem(instagraml,instagramlold);

       instagramtold=localStorage.getItem("instagramtop");
       instagramt="save"+number+"instagramT";
       localStorage.setItem(instagramt,instagramtold);
       //
       linelold=localStorage.getItem("lineleft");
       linel="save"+number+"lineL";
       localStorage.setItem(linel,linelold);

       linetold=localStorage.getItem("linetop");
       linet="save"+number+"lineT";
       localStorage.setItem(linet,linetold);
       //
      fonttold=localStorage.getItem("fontstate");
       fontt="save"+number+"Font";
       localStorage.setItem(fontt,fonttold);
       //
       wbold=localStorage.getItem("checked");
       wb="save"+number+"Winterboard";
       localStorage.setItem(wb,wbold);
       //
       tweetbotrolds=localStorage.getItem('Tweetbotrotated');
       tweetbotrs="save"+number+"Tweetbotrotated";
       localStorage.setItem(tweetbotrs,tweetbotrolds);

       tweetbotsolds=localStorage.getItem('Tweetbotscaled');
       tweetbotss="save"+number+"Tweetbotscaled";
       localStorage.setItem(tweetbotss,tweetbotsolds);

       phonerolds=localStorage.getItem('Phonerotated');
       phoners="save"+number+"Phonerotated";
       localStorage.setItem(phoners,phonerolds);

       phonesolds=localStorage.getItem('Phonescaled');
       phoness="save"+number+"Phonescaled";
       localStorage.setItem(phoness,phonesolds);

       mailrolds=localStorage.getItem('Mailrotated');
       mailrs="save"+number+"Mailrotated";
       localStorage.setItem(mailrs,mailrolds);

       mailsolds=localStorage.getItem('Mailscaled');
       mailss="save"+number+"Mailscaled";
       localStorage.setItem(mailss,mailsolds);

       facebookrolds=localStorage.getItem('Facebookrotated');
       facebookrs="save"+number+"Facebookrotated";
       localStorage.setItem(facebookrs,facebookrolds);

       facebooksolds=localStorage.getItem('Facebookscaled');
       facebookss="save"+number+"Facebookscaled";
       localStorage.setItem(facebookss,facebooksolds);

       timerrolds=localStorage.getItem('Timerrotated');
       timerrs="save"+number+"Timerrotated";
       localStorage.setItem(timerrs,timerrolds);

       timersolds=localStorage.getItem('Timerscaled');
       timerss="save"+number+"Timerscaled";
       localStorage.setItem(timerss,timersolds);

       messagesrolds=localStorage.getItem('Messagesrotated');
       messagesrs="save"+number+"Messagesrotated";
       localStorage.setItem(messagesrs,messagesrolds);

       messagessolds=localStorage.getItem('Messagesscaled');
       messagesss="save"+number+"Messagesscaled";
       localStorage.setItem(messagesss,messagessolds);

       instagramrolds=localStorage.getItem('Instagramrotated');
       instagramrs="save"+number+"Instagramrotated";
       localStorage.setItem(instagramrs,instagramrolds);

       instagramsolds=localStorage.getItem('Instagramscaled');
       instagramss="save"+number+"Instagramscaled";
       localStorage.setItem(instagramss,instagramsolds);

       linerolds=localStorage.getItem('Linerotated');
       liners="save"+number+"Linerotated";
       localStorage.setItem(liners,linerolds);

       linesolds=localStorage.getItem('Linescaled');
       liness="save"+number+"Linescaled";
       localStorage.setItem(liness,linesolds);

       stockolds=localStorage.getItem('iconstates');
       stocks="save"+number+"StockIcon";
       localStorage.setItem(stocks,stockolds);

       unlocktextolds=localStorage.getItem('unlocktexttext');
       unlocktext="save"+number+"Unlocktext";
       localStorage.setItem(unlocktext,unlocktextolds);


       twittersaveold=localStorage.getItem("twitterstart");
       twittersave="save"+number+"twittersave";
       localStorage.setItem(twittersave,twittersaveold);

       twitterlold=localStorage.getItem("twitterleft");
       twitterle="save"+number+"twitterleftsave";
       localStorage.setItem(twitterle,twitterlold);

       twittertold=localStorage.getItem("twittertop");
       twitterte="save"+number+"twittertopsave";
       localStorage.setItem(twitterte,twittertold);

/////////
       phonestold=localStorage.getItem("phonebuttontexttop");
       phoneste="save"+number+"phonestopsaves";
       localStorage.setItem(phoneste,phonestold);

       phoneslold=localStorage.getItem("phonebuttontextleft");
       phonesle="save"+number+"phonesleftsave";
       localStorage.setItem(phonesle,phoneslold);

       phonesrold=localStorage.getItem("phonetextrotated");
       phonesre="save"+number+"phonesrotatesave";
       localStorage.setItem(phonesre,phonesrold);

       phonesscold=localStorage.getItem("phonetextscaled");
       phonessce="save"+number+"phonesscalesave";
       localStorage.setItem(phonessce,phonesscold);

       ////
       twitterstold=localStorage.getItem("twitterbuttontexttop");
       twitterste="save"+number+"twitterstopsaves";
       localStorage.setItem(twitterste,twitterstold);

       twitterslold=localStorage.getItem("twitterbuttontextleft");
       twittersle="save"+number+"twittersleftsave";
       localStorage.setItem(twittersle,twitterslold);

       twittersrold=localStorage.getItem("twittertextrotated");
       twittersre="save"+number+"twittersrotatesave";
       localStorage.setItem(twittersre,twittersrold);

       twittersscold=localStorage.getItem("twittertextscaled");
       twitterssce="save"+number+"twittersscalesave";
       localStorage.setItem(twitterssce,twittersscold);
       //
       messagesstold=localStorage.getItem("messengerbuttontexttop");
       messagesste="save"+number+"messengerstopsaves";
       localStorage.setItem(messagesste,messagesstold);

       messagesslold=localStorage.getItem("messengerbuttontextleft");
       messagessle="save"+number+"messengersleftsave";
       localStorage.setItem(messagessle,messagesslold);

       messagessrold=localStorage.getItem("messengertextrotated");
       messagessre="save"+number+"messengersrotatesave";
       localStorage.setItem(messagessre,messagessrold);

       messagessscold=localStorage.getItem("messengertextscaled");
       messagesssce="save"+number+"messengersscalesave";
       localStorage.setItem(messagesssce,messagessscold);















}



//////////Save button name
savedonename=localStorage.getItem('saveone');
savedtwoname=localStorage.getItem('savetwo');
savedthreename=localStorage.getItem('savethree');
savedfourname=localStorage.getItem('savefour');
savedfivename=localStorage.getItem('savefive');

if(savedonename!=null){replacesavenames('saveone',savedonename);}
if(savedtwoname!=null){replacesavenames('savetwo',savedtwoname);}
if(savedthreename!=null){replacesavenames('savethree',savedthreename);}
if(savedfourname!=null){replacesavenames('savefour',savedfourname);}
if(savedfivename!=null){replacesavenames('savefive',savedfivename);}

function replacesavenames(name,local){
$( '#'+ name ).html(local);
}
//////////End button save name