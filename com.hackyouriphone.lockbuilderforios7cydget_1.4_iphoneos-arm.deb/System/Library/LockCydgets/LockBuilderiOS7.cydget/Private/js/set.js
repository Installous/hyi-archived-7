

function setlayout(which){ /// initiated by apply button
	/////background
	background="save"+which+"background" //get unique name
	background=localStorage.getItem(background); //get storage name
	localStorage.setItem("userbg",background); //store new
if(background!=null){ //change and overwrite original
$('#overlay').css('background-image', 'url(' + background + ')');
}
	////end background

	////start description left
	descriptionleft="save"+which+"descl";
	descriptionleft=localStorage.getItem(descriptionleft);
	localStorage.setItem("descriptionleft",descriptionleft);
if(descriptionleft!=null){ //change and overwrite original
$('#description').css('left', descriptionleft);
}

     //top
	descriptiontop="save"+which+"desct";
	descriptiontop=localStorage.getItem(descriptiontop);
	localStorage.setItem("descriptiontop",descriptiontop);
if(descriptiontop!=null){ //change and overwrite original
$('#description').css('top', descriptiontop);
}
	///end description
	///start desc rotate
	descriptionrotate="save"+which+"descr";
	descriptionrotate=localStorage.getItem(descriptionrotate);
	localStorage.setItem("descrotated",descriptionrotate);
if(descriptionrotate!=null){ //change and overwrite original
$('#desc').css('-webkit-transform', descriptionrotate);
}
	//start scale
	descriptionscaled="save"+which+"descs";
	descriptionscaled=localStorage.getItem(descriptionscaled);
	localStorage.setItem("descscaled",descriptionscaled);
if(descriptionscaled!=null){ //change and overwrite original
$('#desc').css('font-size', descriptionscaled);
}

	////start humid left
	humidleft="save"+which+"humidl";
	humidleft=localStorage.getItem(humidleft);
	localStorage.setItem("humidleft",humidleft);
if(humidleft!=null){ //change and overwrite original
$('#humid').css('left', humidleft);
}

     //top
	humidtop="save"+which+"humidt";
	humidtop=localStorage.getItem(humidtop);
	localStorage.setItem("humidtop",humidtop);
if(humidtop!=null){ //change and overwrite original
$('#humid').css('top', humidtop);
}

	///start humidity rotate
	humidityrotate="save"+which+"humidityr";
	humidityrotate=localStorage.getItem(humidityrotate);
	localStorage.setItem("humidityrotated",humidityrotate);
if(humidityrotate!=null){ //change and overwrite original
$('#humidity').css('-webkit-transform', humidityrotate);
}
	//start scale
	humidityscaled="save"+which+"humiditys";
	humidityscaled=localStorage.getItem(humidityscaled);
	localStorage.setItem("humidityscaled",humidityscaled);
if(humidityscaled!=null){ //change and overwrite original
$('#humidity').css('font-size', humidityscaled);
}

	////start low left
	lowleft="save"+which+"lowl";
	lowleft=localStorage.getItem(lowleft);
	localStorage.setItem("lowleft",lowleft);
if(lowleft!=null){ //change and overwrite original
$('#low').css('left', lowleft);
}

     //top
	lowtop="save"+which+"lowt";
	lowtop=localStorage.getItem(lowtop);
	localStorage.setItem("lowtop",lowtop);
if(lowtop!=null){ //change and overwrite original
$('#low').css('top', lowtop);
}
	///end low

 	///start lo rotate
	lorotate="save"+which+"lor";
	lorotate=localStorage.getItem(lorotate);
	localStorage.setItem("lorotated",lorotate);
if(lorotate!=null){ //change and overwrite original
$('#lo').css('-webkit-transform', lorotate);
}
	//start scale
	loscaled="save"+which+"los";
	loscaled=localStorage.getItem(loscaled);
	localStorage.setItem("loscaled",loscaled);
if(loscaled!=null){ //change and overwrite original
$('#lo').css('font-size', loscaled);
}

    ////start high left
    highleft="save"+which+"highl";
    highleft=localStorage.getItem(highleft);
    localStorage.setItem("highleft",highleft);
if(highleft!=null){ //change and overwrite original
$('#high').css('left', highleft);
}

     //top
    hightop="save"+which+"hight";
    hightop=localStorage.getItem(hightop);
    localStorage.setItem("hightop",hightop);
if(hightop!=null){ //change and overwrite original
$('#high').css('top', hightop);
}
    ///end high

        ///start hi rotate
    hirotate="save"+which+"hir";
    hirotate=localStorage.getItem(hirotate);
    localStorage.setItem("hirotated",hirotate);
if(hirotate!=null){ //change and overwrite original
$('#hi').css('-webkit-transform', hirotate);
}
    //start scale
    hiscaled="save"+which+"his";
    hiscaled=localStorage.getItem(hiscaled);
    localStorage.setItem("hiscaled",hiscaled);
if(hiscaled!=null){ //change and overwrite original
$('#hi').css('font-size', hiscaled);
}

    ////start degrees left
    degreesleft="save"+which+"degreesl";
    degreesleft=localStorage.getItem(degreesleft);
    localStorage.setItem("degreesleft",degreesleft);
if(degreesleft!=null){ //change and overwrite original
$('#degrees').css('left', degreesleft);
}

     //top
    degreestop="save"+which+"degreest";
    degreestop=localStorage.getItem(degreestop);
    localStorage.setItem("degreestop",degreestop);
if(degreestop!=null){ //change and overwrite original
$('#degrees').css('top', degreestop);
}

    ///start temp rotate
    temprotate="save"+which+"tempr";
    temprotate=localStorage.getItem(temprotate);
    localStorage.setItem("temprotated",temprotate);
if(temprotate!=null){ //change and overwrite original
$('#temp').css('-webkit-transform', temprotate);
}
    //start scale
    tempscaled="save"+which+"temps";
    tempscaled=localStorage.getItem(tempscaled);
    localStorage.setItem("tempscaled",tempscaled);
if(tempscaled!=null){ //change and overwrite original
$('#temp').css('font-size', tempscaled);
}


    ////start yourcity left
    yourcityleft="save"+which+"yourcityl";
    yourcityleft=localStorage.getItem(yourcityleft);
    localStorage.setItem("yourcityleft",yourcityleft);
if(yourcityleft!=null){ //change and overwrite original
$('#yourcity').css('left', yourcityleft);
}

     //top
    yourcitytop="save"+which+"yourcityt";
    yourcitytop=localStorage.getItem(yourcitytop);
    localStorage.setItem("yourcitytop",yourcitytop);
if(yourcitytop!=null){ //change and overwrite original
$('#yourcity').css('top', yourcitytop);
}

    ///start city rotate
    cityrotate="save"+which+"cityr";
    cityrotate=localStorage.getItem(cityrotate);
    localStorage.setItem("cityrotated",cityrotate);
if(cityrotate!=null){ //change and overwrite original
$('#city').css('-webkit-transform', cityrotate);
}
    //start scale
    cityscaled="save"+which+"citys";
    cityscaled=localStorage.getItem(cityscaled);
    localStorage.setItem("cityscaled",cityscaled);
if(cityscaled!=null){ //change and overwrite original
$('#city').css('font-size', cityscaled);
}


    ////start time left
    timeleft="save"+which+"timel";
    timeleft=localStorage.getItem(timeleft);
    localStorage.setItem("timeleft",timeleft);
if(timeleft!=null){ //change and overwrite original
$('#Time').css('left', timeleft);
}

     //top
    timetop="save"+which+"timet";
    timetop=localStorage.getItem(timetop);
    localStorage.setItem("timetop",timetop);
if(timetop!=null){ //change and overwrite original
$('#Time').css('top', timetop);
}

    ///start clock rotate
    clockrotate="save"+which+"clockr";
    clockrotate=localStorage.getItem(clockrotate);
    localStorage.setItem("clockrotated",clockrotate);
if(clockrotate!=null){ //change and overwrite original
$('#clock').css('-webkit-transform', clockrotate);
}
    //start scale
    clockscaled="save"+which+"clocks";
    clockscaled=localStorage.getItem(clockscaled);
    localStorage.setItem("clockscaled",clockscaled);
if(clockscaled!=null){ //change and overwrite original
$('#clock').css('font-size', clockscaled);
}

    ////start timetext left
    timetextleft="save"+which+"timetextl";
    timetextleft=localStorage.getItem(timetextleft);
    localStorage.setItem("timetextleft",timetextleft);
if(timetextleft!=null){ //change and overwrite original
$('#timetext').css('left', timetextleft);
}

     //top
    timetexttop="save"+which+"timetextt";
    timetexttop=localStorage.getItem(timetexttop);
    localStorage.setItem("timetexttop",timetexttop);
if(timetexttop!=null){ //change and overwrite original
$('#timetext').css('top', timetexttop);
}

    ///start ttext rotate
    ttextrotate="save"+which+"ttextr";
    ttextrotate=localStorage.getItem(ttextrotate);
    localStorage.setItem("ttextrotated",ttextrotate);
if(ttextrotate!=null){ //change and overwrite original
$('#ttext').css('-webkit-transform', ttextrotate);
}
    //start scale
    ttextscaled="save"+which+"ttexts";
    ttextscaled=localStorage.getItem(ttextscaled);
    localStorage.setItem("ttextscaled",ttextscaled);
if(ttextscaled!=null){ //change and overwrite original
$('#ttext').css('font-size', ttextscaled);
}

    ////start updatetext left
    updatetextleft="save"+which+"updatetextl";
    updatetextleft=localStorage.getItem(updatetextleft);
    localStorage.setItem("updatetextleft",updatetextleft);
if(updatetextleft!=null){ //change and overwrite original
$('#updatetext').css('left', updatetextleft);
}

     //top
    updatetexttop="save"+which+"updatetextt";
    updatetexttop=localStorage.getItem(updatetexttop);
    localStorage.setItem("updatetexttop",updatetexttop);
if(updatetexttop!=null){ //change and overwrite original
$('#updatetext').css('top', updatetexttop);
}

    ///start utext rotate
    utextrotate="save"+which+"utextr";
    utextrotate=localStorage.getItem(utextrotate);
    localStorage.setItem("utextrotated",utextrotate);
if(utextrotate!=null){ //change and overwrite original
$('#utext').css('-webkit-transform', utextrotate);
}
    //start scale
    utextscaled="save"+which+"utexts";
    utextscaled=localStorage.getItem(utextscaled);
    localStorage.setItem("utextscaled",utextscaled);
if(utextscaled!=null){ //change and overwrite original
$('#utext').css('font-size', utextscaled);
}

    ////start unlockbuttontext left
    unlockbuttontextleft="save"+which+"unlockbuttontextl";
    unlockbuttontextleft=localStorage.getItem(unlockbuttontextleft);
    localStorage.setItem("unlockbuttontextleft",unlockbuttontextleft);
if(unlockbuttontextleft!=null){ //change and overwrite original
$('#unlockbuttontext').css('left', unlockbuttontextleft);
}

     //top
    unlockbuttontexttop="save"+which+"unlockbuttontextt";
    unlockbuttontexttop=localStorage.getItem(unlockbuttontexttop);
    localStorage.setItem("unlockbuttontexttop",unlockbuttontexttop);
if(unlockbuttontexttop!=null){ //change and overwrite original
$('#unlockbuttontext').css('top', unlockbuttontexttop);
}

    ///start untext rotate
    untextrotate="save"+which+"untextr";
    untextrotate=localStorage.getItem(untextrotate);
    localStorage.setItem("untextrotated",untextrotate);
if(untextrotate!=null){ //change and overwrite original
$('#untext').css('-webkit-transform', untextrotate);
}
    //start scale
    untextscaled="save"+which+"untexts";
    untextscaled=localStorage.getItem(untextscaled);
    localStorage.setItem("untextscaled",untextscaled);
if(untextscaled!=null){ //change and overwrite original
$('#untext').css('font-size', untextscaled);
}

    ////start messagebuttontext left
    messagebuttontextleft="save"+which+"messagebuttontextl";
    messagebuttontextleft=localStorage.getItem(messagebuttontextleft);
    localStorage.setItem("messagebuttontextleft",messagebuttontextleft);
if(messagebuttontextleft!=null){ //change and overwrite original
$('#messagebuttontext').css('left', messagebuttontextleft);
}

     //top
    messagebuttontexttop="save"+which+"messagebuttontextt";
    messagebuttontexttop=localStorage.getItem(messagebuttontexttop);
    localStorage.setItem("messagebuttontexttop",messagebuttontexttop);
if(messagebuttontexttop!=null){ //change and overwrite original
$('#messagebuttontext').css('top', messagebuttontexttop);
}

    ///start messagetext rotate
    messagetextrotate="save"+which+"messagetextr";
    messagetextrotate=localStorage.getItem(messagetextrotate);
    localStorage.setItem("messagetextrotated",messagetextrotate);
if(messagetextrotate!=null){ //change and overwrite original
$('#messagetext').css('-webkit-transform', messagetextrotate);
}
    //start scale
    messagetextscaled="save"+which+"messagetexts";
    messagetextscaled=localStorage.getItem(messagetextscaled);
    localStorage.setItem("messagetextscaled",messagetextscaled);
if(messagetextscaled!=null){ //change and overwrite original
$('#messagetext').css('font-size', messagetextscaled);
}

    ////start emailbuttontext left
    emailbuttontextleft="save"+which+"emailbuttontextl";
    emailbuttontextleft=localStorage.getItem(emailbuttontextleft);
    localStorage.setItem("emailbuttontextleft",emailbuttontextleft);
if(emailbuttontextleft!=null){ //change and overwrite original
$('#emailbuttontext').css('left', emailbuttontextleft);
}

     //top
    emailbuttontexttop="save"+which+"emailbuttontextt";
    emailbuttontexttop=localStorage.getItem(emailbuttontexttop);
    localStorage.setItem("emailbuttontexttop",emailbuttontexttop);
if(emailbuttontexttop!=null){ //change and overwrite original
$('#emailbuttontext').css('top', emailbuttontexttop);
}

    ///start emailtext rotate
    emailtextrotate="save"+which+"emailtextr";
    emailtextrotate=localStorage.getItem(emailtextrotate);
    localStorage.setItem("emailtextrotated",emailtextrotate);
if(emailtextrotate!=null){ //change and overwrite original
$('#emailtext').css('-webkit-transform', emailtextrotate);
}
    //start scale
    emailtextscaled="save"+which+"emailtexts";
    emailtextscaled=localStorage.getItem(emailtextscaled);
    localStorage.setItem("emailtextscaled",emailtextscaled);
if(emailtextscaled!=null){ //change and overwrite original
$('#emailtext').css('font-size', emailtextscaled);
}

    ////start weatherIcon2 left
    weatherIcon2left="save"+which+"weatherIcon2l";
    weatherIcon2left=localStorage.getItem(weatherIcon2left);
    localStorage.setItem("weatherIcon2left",weatherIcon2left);
if(weatherIcon2left!=null){ //change and overwrite original
$('#weatherIcon2').css('left', weatherIcon2left);
}

     //top
    weatherIcon2top="save"+which+"weatherIcon2t";
    weatherIcon2top=localStorage.getItem(weatherIcon2top);
    localStorage.setItem("weatherIcon2top",weatherIcon2top);
if(weatherIcon2top!=null){ //change and overwrite original
$('#weatherIcon2').css('top', weatherIcon2top);
}

    ///start weatherIcon2 rotate
    weatherIcon2rotate="save"+which+"weatherIcon2r";
    weatherIcon2rotate=localStorage.getItem(weatherIcon2rotate);
    localStorage.setItem("weatherIcon2rotated",weatherIcon2rotate);
if(weatherIcon2rotate!=null){ //change and overwrite original
$('#weatherIcon2').css('-webkit-transform', weatherIcon2rotate);
}
    //start scale
    weatherIcon2scaled="save"+which+"weatherIcon2s";
    weatherIcon2scaled=localStorage.getItem(weatherIcon2scaled);
    localStorage.setItem("weatherIcon2scaled",weatherIcon2scaled);
if(weatherIcon2scaled!=null){ //change and overwrite original
$('#weatherIcon2').css('width', weatherIcon2scaled);
}

    ////start calendar left
    calendarleft="save"+which+"calendarl";
    calendarleft=localStorage.getItem(calendarleft);
    localStorage.setItem("calendarleft",calendarleft);
if(calendarleft!=null){ //change and overwrite original
$('#calendar').css('left', calendarleft);
}

     //top
    calendartop="save"+which+"calendart";
    calendartop=localStorage.getItem(calendartop);
    localStorage.setItem("calendartop",calendartop);
if(calendartop!=null){ //change and overwrite original
$('#calendar').css('top', calendartop);
}

    ///start calendar rotate
    calendarrotate="save"+which+"calendarr";
    calendarrotate=localStorage.getItem(calendarrotate);
    localStorage.setItem("calendarrotated",calendarrotate);
if(calendarrotate!=null){ //change and overwrite original
$('#calendar').css('-webkit-transform', calendarrotate);
}
    //start scale
    calendarscaled="save"+which+"calendars";
    calendarscaled=localStorage.getItem(calendarscaled);
    localStorage.setItem("calendarscaled",calendarscaled);
if(calendarscaled!=null){ //change and overwrite original
$('#calendar').css('font-size', calendarscaled);
}


       //shadow1="save"+which+"shadow1";
          hor1="save"+which+"hor1";
          ver1="save"+which+"ver1";
          blur1="save"+which+"blur1";
          cc1="save"+which+"cc1";
          //shadow1=localStorage.getItem(shadow1);
          hor1=localStorage.getItem(hor1);
          ver1=localStorage.getItem(ver1);
          blur1=localStorage.getItem(blur1);
          cc1=localStorage.getItem(cc1);

    localStorage.setItem('horizontal',hor1);
    localStorage.setItem('vertical',ver1);
    localStorage.setItem('blur',blur1);
    localStorage.setItem('picker',cc1);

var hor1 = hor1 + "px";
var ver1 = ver1+"px";
var blur1 = blur1+"px";
var cc1 = cc1;

document.getElementById("TextContainer").style.textShadow= hor1+" "+ver1+" "+blur1+" "+cc1;

///main color
newcolor="save"+which+"maincolor";
newcolor=localStorage.getItem(newcolor);
localStorage.setItem('bgcolor',newcolor);

if(newcolor!=null){
	//location.reload();
	colorchange=localStorage.getItem('bgcolor');
	$('#TextContainer').css('color', colorchange);
	 $('#Time').css('color', colorchange);
      $('#clock').css('color', colorchange);
}
///end main color
newtemp="save"+which+"tempswitch";
newtemp=localStorage.getItem(newtemp);
localStorage.setItem('tempstate',newtemp);

newtemptoggle="save"+which+"temptoggle";
newtemptoggle=localStorage.getItem(newtemptoggle);
localStorage.setItem('buttoncook',newtemptoggle);
//
newicon="save"+which+"iconswitch";
newicon=localStorage.getItem(newicon);
localStorage.setItem('iconstate',newicon);

newicontoggle="save"+which+"icontoggle";
newicontoggle=localStorage.getItem(newicontoggle);
localStorage.setItem('buttoncook1',newicontoggle);
//
newcity="save"+which+"cityswitch";
newcity=localStorage.getItem(newcity);
localStorage.setItem('citystate',newcity);

newcitytoggle="save"+which+"citytoggle";
newcitytoggle=localStorage.getItem(newcitytoggle);
localStorage.setItem('buttoncook2',newcitytoggle);
//
newhumid="save"+which+"humidswitch";
newhumid=localStorage.getItem(newhumid);
localStorage.setItem('humidstate',newhumid);

newhumidtoggle="save"+which+"humidtoggle";
newhumidtoggle=localStorage.getItem(newhumidtoggle);
localStorage.setItem('buttoncook3',newhumidtoggle);
//
newdesc="save"+which+"descswitch";
newdesc=localStorage.getItem(newdesc);
localStorage.setItem('descstate',newdesc);

newdesctoggle="save"+which+"desctoggle";
newdesctoggle=localStorage.getItem(newdesctoggle);
localStorage.setItem('buttoncook4',newdesctoggle);
//
newdate="save"+which+"dateswitch";
newdate=localStorage.getItem(newdate);
localStorage.setItem('datestate',newdate);

newdatetoggle="save"+which+"datetoggle";
newdatetoggle=localStorage.getItem(newdatetoggle);
localStorage.setItem('buttoncook5',newdatetoggle);
//
newlow="save"+which+"lowswitch";
newlow=localStorage.getItem(newlow);
localStorage.setItem('lowstate',newlow);

newlowtoggle="save"+which+"lowtoggle";
newlowtoggle=localStorage.getItem(newlowtoggle);
localStorage.setItem('buttoncook6',newlowtoggle);
//
newhigh="save"+which+"highswitch";
newhigh=localStorage.getItem(newhigh);
localStorage.setItem('highstate',newhigh);

newhightoggle="save"+which+"hightoggle";
newhightoggle=localStorage.getItem(newhightoggle);
localStorage.setItem('buttoncook7',newhightoggle);
//
newtime="save"+which+"timeswitch";
newtime=localStorage.getItem(newtime);
localStorage.setItem('timestate',newtime);

newtimetoggle="save"+which+"timetoggle";
newtimetoggle=localStorage.getItem(newtimetoggle);
localStorage.setItem('buttoncook8',newtimetoggle);
//
newtexttimeoff="save"+which+"texttimeoffswitch";
newtexttimeoff=localStorage.getItem(newtexttimeoff);
localStorage.setItem('timetexton',newtexttimeoff);

newtexttimeofftoggle="save"+which+"texttimeofftoggle";
newtexttimeofftoggle=localStorage.getItem(newtexttimeofftoggle);
localStorage.setItem('buttoncook9',newtexttimeofftoggle);
//
newupdatetimeoff="save"+which+"updatetimeoffswitch";
newupdatetimeoff=localStorage.getItem(newupdatetimeoff);
localStorage.setItem('updatetexton',newupdatetimeoff);

newupdatetimeofftoggle="save"+which+"updatetimeofftoggle";
newupdatetimeofftoggle=localStorage.getItem(newupdatetimeofftoggle);
localStorage.setItem('buttoncook10',newupdatetimeofftoggle);
//
newunlockbuttonoff="save"+which+"unlockbuttonoffswitch";
newunlockbuttonoff=localStorage.getItem(newunlockbuttonoff);
localStorage.setItem('unlockbuttonon',newunlockbuttonoff);

newunlockbuttonofftoggle="save"+which+"unlockbuttonofftoggle";
newunlockbuttonofftoggle=localStorage.getItem(newunlockbuttonofftoggle);
localStorage.setItem('buttoncook11',newunlockbuttonofftoggle);
//
newmessagebuttonoff="save"+which+"messagebuttonoffswitch";
newmessagebuttonoff=localStorage.getItem(newmessagebuttonoff);
localStorage.setItem('messagebuttonon',newmessagebuttonoff);

newmessagebuttonofftoggle="save"+which+"messagebuttonofftoggle";
newmessagebuttonofftoggle=localStorage.getItem(newmessagebuttonofftoggle);
localStorage.setItem('buttoncook12',newmessagebuttonofftoggle);
//
newemailbuttonoff="save"+which+"emailbuttonoffswitch";
newemailbuttonoff=localStorage.getItem(newemailbuttonoff);
localStorage.setItem('emailbuttonon',newemailbuttonoff);

newemailbuttonofftoggle="save"+which+"emailbuttonofftoggle";
newemailbuttonofftoggle=localStorage.getItem(newemailbuttonofftoggle);
localStorage.setItem('buttoncook13',newemailbuttonofftoggle);
//
newicons="save"+which+"iconsset";
newicons=localStorage.getItem(newicons);
localStorage.setItem('iconset',newicons);
//
newwidget1="save"+which+"widget1";
widget1=localStorage.getItem(newwidget1);
localStorage.setItem('widget1switch',widget1);

newwidget1l="save"+which+"widget1L";
widget1l=localStorage.getItem(newwidget1l);
localStorage.setItem('widgetoneleft',widget1l);

newwidget1t="save"+which+"widget1T";
widget1t=localStorage.getItem(newwidget1t);
localStorage.setItem('widgetonetop',widget1t);
//
newwidget2="save"+which+"widget2";
widget2=localStorage.getItem(newwidget2);
localStorage.setItem('widget2save',widget2);

newwidget2l="save"+which+"widget2L";
widget2l=localStorage.getItem(newwidget2l);
localStorage.setItem('widget2left',widget2l);

newwidget2t="save"+which+"widget2T";
widget2t=localStorage.getItem(newwidget2t);
localStorage.setItem('widget2top',widget2t);
//
newwidget3="save"+which+"widget3";
widget3=localStorage.getItem(newwidget3);
localStorage.setItem('widget3save',widget3);
//
fshadow="save"+which+"FullShadow";
fshadows=localStorage.getItem(fshadow);
localStorage.setItem('fullshadow',fshadows);
//
GLSs="save"+which+"GroovyLock";
GLSb=localStorage.getItem(GLSs);
localStorage.setItem('lockscreenchosen',GLSb);
//
tweetbotlold="save"+which+"tweetbotL";
tweetbotl=localStorage.getItem(tweetbotlold);
localStorage.setItem('tweetbotleft',tweetbotl);
//
tweetbottold="save"+which+"tweetbotT";
tweetbott=localStorage.getItem(tweetbottold);
localStorage.setItem('tweetbottop',tweetbott);
//
phonelold="save"+which+"phoneL";
phonel=localStorage.getItem(phonelold);
localStorage.setItem('phoneleft',phonel);
//
phonetold="save"+which+"phoneT";
phonet=localStorage.getItem(phonetold);
localStorage.setItem('phonetop',phonet);
//
maillold="save"+which+"mailL";
maill=localStorage.getItem(maillold);
localStorage.setItem('mailleft',maill);
//
mailtold="save"+which+"mailT";
mailt=localStorage.getItem(mailtold);
localStorage.setItem('mailtop',mailt);
//
facebooklold="save"+which+"facebookL";
facebookl=localStorage.getItem(facebooklold);
localStorage.setItem('facebookleft',facebookl);
//
facebooktold="save"+which+"facebookT";
facebookt=localStorage.getItem(facebooktold);
localStorage.setItem('facebooktop',facebookt);
//
timerlold="save"+which+"timerL";
timerl=localStorage.getItem(timerlold);
localStorage.setItem('timerleft',timerl);
//
timertold="save"+which+"timerT";
timert=localStorage.getItem(timertold);
localStorage.setItem('timertop',timert);
//
messageslold="save"+which+"messagesL";
messagesl=localStorage.getItem(messageslold);
localStorage.setItem('messagesleft',messagesl);
//
messagestold="save"+which+"messagesT";
messagest=localStorage.getItem(messagestold);
localStorage.setItem('messagestop',messagest);
//
instagramlold="save"+which+"instagramL";
instagraml=localStorage.getItem(instagramlold);
localStorage.setItem('instagramleft',instagraml);
//
instagramtold="save"+which+"instagramT";
instagramt=localStorage.getItem(instagramtold);
localStorage.setItem('instagramtop',instagramt);
//
linelold="save"+which+"lineL";
linel=localStorage.getItem(linelold);
localStorage.setItem('lineleft',linel);
//
linetold="save"+which+"lineT";
linet=localStorage.getItem(linetold);
localStorage.setItem('linetop',linet);
//
fonttold="save"+which+"Font";
fontt=localStorage.getItem(fonttold);
localStorage.setItem('fontstate',fontt);
//
wbold="save"+which+"Winterboard";
wbt=localStorage.getItem(wbold);
localStorage.setItem('checked',wbt);
//
tweetbotrold="save"+which+"Tweetbotrotated";
tweetbotr=localStorage.getItem(tweetbotrold);
localStorage.setItem('Tweetbotrotated',tweetbotr);

tweetbotsold="save"+which+"Tweetbotscaled";
tweetbots=localStorage.getItem(tweetbotsold);
localStorage.setItem('Tweetbotscaled',tweetbots);

phonerold="save"+which+"Phonerotated";
phoner=localStorage.getItem(phonerold);
localStorage.setItem('Phonerotated',phoner);

phonesold="save"+which+"Phonescaled";
phones=localStorage.getItem(phonesold);
localStorage.setItem('Phonescaled',phones);
 
mailrold="save"+which+"Mailrotated";
mailr=localStorage.getItem(mailrold);
localStorage.setItem('Mailrotated',mailr);

mailsold="save"+which+"Mailscaled";
mails=localStorage.getItem(mailsold);
localStorage.setItem('Mailscaled',mails);
 
facebookrold="save"+which+"Facebookrotated";
facebookr=localStorage.getItem(facebookrold);
localStorage.setItem('Facebookrotated',facebookr);

facebooksold="save"+which+"Facebookscaled";
facebooks=localStorage.getItem(facebooksold);
localStorage.setItem('Facebookscaled',facebooks);
 
 timerrold="save"+which+"Timerrotated";
timerr=localStorage.getItem(timerrold);
localStorage.setItem('Timerrotated',timerr);

timersold="save"+which+"Timerscaled";
timers=localStorage.getItem(timersold);
localStorage.setItem('Timerscaled',timers);
 
  messagesrold="save"+which+"Messagesrotated";
messagesr=localStorage.getItem(messagesrold);
localStorage.setItem('Messagesrotated',messagesr);

messagessold="save"+which+"Messagesscaled";
messagess=localStorage.getItem(messagessold);
localStorage.setItem('Messagesscaled',messagess);

  instagramrold="save"+which+"Instagramrotated";
instagramr=localStorage.getItem(instagramrold);
localStorage.setItem('Instagramrotated',instagramr);

instagramsold="save"+which+"Instagramscaled";
instagrams=localStorage.getItem(instagramsold);
localStorage.setItem('Instagramscaled',instagrams);
 

linerold="save"+which+"Linerotated";
liner=localStorage.getItem(linerold);
localStorage.setItem('Linerotated',liner);

linesold="save"+which+"Linescaled";
lines=localStorage.getItem(linesold);
localStorage.setItem('Linescaled',lines);

iconssold="save"+which+"StockIcon";
iconss=localStorage.getItem(iconssold);
localStorage.setItem('iconstates',iconss);
  
unlocktextsold="save"+which+"Unlocktext";
unlocktexts=localStorage.getItem(unlocktextsold);
localStorage.setItem('unlocktexttextold',unlocktexts);



twittersold="save"+which+"twittersave";
ntwitters=localStorage.getItem(twittersold);
localStorage.setItem('twitterstart',ntwitters);

twitterslold="save"+which+"twitterleftsave";
ntwitterls=localStorage.getItem(twitterslold);
localStorage.setItem('twitterleft',ntwitterls);

twitterstold="save"+which+"twittertopsave";
ntwitterts=localStorage.getItem(twitterstold);
localStorage.setItem('twittertop',ntwitterts);





phonetold="save"+which+"phonestopsaves";
phonets=localStorage.getItem(phonetold);
localStorage.setItem('phonebuttontexttop',phonets);

phonelold="save"+which+"phonesleftsave";
phonels=localStorage.getItem(phonelold);
localStorage.setItem('phonebuttontextleft',phonels);

phonerold="save"+which+"phonesrotatesave";
phoners=localStorage.getItem(phonerold);
localStorage.setItem('phonetextrotated',phoners);

phonessold="save"+which+"phonesscalesave";
phonesss=localStorage.getItem(phonessold);
localStorage.setItem('phonetextscaled',phonesss);

twittertold="save"+which+"twitterstopsaves";
twitterts=localStorage.getItem(twittertold);
localStorage.setItem('twitterbuttontexttop',twitterts);

twitterlold="save"+which+"twittersleftsave";
twitterls=localStorage.getItem(twitterlold);
localStorage.setItem('twitterbuttontextleft',twitterls);

twitterrold="save"+which+"twittersrotatesave";
twitterrs=localStorage.getItem(twitterrold);
localStorage.setItem('twittertextrotated',twitterrs);

twitterssold="save"+which+"twittersscalesave";
twittersss=localStorage.getItem(twitterssold);
localStorage.setItem('twittertextscaled',twittersss);

messengertold="save"+which+"messengerstopsaves";
messengerts=localStorage.getItem(messengertold);
localStorage.setItem('messengerbuttontexttop',messengerts);

messengerlold="save"+which+"messengersleftsave";
messengerls=localStorage.getItem(messengerlold);
localStorage.setItem('messengerbuttontextleft',messengerls);

messengerrold="save"+which+"messengersrotatesave";
messengerrs=localStorage.getItem(messengerrold);
localStorage.setItem('messengertextrotated',messengerrs);

messengerssold="save"+which+"messengersscalesave";
messengersss=localStorage.getItem(messengerssold);
localStorage.setItem('messengertextscaled',messengersss);


location.reload();
}


