$(window).load(function() {
$('.do').css('display', 'block');
$('#Time').css('display', 'block'); 
$(".do").css('marginTop', '0px');

texttimestore = localStorage.getItem("timetexton");
updatetimestore = localStorage.getItem("updatetexton");
updateunlockbutton = localStorage.getItem("unlockbuttonon");
updatemessagebutton = localStorage.getItem("messagebuttonon");
updateemailbutton = localStorage.getItem("emailbuttonon");
updatephonebutton = localStorage.getItem("phonebuttonon");
updatetwitterbutton = localStorage.getItem("twitterbuttonon");
updatemessengerbutton = localStorage.getItem("messengerbuttonon");

if (texttimestore == "on") {
    $("#timetext").css('display', 'block');
}

if (updatetimestore == "on") {
    $("#updatetext").css('display', 'block');
}

if (updateunlockbutton == "on") {
    $("#unlockbuttontext").css('display', 'block');
}
if (updatemessagebutton == "on") {
    $("#messagebuttontext").css('display', 'block');
}
if (updateemailbutton == "on") {
    $("#emailbuttontext").css('display', 'block');
}
if (updatephonebutton == "on") {
    $("#phonebuttontext").css('display', 'block');

} else {
    $("#phonebuttontext").css('display', 'none');
}
if (updatetwitterbutton == "on") {
    $("#twitterbuttontext").css('display', 'block');
} else {
    $("#twitterbuttontext").css('display', 'none');
}
if (updatemessengerbutton == "on") {
    $("#messengerbuttontext").css('display', 'block');
} else {
    $("#messengerbuttontext").css('display', 'none');
}

//$('#opensettings').css('display', 'block'); evil af
$("weatherIcon").css('display', 'block');

});


//moved bg button when clicked create Wall, Weather, Locks, and reload buttons
$("#bg").click(function () {
    closemenu();
    submenu();
    $("#bubble").css('left', '90px');
    $("#bubble").css('top', '315px');
    $("#bgwall").css('left', '4px');
    $("#nobg").css('left', '0px');
    $("#bgwall").css('top', '80px');
    $("#files").css('display', 'block');
    $("#wall").css('display', 'block');
$("<button></button>").attr('id','wall' ).appendTo('body');    
     
      $("#wall").html('Unblur').button('wall');
$("<button></button>").attr('id','weatherbutton' ).appendTo('body');    
     
      $("#weatherbutton").html('Weather').button('weatherbutton');
$("<button></button>").attr('id','locks' ).appendTo('body');    

      $("#locks").html('Locks').button('locks');

});

//when any of these are pressed reset blur
$('#widgetone, #widgettwo,#widgetthree,#widgetfour,#closewidget1,#closewidget2,#closewidgetclosemenu,#closewidget3').live('click', function() {
 releaseblur();
    }); 

// release blur function 
function releaseblur(){
opened ="1";
$("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#date,#Time,#emailbuttontext,#messagebuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(0px)');
$("#weather").css('-webkit-transform', 'scale(1)');
}

// if wall is clicked load wall
$('#wall').live('click', function() {
checkwall();
}); 

function checkwall(){
$("#overlay").css('display', 'block');
localStorage.setItem('hideuserbg','no');
}

// if weather button is press then remove user background and reload.
$('#weatherbutton').live('click', function() {
$("#overlay").css('display', 'none');
 localStorage.setItem('hideuserbg','yes');
 set = "no";
  localStorage.setItem('livewall', set);
$('#weatherIcon').css('opacity','1');
}); 

//Reload button for locks entered
$('#reloadbg').live('click', function() {
 
}); 

$('#files').live('click', function() {
$('#files').css('display','none');
});



opened = "1";
// If closed remove blur and buttons
$("#settingsclose").click(function () {
   closemenu();
   $('#opensettings').removeClass('nohide');
   $("#menu2button").css('display', 'none');
   $(".settingspanel2").css('top', '-500px');
      $(".onandoff2").css('left', '-500px');
    $(".onandoff2").css('top', '-500px');
    $(".changeweathericons").css('display', 'none');
     $(".changeweathericons2").css('display', 'none');
     $("#files").css('display', 'none');
      $("#moreicons").css('display', 'none');
$("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#date,#Time,#emailbuttontext,#messagebuttontext,#unlockbuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(0px)');
$("#weather").css('-webkit-transform', 'scale(1)');
 $("#overlay").css('-webkit-filter', 'blur(0px)');
  $(".usersettings,#bgwall,#bubble,.settingspanelcolors,.fontcolors,#widgetfour,#widgetfive,#widgetthree,#widgetsmenu,#widgetone,#widgettwo,#widgetclosemenu,#settingsclose,.settingspanel,.settingspanelfonts,#settingspanel,.onandoff,.settingspaneliconsgo,#themes").css('left', '-1000px');
  $(".fonton,.iconsgo").css('left', '-100px');
  $("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#date,#Time,#emailbuttontext,#messagebuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(0px)');
  $("#weather").css('-webkit-transform', 'scale(1)');

opened ="1";
   $("#refreshs").remove();
   $("#changeicons").remove();
   $("#winterboard").remove();
   $("#wall").remove();
   $("#weatherbutton").remove();
   $("#locks").remove();
   $("#reloadbg").remove();
});



click1 = "0";

// When menu button is pressed
$("#opensettings").click(function () {

  $('#opensettings').addClass('nohide');

click1++

    if(click1 == 1){ openmenu1(); $('#opensettings').addClass('nohide');}
        if(click1 == 2){closemenu();click1 = "0"; $('#opensettings').removeClass('nohide');}

  opened++




//if pressed again remove button

});
/////////////////////////////////////////


function openmenu1(){
$("#weather").css('-webkit-transform', 'scale(1.2)');
$("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#Time,#emailbuttontext,#messagebuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(5px)');
$("#messengertext,#phonetext,#date,#twittertext").css('-webkit-filter', 'blur(5px)');
$("#opensettings").css('top', '335px');
$(".menu1").css('left', '130px');
$(".menu1icons").css('left', '60px');
$("#menubar").css('top', '-80px');

$(" <button></button>").attr('id','refreshs' ).appendTo('body');    
   

      $("#refreshs").html('Google').button('refresh');

      $(" <button></button>").attr('id','Lockeverything' ).appendTo('body');    

      $("#Lockeverything").html('Lock').button('Lockeverything');
}


function closemenu(){
     click1 = "0";
$("#messengertext,#phonetext,#date,#twittertext").css('-webkit-filter', 'blur(0px)');
$("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#Time,#emailbuttontext,#messagebuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(0px)');
$("#weather").css('-webkit-transform', 'scale(1)');
$("#opensettings").css('top', '25px');
$("#menubar").css('top', '-905px');
$(".menu1icons").css('left', '-605px');
$(".menu1").css('left', '-605px');
$("#refreshs").remove();
$("#Lockeverything").remove();
}


   $('#refreshs').live('click', function() {
    google=prompt("What do you want to Google?"," ");
    window.location.href = "x-web-search://?"+google;
}); 

isitlocked=localStorage.getItem("lockednow");
if(isitlocked!=null){
  $("#lockoverlay").css('left', '0px');
  unlockoverlay="0";
}
else{
  
}


$('#Lockeverything').live('click', function() {
 localStorage.setItem("lockednow","yes");
 localStorage.setItem('islocked','yes');
 $("#lockoverlay").css('left', '0px');


setTimeout(function () {removelockedsymbol(); }, 1000);
 opened="2";
 $('#lockedsymbol').addClass('animate');
unlockoverlay="0";

});  


firsticonlock=localStorage.getItem('islocked');


if(firsticonlock==null){
localStorage.setItem('islocked','no');
}

function unlockthis(){

$('#unlockedsymbol').removeClass('animate');

unlockoverlay++
if(unlockoverlay==3){

   $("#lockoverlay").css('left', '-500px');
    $('#lockedsymbol').removeClass('animate');
 $('#unlockedsymbol').addClass('animate');   

localStorage.removeItem("lockednow");
localStorage.setItem('islocked','no');
setTimeout(function () {unlockedsymbol(); }, 1000);
}

}

function unlockedsymbol(){
  $('#unlockedsymbol').removeClass('animate');
  location.reload();
}

 function removelockedsymbol(){
   $('#lockedsymbol').removeClass('animate');
   location.reload();
 } 

// Pulled in from button.js when ever there is a sub menu open blur items.
function submenu(){
 $("#refreshs").remove(); // remove our button
$("#updatetext,#timetext,#city,#weather,#weatherIcon2,#low,#high,#desc,#humidity,#temp,#date,#Time,#emailbuttontext,#messagebuttontext,#messengertext,#phonetext,#twittertext,#unlockbuttontext").css('-webkit-filter', 'blur(5px)');
$("#weather").css('-webkit-transform', 'scale(1.2)');
$("#settingspanel").css('left', '0px');
$("#settingspanel").css('top', '40px');
$("#settingsclose").css('left', '148px');
$("#opensettings").css('top', '22px');
}


 //if (navigator.platform === 'iPad') {
 //$('meta[name=viewport]').attr('content','width=700, height=1000, initial-scale=2.4, maximum-scale=2.4, user-scalable=no');
   


//setTimeout('locksload()', 100);

//function locksload(){
//$('#locksa').css("-webkit-transform","scale(0.43,0.43)");
//$('#locksa').css("marginLeft","-89px");
//$('#locksa').css("marginTop","-66px");
//$('#locksa').css("opacity","1");
//$('#locksa').animate({
  //  marginLeft: -89,
    //marginTop: -66
    // Comment the line below to see difference
   //,opacity: 1
//}, 1);

//}


 //}






