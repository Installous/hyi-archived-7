// When icons are chosen create button to change icons


$("#iconsgo").click(function () {

$(" <button></button>").attr('id','changeicons' ).appendTo('body');    
   
$("#changeicons").html('Stock Icons').button('refresh');

$(" <button></button>").attr('id','winterboard' ).appendTo('body');    
    
$("#winterboard").html('Winterboard').button('refresh');
});





clicked = "0";

   $('#changeicons').live('click', function() {

localStorage.removeItem("checked");
    clicked++
  if(clicked =="1"){
    values = "go";
    localStorage.setItem('iconstates', values);
    setnormal();
    //setwhiteicons();
    clicked ="0";
  }
  
    });

var autoset = localStorage.getItem('iconstates');




if(autoset =="go"){
setnormal();

}
else{setnormal();}

if(autoset=="undefined"){
  setnormal();
}





function setnormal(){
 twitter=localStorage.getItem('twitterclient');
 if(twitter==null){twitter="twitter://"}
  twitterchoice=twitter;
  messenger=localStorage.getItem('messageclient');
   if(messenger==null){messenger="whatsapp://app";}
  messengerchoice=messenger;
 sizeicon="50"

 document.getElementById("size1").innerHTML = "<img src='../tweetbot.png' width='50'>"
 document.getElementById("Tweetbot").innerHTML =  '<a href='+twitterchoice+'><img width='+sizeicon+' src="../tweetbot.png"></a>'
  document.getElementById("size2").innerHTML = "<img src='../phone.png' width='50'>"
 document.getElementById("Phone").innerHTML = "<a href='music:user_profile'><img src='../phone.png' width='50'></a>"
  document.getElementById("size3").innerHTML = "<img src='../mail.png' width='50'>"
 document.getElementById("Mail").innerHTML = "<a href='mailto:''><img src='../mail.png' width='50'></a>"
  document.getElementById("size4").innerHTML = "<img src='../facebook.png' width='50'>"
 document.getElementById("Facebook").innerHTML = "<a href='fb://profile'><img src='../facebook.png' width='50'></a>"
  document.getElementById("size5").innerHTML = "<img src='../timer.png' width='50'>"
 document.getElementById("Timer").innerHTML = "<a href='maps:'><img src='../timer.png' width='50'></a>"
  document.getElementById("size6").innerHTML = "<img src='../messages.png' width='50'>"
 document.getElementById("Messages").innerHTML = "<a href='sms:'><img src='../messages.png' width='50'></a>"
  document.getElementById("size7").innerHTML = "<img src='../instagram.png' width='50'>"
 document.getElementById("Instagram").innerHTML = " <a href='instagram://user_profile'><img src='../instagram.png' width='50'></a>"
  document.getElementById("size8").innerHTML = "<img src='../line.png' width='50'>"
 document.getElementById("Line").innerHTML = '<a href='+messengerchoice+'><img width='+sizeicon+' src="../line.png"></a>'
}


// fixes. Only way to move the lock is with animate

//$('#locksa').animate({
  //  height: 586
   //,opacity: 1
//}, 1);

theme=localStorage.getItem("checked");

//We are not moving it.. The issue lies in HUD, update v1.1 will fix

// other fixes
$(document).ready(function(){
  setTimeout('fixu()', 2000); //fix layering of lockscreen and wallpaper
});

function fixu(){
$("#overlay").css('z-index', '1'); 

$("#locksa").css('z-index', '2');




}




if(theme!=null){
  if(theme!="null"){
    if(theme!="undefined"){
localStorage.removeItem("iconstates");
twitter=localStorage.getItem('twitterclient');
 if(twitter==null){twitter="twitter://"}
  size="60";
  sizeicon="50";
  tweetbot=twitter;

  music="music:user_profile";
  mail="mailto:";
  facebook="fb://profile";
  maps="maps:";
  sms="sms:";
  instagram="instagram://user_profile";
  line="whatsapp://app";
  messenger=localStorage.getItem('messageclient');
  if(messenger==null){messenger="whatsapp://app";}
  messengerchoice=messenger;

document.getElementById("size1").innerHTML = '<img width='+size+' src="file:///Library/Themes/'+theme+'/Bundles/com.tapbots.Tweetbot3/AppIcon60x60@2x.png">'
document.getElementById("Tweetbot").innerHTML = '<a href='+tweetbot+'><img width='+sizeicon+' src="file:///Library/Themes/'+theme+'/Bundles/com.tapbots.Tweetbot3/AppIcon60x60@2x.png"></a>'

document.getElementById("size2").innerHTML = '<img width='+size+' src="file:///Library/Themes/'+theme+'/Bundles/com.apple.Music/Icon-120.png">'
document.getElementById("Phone").innerHTML = '<a href='+music+'><img width='+sizeicon+' src="file:///Library/Themes/'+theme+'/Bundles/com.apple.Music/Icon-120.png"></a>'

document.getElementById("size3").innerHTML = '<img width='+size+' src="file:///Library/Themes/'+theme+'/Bundles/com.apple.mobilemail/Icon@2x.png">'
document.getElementById("Mail").innerHTML = '<a href='+mail+'><img width='+sizeicon+' src="file:///Library/Themes/'+theme+'/Bundles/com.apple.mobilemail/Icon@2x.png"></a>'

document.getElementById("size4").innerHTML = '<img width='+size+' src="file:///Library/Themes/'+theme+'/Bundles/com.facebook.Facebook/Icon@2x.png">'
document.getElementById("Facebook").innerHTML = '<a href='+facebook+'><img width='+sizeicon+' src="file:///Library/Themes/'+theme+'/Bundles/com.facebook.Facebook/Icon@2x.png"></a>'

document.getElementById("size5").innerHTML = '<img width='+size+' src="file:///Library/Themes/'+theme+'/Bundles/com.apple.Maps/icon@2x~iphone.png">'
document.getElementById("Timer").innerHTML = '<a href='+maps+'><img width='+sizeicon+' src="file:///Library/Themes/'+theme+'/Bundles/com.apple.Maps/icon@2x~iphone.png"></a>'



document.getElementById("size6").innerHTML = '<img width='+size+' src="file:///Library/Themes/'+theme+'/Bundles/com.apple.MobileSMS/icon@2x.png">'

document.getElementById("Messages").innerHTML = '<a href='+sms+'><img width='+sizeicon+' src="file:///Library/Themes/'+theme+'/Bundles/com.apple.MobileSMS/icon@2x.png" ></a>'
document.getElementById("size6").innerHTML = '<img width='+size+' src="file:///Library/Themes/'+theme+'/Bundles/com.apple.MobileSMS/icon@2x.png">'


document.getElementById("Instagram").innerHTML = '<a href='+instagram+'><img width='+sizeicon+' src="file:///Library/Themes/'+theme+'/Bundles/com.burbn.instagram/Icon-60@2x.png" ></a>'
document.getElementById("size7").innerHTML = '<img width='+size+' src="file:///Library/Themes/'+theme+'/Bundles/com.burbn.instagram/Icon-60@2x.png">'

document.getElementById("size8").innerHTML = '<img width='+size+' src="file:///Library/Themes/'+theme+'/Bundles/net.whatsapp.WhatsApp/Icon@2x.png">'
document.getElementById("Line").innerHTML = '<a href='+messengerchoice+'><img width='+sizeicon+' src="file:///Library/Themes/'+theme+'/Bundles/net.whatsapp.WhatsApp/Icon@2x.png"></a>'

}
}
}

