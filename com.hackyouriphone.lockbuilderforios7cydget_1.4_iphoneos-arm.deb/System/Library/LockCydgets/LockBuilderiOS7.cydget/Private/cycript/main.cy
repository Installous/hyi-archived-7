
[[SBBacklightController sharedInstance] cancelLockScreenIdleTimer]
var statusbar = new Boolean(false);
var dimmer="";
var sCityCodes="";
var isCelsius="";
var urlcode="";
var showuni=new Boolean(false);
var TwentyFourHourClock=new Boolean(false);
    try {
        var settings = [NSDictionary dictionaryWithContentsOfFile: @"/var/mobile/Library/Preferences/com.JunesiPhone.LockBuilder.plist"];
        if (settings != null) {
        //alert(settings);   
            if(settings.statusbarswitch!=null){statusbar = settings.statusbarswitch;}
              else{statusbar=false;}  
            if(settings.dimmer!=null){dimmer = settings.dimmer;}
              else{dimmer="6000";} 
            if(settings.sCityCodes!=null){sCityCodes = settings.sCityCodes;}
              else{sCityCodes="38671";} 
            if(settings.sUnit!=null){isCelsius = settings.sUnit}
              else{isCelsius="false";}
            if(settings.languages!=null){languages = settings.languages}
              else{languages="en";}
            if(settings.zipwoeid!=null){urlcode = settings.zipwoeid}
              else{urlcode=false;}
            if(settings.showuni!=null){showuni = settings.showuni}
              else{showuni=false;}
            if(settings.TwentyFour!=null){TwentyFourHourClock = settings.TwentyFour}
              else{TwentyFourHourClock=false;}
            if(settings.slider!=null){slider = settings.slider;}
            if(settings.twitter!=null){twittersettings=settings.twitter}
             if(settings.settingblur!=null){dynamic=settings.settingblur}
              if(settings.captext!=null){captext=settings.captext}
                else{captext="1"} 
              if(settings.smstext!=null){smstext=settings.smstext}
                else{smstext="SMS: "}  
              if(settings.mailtext!=null){mailtext=settings.mailtext}
                else{mailtext="Mail: "}  
              if(settings.phtext!=null){phtext=settings.phtext}
                else{phtext="Missed: "}  
              if(settings.twtext!=null){twtext=settings.twtext}
                else{twtext="Twitter: "}  
              if(settings.msgtext!=null){msgtext=settings.msgtext}
                else{msgtext="Messenger: "}  
              if(settings.globalfonts!=null){globalfonts=settings.globalfonts}
                else{globalfonts="30"}
                if(settings.globaliconsize!=null){globaliconsize=settings.globaliconsize}
                else{globaliconsize="60"} 

              if(settings.Tempopacity!=null){Tempopacity=settings.Tempopacity}
                else{Tempopacity="1.0"} 
                if(settings.Iconopacity!=null){Iconopacity=settings.Iconopacity}
                else{Iconopacity="1.0"} 
                if(settings.Cityopacity!=null){Cityopacity=settings.Cityopacity}
                else{Cityopacity="1.0"} 
                if(settings.Humidopacity!=null){Humidopacity=settings.Humidopacity}
                else{Humidopacity="1.0"} 
                if(settings.Descopacity!=null){Descopacity=settings.Descopacity}
                else{Descopacity="1.0"} 
                if(settings.Dateopacity!=null){Dateopacity=settings.Dateopacity}
                else{Dateopacity="1.0"} 
                if(settings.Lowopacity!=null){Lowopacity=settings.Lowopacity}
                else{Lowopacity="1.0"} 
                if(settings.Highopacity!=null){Highopacity=settings.Highopacity}
                else{Highopacity="1.0"} 
                if(settings.Timeopacity!=null){Timeopacity=settings.Timeopacity}
                else{Timeopacity="1.0"}  
                if(settings.TTopacity!=null){TTopacity=settings.TTopacity}
                else{TTopacity="1.0"} 
                if(settings.UTopacity!=null){UTopacity=settings.UTopacity}
                else{UTopacity="1.0"} 
                if(settings.Tapopacity!=null){Tapopacity=settings.Tapopacity}
                else{Tapopacity="1.0"} 
                if(settings.Messopacity!=null){Messopacity=settings.Messopacity}
                else{Messopacity="1.0"} 
                if(settings.EMopacity!=null){EMopacity=settings.EMopacity}
                else{EMopacity="1.0"} 
                if(settings.Phoneopacity!=null){Phoneopacity=settings.Phoneopacity}
                else{Phoneopacity="1.0"} 
                if(settings.Tweetopacity!=null){Tweetopacity=settings.Tweetopacity}
                else{Tweetopacity="1.0"} 
                if(settings.MSGopacity!=null){MSGopacity=settings.MSGopacity}
                else{MSGopacity="1.0"} 

                if(settings.Tempcolor!=null){Tempcolor=settings.Tempcolor}
                else{Tempcolor="null"} 
                if(settings.Citycolor!=null){Citycolor=settings.Citycolor}
                else{Citycolor="null"} 
                if(settings.Humidcolor!=null){Humidcolor=settings.Humidcolor}
                else{Humidcolor="null"} 
                if(settings.Desccolor!=null){Desccolor=settings.Desccolor}
                else{Desccolor="null"} 
                if(settings.Datecolor!=null){Datecolor=settings.Datecolor}
                else{Datecolor="null"} 
                if(settings.Lowcolor!=null){Lowcolor=settings.Lowcolor}
                else{Lowcolor="null"} 
                if(settings.Highcolor!=null){Highcolor=settings.Highcolor}
                else{Highcolor="null"} 
                if(settings.Timecolor!=null){Timecolor=settings.Timecolor}
                else{Timecolor="null"}  
                if(settings.TimeTcolor!=null){TimeTcolor=settings.TimeTcolor}
                else{TimeTcolor="null"} 
                if(settings.UpdateTcolor!=null){UpdateTcolor=settings.UpdateTcolor}
                else{UpdateTcolor="null"}
                if(settings.Tapcolor!=null){Tapcolor=settings.Tapcolor}
                else{Tapcolor="null"} 
                if(settings.Messcolor!=null){Messcolor=settings.Messcolor}
                else{Messcolor="null"} 
                if(settings.EMcolor!=null){EMcolor=settings.EMcolor}
                else{EMcolor="null"} 
                if(settings.Phonecolor!=null){Phonecolor=settings.Phonecolor}
                else{Phonecolor="null"} 
                if(settings.Tweetcolor!=null){Tweetcolor=settings.Tweetcolor}
                else{Tweetcolor="null"} 
                if(settings.MSGcolor!=null){MSGcolor=settings.MSGcolor}
                else{MSGcolor="null"} 
                if(settings.allcolor!=null){allcolor=settings.allcolor}
                else{allcolor="null"} 


}
else{ ///defaults
alert("Set location in the settings.app");
statusbar=false;
dimmer="10000";
sCityCodes="38671";
isCelsius="false";
urlcode="false";
showuni=false;
TwentyFourHourClock=false;
        }
} catch(err){alert(err);
}

localStorage.setItem("showuni",showuni);

if(languages!=null){
  localStorage.setItem("languages",languages);
}

if(TwentyFourHourClock==1){
  TwentyFourHourClock="false";
localStorage.setItem("time",TwentyFourHourClock);

}
if(TwentyFourHourClock==0){
  TwentyFourHourClock="true";
  localStorage.setItem("time",TwentyFourHourClock);
}

if(isCelsius==1){
  isCelsius="true";
localStorage.setItem("isCelsius",isCelsius);
}
else{
  isCelsius="false";
  localStorage.setItem("isCelsius",isCelsius);
}

if(captext==1){
localStorage.setItem("captext",captext);
}
else{
  
  localStorage.setItem("captext",captext);
}

if(urlcode==1){
  urlcode="true";
  localStorage.setItem('urlcode',urlcode);
}
else{
  urlcode="false";
  localStorage.setItem('urlcode',urlcode);
}


if(dynamic==1){
  localStorage.removeItem("userbg");
}

