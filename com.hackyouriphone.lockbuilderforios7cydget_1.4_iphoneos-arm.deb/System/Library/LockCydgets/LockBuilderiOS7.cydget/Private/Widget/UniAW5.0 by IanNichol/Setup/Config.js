
// UniAW5.0 By Ian Nicoll with credit to Dacal

// Configuration

/* For weather code, go to http://weather.yahoo.com/ and search for your city.
The correct zip code is in the URL (only numbers) */

	// Yahoo Weather code.
			// "f" for fahrenheit.
var updateInterval = 60; 	// in minutes.
var GMT = 0; 				/* 	Adjust the hour of sunset and sunrise only if 
								YahooWeather doesn't report correctly (summer time)*/				

var ampm = true; 			// Set to true for 12h format.
var lang = "en"; 			// (fr) for french, (de) for german, (sp) for spanish, (en) or for english.
var SecDisplay = true; 		// true to display seconds.
var SunsetSunrise = true; 	// true to display sunset and sunrise time
