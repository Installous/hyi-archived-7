// UniAW5.0 By Ian Nicoll with credit to Dacal



var updateWeatherEvery = updateInterval*60*1000;
var xmldata = false;
var postal;
var filename = "";
var where = "";
var whereOld = "";

switch (lang) {
case "fr":
	var days = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
	var months=['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre'];
break;
case "de":
	var days = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];
	var months=["Januar","Februar","Marz","April","Mai","Juni","Juli","August","September ","Oktober","November","Dezember"];		
break;
case "sp":
	var days = ["Dom","Lun","Mar","Mie","Jue","Vie","Sab"];
	var months=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Deciembre'];
break;
default: 
	var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	var months=["January","February","March","April","May","June","July","August","September","October","November","December"];
break;
}

function updateClock () {
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
time_to_change_wall = currentHours + currentMinutes/60;
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";
	
if (ampm == false) {
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
	document.getElementById("clock").innerHTML = currentTimeString;
	document.getElementById("ampm").innerHTML = timeOfDay;
	} else {
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
	document.getElementById("clock").innerHTML = currentTimeString;
	document.getElementById("ampm").innerHTML = timeOfDay;
}

document.getElementById("second").innerHTML = currentSeconds;
document.getElementById("day").innerHTML = days[currentTime.getDay()];
document.getElementById("month").innerHTML = months[currentTime.getMonth()];
document.getElementById("date").innerHTML = currentDate;
}

function init(){
document.getElementById("city").innerHTML="...";
document.getElementById("temp").innerHTML="...&#176;";
document.getElementById("desc").innerHTML="Loading...";
if (SecDisplay == false) { document.getElementById("second").style.display='none';}
updateClock();
setInterval("updateClock();", 1000);
validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal);
}

function setPostal(obj){
	if (obj.error == false){
		if(obj.cities.length > 0) {
			postal = escape(obj.cities[0].zip).replace(/^%u/g, "%")
			weatherRefresherTemp();
			}
			else
			{
			document.getElementById("city").innerHTML="Locale ?!";
			}
		}
		else
		{
		document.getElementById("city").innerHTML="Locale ?!";
		setTimeout('validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)', Math.round(1000*60*5));
		}
}

function weatherRefresherTemp(){

	fetchWeatherData(dealWithWeather,postal);
	setTimeout(weatherRefresherTemp, updateWeatherEvery);
}

function validateWeatherLocation (location, callback) {
	var obj = {error:false, errorString:null, cities: new Array};
	obj.cities[0] = {zip: location};
	callback (obj);
}

function dealWithWeather(obj){
	if (obj.error == false){
		direction = parseFloat(obj.winddir);
		document.getElementById("city").innerHTML=obj.city;
		document.getElementById("temp").innerHTML=obj.temp + "&#176;";
		document.getElementById("low").innerHTML=obj.todaylow + "&#176;";
		document.getElementById("high").innerHTML=obj.todayhigh + "&#176;";
		document.getElementById("tiret").innerHTML = "/";
		document.getElementById("tiret").style.color = "#FFFFFF";
		document.getElementById("desc").innerHTML=obj.description;

		switch (lang) {
		case "fr":
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Ensoleill&eacute;'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Bruine'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Fortes chutes de neige'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Fortes averses'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Pluie et neige'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Pluie et neige m&eacute;l&eacute;es'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Ciel d&eacute;gag&eacute;';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Quelques nuages';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Partiellement nuageux';	  }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Nuages &eacute;parses';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;rement voil&eacute;';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Brume';	}
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nuageux';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Brouillard';	  }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Averses';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Soleil et averses';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Orages';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Orage';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et fortes averses';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Soleil et fortes averses';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re pluie';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Pluie';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Averses de neige';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux avec neige';	  }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Soleil et averses de neige';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Averses de neige';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Averses de neige';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Neige';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et neige';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Glace';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Verglas';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Pluie vergla&ccedil;ante';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Pluie et neige m&eacute;l&eacute;es';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Chaud';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Froid';	  }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Vent';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Clair';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Tr&egrave;s clair';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Partiellement nuageux';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Brume';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Partiellement nuageux et averses';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et averses';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Partiellement nuageux et fortes averses';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Brouillard';    }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Flocons de neige'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;res chutes de neige'; }		
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Averses';    }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re bruine';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Pluie et verglas';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Neige et verglas';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Gros orages';    }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Ouragan';    }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Orage tropical';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornade';    }
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Buine vergla&ccedil;ante';    }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Rafales de neige'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Gr&ecirc;le'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Poussi&eacute;reux';    }
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Brumeux';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Temp&ecirc;te';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Pluie et Gr&ecirc;le m&eacute;l&eacute;es';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Orages isol&eacute;s';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Averses isol&eacute;s';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Orages &eacute;parses';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Averses &eacute;parses';    }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Chutes de neige &eacute;parses';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Pluie l&eacute;g&egrave;re et &eacute;clairs';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='Non disponible';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Neige poudreuse et vent';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re averse'; }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Tonnerre'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et vent'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Temp&ecirc;te de sable'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Rafales de vent'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Sable'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Temp&ecirc;te de sable et vent'; }
			if (translatedesc=='squalls') { document.getElementById("desc").innerHTML='Rafales'; }
			document.getElementById("lastupdate").innerHTML = "Mise à jour - " + currentTimeString + " " + timeOfDay;
			document.getElementById("humidity").innerHTML = "Humidité : " + obj.humidity + "%";		
			if (direction <= 360) obj.winddir = "N";
			if (direction < 348.75) obj.winddir = "N-NO";		
			if (direction < 326.25) obj.winddir = "NO";		
			if (direction < 303.75) obj.winddir = "O-NO";
			if (direction < 281.25) obj.winddir = "O";		
			if (direction < 258.75) obj.winddir = "O-SO";		
			if (direction < 236.25) obj.winddir = "SO";
			if (direction < 213.75) obj.winddir = "S-SO";		
			if (direction < 191.25) obj.winddir = "S";		
			if (direction < 168.75) obj.winddir = "S-SE";
			if (direction < 146.25) obj.winddir = "SE";		
			if (direction < 123.75) obj.winddir = "E-SE";		
			if (direction < 101.25) obj.winddir = "E";		
			if (direction < 78.75) obj.winddir = "E-NE";		
			if (direction < 56.25) obj.winddir = "NE";
			if (direction < 33.75) obj.winddir = "N-NE";		
			if (direction < 11.25) obj.winddir = "N";
			if (direction == 0) obj.winddir = "Pas de vent";
			if (direction == 0) {
								document.getElementById("wind").innerHTML = "Vent : " + obj.winddir;				
								} else {
								document.getElementById("wind").innerHTML = "Vent : " + obj.winddir + " - " + Math.round(obj.windspeed) + " " + obj.windunit; }
		break;
		case "de":
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado!'; }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tropischer Sturm'; }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Wirbelsturm'; }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Schwere Gewitter'; }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Gewitter'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Regen und Schnee'; }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Graupelschauer'; }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Schneeregen'; }
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Gefrierender Nieselregen'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Nieselregen'; }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Gefrierender Regen'; }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Schauer'; }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Schneegest&ouml;ber'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Leichte Schneeschauer'; }
			if (translatedesc=='light snow grains') { document.getElementById("desc").innerHTML='Leichte Schneeschauer'; }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Schneetreiben'; }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Schnee'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Hagel'; }
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Schneeregen'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Staubig'; }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Nebelig'; }
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Dunstschleier'; }
			if (translatedesc=='smoky') { document.getElementById("desc").innerHTML='Dunstig'; }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='St&uuml;rmisch'; }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Windig'; }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Kalt'; }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Bew&ouml;lkt'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Meist Bew&ouml;lkt'; }
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Teilweise Bew&ouml;lkt'; }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Klar'; }
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Sonnig'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Heiter'; }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Regen und Hagel'; }
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Heiss'; }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='&Ouml;rtliche Gewitter'; }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Vereinzelte Gewitter'; }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Vereinzelte Schauer'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Starker Schneefall'; }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Vereinzelte Schneeschauer'; }
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Teilweise Bew&ouml;lkt'; }
			if (translatedesc=='thundershowers') { document.getElementById("desc").innerHTML='Gewitter'; }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Scheeschauer'; }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Ouml;rtliche Gewitterschauer'; }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Leichte Regenschauer'; }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='nicht verfuegbar'; }
			if (translatedesc=='showers in the vicinity') { document.getElementById("desc").innerHTML='Schauer'; }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Teilweise Sonnig'; }
			if (translatedesc=='ground fog') { document.getElementById("desc").innerHTML='Bodennebel'; }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='Leichter Nieselregen'; }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Leichter Regen'; }
			if (translatedesc=='mist') { document.getElementById("desc").innerHTML='Nebel'; }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Nebel'; }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Regen'; }
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Regenschauer'; }
			if (translatedesc=='severe thunderstorm/windy') { document.getElementById("desc").innerHTML='Schwere Gewitter/Windig'; }
			document.getElementById("lastupdate").innerHTML = "Letztes Update - " + currentTimeString + " " + timeOfDay;
			document.getElementById("humidity").innerHTML = "Feuchtigkeit : " + obj.humidity + "%";		
			if (direction <= 360) obj.winddir = "N";
			if (direction < 348.75) obj.winddir = "N-NW";	
			if (direction < 326.25) obj.winddir = "NW";	
			if (direction < 303.75) obj.winddir = "W-NW";
			if (direction < 281.25) obj.winddir = "W";	
			if (direction < 258.75) obj.winddir = "W-SW";	
			if (direction < 236.25) obj.winddir = "SW";
			if (direction < 213.75) obj.winddir = "S-SW";	
			if (direction < 191.25) obj.winddir = "S";	
			if (direction < 168.75) obj.winddir = "S-SO";
			if (direction < 146.25) obj.winddir = "SO";	
			if (direction < 123.75) obj.winddir = "O-SO";	
			if (direction < 101.25) obj.winddir = "O";	
			if (direction < 78.75) obj.winddir = "O-NO";	
			if (direction < 56.25) obj.winddir = "NO";
			if (direction < 33.75) obj.winddir = "N-NO";	
			if (direction < 11.25) obj.winddir = "N";
			if (direction == 0) obj.winddir = "Kein wind";
			if (direction == 0) {
								document.getElementById("wind").innerHTML = "Wind : " + obj.winddir;
								} else 	{
								document.getElementById("wind").innerHTML = "Wind : " + obj.winddir + " - " + Math.round(obj.windspeed) + " " + obj.windunit;}
		break;
		case "sp":
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Soleado'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Llovizna'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Nevada fuerte'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Lluvia fuerte'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Lluvia y nieve'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Lluvia y nieve'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Despejado';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Muy soleado';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Parcialmente soleado';   }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Nubes intermitentes';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Sol brumoso';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Neblina'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Mayormente nublado';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nublado';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Niebla';	  }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Chubascos';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Parcialmente soleado con chubascos';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Tormenta electrica';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Mayormente nublado con tormentas de chubascos';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Parcialmente soleado con tormentas de chubascos';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Lluvia ligera';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Lluvia';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Rafagas';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Mayormente nublado con rafagas';   }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Parcialmente soleado con rafagas';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Rafagas de nieve';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Lluvia de nieve';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Nieve';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Mayormente nublado con nieve';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Hielo';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Aguanieve';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Lluvia helada';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Mezcla de lluvia y nieve';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Calor';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Frio';   }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Viento';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Despejado';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Mayormente despejado';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Parcialmente despejado';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Brumoso';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Parcialmente nublado con chubascos';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Mayormente nublado con chubascos';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Parcialmente nublado con tormentas de chubascos';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Brumoso';	 }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Nieve ligera'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Lluvias de nieve ligeras'; }       
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Chubascos';    }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Llovizna';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Lluvia y aguanieve';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Nieve y aguanieve';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas severas';	 }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Huracan';	  }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tormenta tropical';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado';	}
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Llovizna helada';	  }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Viento y nieve'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Granizo'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Polvo';	}
			if (translatedesc=='smoky') { document.getElementById("desc").innerHTML='Humo';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Tempestad';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Lluvia y granizo';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas aisladas';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Tormentas aisladas';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas dispersas';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Chubascos dispersos';	 }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Precipitaciones de nieve dispersas';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='LLuvia y tormenta ligera';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='No disponible';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Acumulacion de nieve y viento';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Lluvia ligera';	  }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Truenos'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Mayormente nublado y viento'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Tormenta de arena'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Chubascos y viento'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Arena'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Tormentas de arena y viento'; }
			document.getElementById("lastupdate").innerHTML = "Actualizado - " + currentTimeString + " " + timeOfDay;
			document.getElementById("humidity").innerHTML = "Humedad : " + obj.humidity + "%";		
			if (direction <= 360) obj.winddir = "N";
			if (direction < 348.75) obj.winddir = "N-NO";		
			if (direction < 326.25) obj.winddir = "NO";		
			if (direction < 303.75) obj.winddir = "O-NO";
			if (direction < 281.25) obj.winddir = "O";		
			if (direction < 258.75) obj.winddir = "O-SO";		
			if (direction < 236.25) obj.winddir = "SO";
			if (direction < 213.75) obj.winddir = "S-SO";		
			if (direction < 191.25) obj.winddir = "S";		
			if (direction < 168.75) obj.winddir = "S-SE";
			if (direction < 146.25) obj.winddir = "SE";		
			if (direction < 123.75) obj.winddir = "E-SE";		
			if (direction < 101.25) obj.winddir = "E";		
			if (direction < 78.75) obj.winddir = "E-NE";		
			if (direction < 56.25) obj.winddir = "NE";
			if (direction < 33.75) obj.winddir = "N-NE";		
			if (direction < 11.25) obj.winddir = "N";
			if (direction == 0) obj.winddir = "No hay viento";
			if (direction == 0) {
					document.getElementById("wind").innerHTML = "Viento : " + obj.winddir;				
					} else {
					document.getElementById("wind").innerHTML = "Viento : " + obj.winddir + " - " + Math.round(obj.windspeed) + " " + obj.windunit;	}		
		break;
		default: 			
			document.getElementById("desc").innerHTML=obj.description;
			document.getElementById("lastupdate").innerHTML = "Last update - " + currentTimeString + " " + timeOfDay;
			document.getElementById("humidity").innerHTML = "Humidity : " + obj.humidity + "%";
			if (direction <= 360) obj.winddir = "N";
			if (direction < 348.75) obj.winddir = "N-NW";		
			if (direction < 326.25) obj.winddir = "NW";		
			if (direction < 303.75) obj.winddir = "W-NW";
			if (direction < 281.25) obj.winddir = "W";		
			if (direction < 258.75) obj.winddir = "W-SW";		
			if (direction < 236.25) obj.winddir = "SW";
			if (direction < 213.75) obj.winddir = "S-SW";		
			if (direction < 191.25) obj.winddir = "S";		
			if (direction < 168.75) obj.winddir = "S-SE";
			if (direction < 146.25) obj.winddir = "SE";		
			if (direction < 123.75) obj.winddir = "E-SE";		
			if (direction < 101.25) obj.winddir = "E";		
			if (direction < 78.75) obj.winddir = "E-NE";		
			if (direction < 56.25) obj.winddir = "NE";
			if (direction < 33.75) obj.winddir = "N-NE";		
			if (direction < 11.25) obj.winddir = "N";
			if (direction == 0) obj.winddir = "No wind";			
			if (direction == 0) {
								document.getElementById("wind").innerHTML = "Wind : " + obj.winddir;				
								} else {
								document.getElementById("wind").innerHTML = "Wind : " + obj.winddir + " - " + Math.round(obj.windspeed) + " " + obj.windunit; }		
		break;
		}
		
		// SUNSET/SUNRISE FORMAT
		sunriseh = obj.sunrise.substring(0,obj.sunrise.indexOf(":",0));
		sunrisem = obj.sunrise.substring(obj.sunrise.indexOf(":",0)+1,obj.sunrise.indexOf(" ",0));
		sunseth = obj.sunset.substring(0,obj.sunset.indexOf(":",0));
		sunsetm = obj.sunset.substring(obj.sunset.indexOf(":",0)+1,obj.sunset.indexOf(" ",0));
		sunriseh = parseInt(sunriseh) + GMT;
		sunseth = parseInt(sunseth) + GMT;
		sunseth = sunseth + 12;
		
		// DAY AND NIGHT DURATION
		dayhour = parseInt(sunriseh) + parseInt(sunrisem)/60;
		nighthour = parseInt(sunseth) + parseInt(sunsetm)/60;
		DurationOfDay = nighthour - dayhour;
		DurationOfNight = 24 - DurationOfDay;
		
		if (ampm == false)
		{
		var sunriseh = ( sunriseh < 10 ? "0" : "" ) + sunriseh;
		var sunseth = ( sunseth < 10 ? "0" : "" ) + sunseth;
		obj.sunrise = sunriseh + ":" + sunrisem;		
		obj.sunset = sunseth + ":" + sunsetm;
		}
		else
		{
		var timeOfSunset = ( sunseth < 12 ) ? "am" : "pm";
		var timeOfSunrise = ( sunriseh < 12 ) ? "am" : "pm";
		sunriseh = ( sunriseh > 12 ) ? sunriseh - 12 : sunriseh;
		sunriseh = ( sunriseh == 0 ) ? 12 : sunriseh;
		sunseth = ( sunseth > 12 ) ? sunseth - 12 : sunseth;
		sunseth = ( sunseth == 0 ) ? 12 : sunseth;
		obj.sunrise = sunriseh + ":" + sunrisem + " " + timeOfSunrise;	
		obj.sunset = sunseth + ":" + sunsetm + " " + timeOfSunset;
		}
		
		if (SunsetSunrise == true)
		{
		document.getElementById("sunset").innerHTML = obj.sunset;		
		document.getElementById("sunrise").innerHTML = obj.sunrise;
		document.getElementById("sunrise").style.display = "block";
		document.getElementById("sunset").style.display = "block";
		}
				
		// POSITION OF SUN/MOON
		if ((time_to_change_wall < dayhour) || (time_to_change_wall > nighthour)) {
				where = "night";
				if (time_to_change_wall < dayhour) { time_to_change_wall = time_to_change_wall +24 };
				pTranslate = parseInt(((time_to_change_wall - nighthour)/ DurationOfNight)*320);
				document.getElementById("moon").style.webkitTransform = "translateX("+pTranslate+"px)";
				document.getElementById("moonray").style.webkitTransform = "translateX("+pTranslate+"px)";
				document.getElementById("weatherWall").src="Images/day_night/night.png";				
		} else {
				where = "day";
				pTranslate = parseInt(((time_to_change_wall - dayhour)/ DurationOfDay)*320);
				document.getElementById("sun").style.webkitTransform = "translateX("+pTranslate+"px)";
				document.getElementById("sunray").style.webkitTransform = "translateX("+pTranslate+"px)";
				document.getElementById("weatherWall").src="Images/day_night/day.png";
		}
		
		// WEATHER CONDITION
		var Conditions = [
			"thunderstorm",		//0 	tornado
			"thunderstorm",		//1 	tropical storm
			"thunderstorm",		//2 	hurricane
			"thunderstorm",		//3 	severe thunderstorms
			"thunderstorm",		//4 	thunderstorms
			"sleet",				//5 	mixed rain and snow
			"sleet",				//6 	mixed rain and sleet
			"sleet",				//7 	mixed snow and sleet
			"sleet",				//8 	freezing drizzle
			"showers_cloud",	//9 	drizzle
			"sleet",				//10 	freezing rain
			"showers_cloud",	//11 	showers
			"rain",				//12 	showers
			"snow",				//13 	snow flurries
			"snow",				//14 	light snow showers
			"snow",				//15 	blowing snow
			"snow",				//16 	snow
			"hail",				//17 	hail
			"sleet",				//18 	sleet
			"fog",				//19 	dust
			"fog",				//20 	foggy
			"haze",				//21 	haze
			"fog",				//22 	smoky
			"wind",				//23 	blustery
			"wind",				//24 	windy
			"frost",				//25 	cold
			"cloud",				//26 	cloudy
			"partlycloudy",		//27 	mostly cloudy (night)
			"partlycloudy",		//28 	mostly cloudy (day)
			"partlycloudy",		//29 	partly cloudy (night)
			"partlycloudy",		//30 	partly cloudy (day)
			"moon",				//31 	clear (night)
			"sun",				//32 	sunny
			"partlycloudy",		//33 	fair (night)
			"partlycloudy",		//34 	fair (day)
			"sleet",				//35 	mixed rain and hail
			"sun",				//36 	hot
			"thunderstorm",		//37 	isolated thunderstorms
			"thunderstorm",		//38 	scattered thunderstorms
			"thunderstorm",		//39 	scattered thunderstorms
			"showers_cloud",	//40 	scattered showers
			"snow",				//41 	heavy snow
			"snow",				//42 	scattered snow showers
			"snow",				//43 	heavy snow
			"partlycloudy",		//44 	partly cloudy
			"thunderstorm",		//45 	thundershowers
			"snow",				//46 	snow showers
			"thunderstorm",		//47 	isolated thundershowers
			"blank"];			//3200 	not available
			
		if (filename == "") {
		filename = Conditions[obj.icon];
		whereOld = where;
		loadjscssfile ("Weather", filename, "css");
		loadjscssfile ("Weather", filename, "js");
		//alert(filename);
		
		}
		else
		{
		if ((Conditions[obj.icon] != filename ) || (where != whereOld)) {
			whereOld = where;
			delelement("frameContainer");
			delelement("cloudContainer");
			delelement("dropContainer");
			replacejscssfile("Weather", filename, Conditions[obj.icon], "css");
			replacejscssfile("Weather", filename, Conditions[obj.icon], "js");
			filename = Conditions[obj.icon];	

			}
		}
	}
	else
	{
	document.getElementById("lastupdate").innerHTML = "Internet ?!";
	document.getElementById("desc").innerHTML = "...";

	}
}

function delelement(elem) {
var element = document.getElementById(elem);
while (element.firstChild) { element.removeChild(element.firstChild); }
}

function loadjscssfile(url, filename, filetype){
if (filetype=="js") {
	var fileref = document.createElement("script");
	fileref.type = "text/javascript";
	fileref.charset = "utf-8";
	fileref.src = "JavaScript/" + url + "/" + filename + ".js";
 }
if (filetype=="css") {
	var fileref = document.createElement("link");
	fileref.rel = "stylesheet";
	fileref.href = "Css/" + url + "/" + filename + ".css";
	fileref.type = "text/css";
	fileref.media = "screen";
 }
document.getElementsByTagName("head")[0].appendChild(fileref);
}

function createjscssfile(url, filename, filetype){
if (filetype=="js") {
	var fileref = document.createElement("script");
	fileref.type = "text/javascript";
	fileref.charset = "utf-8";
	fileref.src = "JavaScript/" + url + "/" + filename + ".js";
 }
if (filetype=="css") {
	var fileref = document.createElement("link");
	fileref.rel = "stylesheet";
	fileref.href = "Css/" + url + "/" + filename + ".css";
	fileref.type = "text/css";
	fileref.media = "screen";
 }
return fileref;
}

function replacejscssfile(url, oldfilename, newfilename, filetype){
var targetelement = (filetype=="js")? "script" : (filetype=="css")? "link" : "none";
var targetattr = (filetype=="js")? "src" : (filetype=="css")? "href" : "none";
var allsuspects = document.getElementsByTagName(targetelement);
for (var i = allsuspects.length; i>=0; i--) { 
		if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(oldfilename)!=-1) {
			var newelement = createjscssfile(url, newfilename, filetype);
			allsuspects[i].parentNode.replaceChild(newelement, allsuspects[i]);
			}
	}
}

function findChild (element, nodeName) {
	var child;
	for (child = element.firstChild; child != null; child = child.nextSibling)
	{
		if (child.nodeName == nodeName)
			return child;
	}
	return null;
}




function convertWoeidzip () {
urlcode=localStorage.getItem('urlcode');
if(urlcode=="false"){
zip=localStorage.getItem('locale');
weatherRefresherTemp(zip);
}

if(urlcode=="true"){
//postal=localStorage.getItem('locale');
var url = "http://weather.yahooapis.com/forecastrss?w="+postal+"&u=f";
		$.get(url, function(data) {
		postal = $(data).find('guid').text().split('_')[0];
		weatherRefresherTemp(postal);
		});
	}
	

}



function setPostal(obj){


	if (obj.error == false){

		if(obj.cities.length > 0) {
			postal = escape(obj.cities[0].zip).replace(/^%u/g, "%")
			convertWoeidzip();
			}
			else
			{
			document.getElementById("city").innerHTML="Locale ?!";
			}
		}
		else
		{
		document.getElementById("city").innerHTML="Locale ?!";
		setTimeout('validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)', Math.round(1000*60*5));
		}
}

function fetchWeatherData (callback, zip) {
temps=localStorage.getItem("isCelsius");
if(temps=="true"){
	tempUnit="c";
}
if(temps=="false"){
	tempUnit="f";
}

	var url="http://xml.weather.yahoo.com/forecastrss/" + zip + "_" + tempUnit + ".xml";

	var xml_request = new XMLHttpRequest();
	var requestTimer = setTimeout(function() {
	xml_request.abort();
	if (xmldata == false) { callback ({error:true}); } else {
	document.getElementById("coordinates").style.color = "red"; 
	document.getElementById("coordinates").innerHTML = "[Offline]"; }
    }, 10000);
	xml_request.onload = function(e) {
	clearTimeout(requestTimer);
	xml_loaded(e, xml_request, callback);
	}
	xml_request.overrideMimeType("text/xml");
	xml_request.open("GET", url);
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null);
	return xml_request;
}

function xml_loaded (event, request, callback) {
	if (request.responseXML)
	{
		var obj = {error:false, errorString:null};
		xmldata = true;
		var effectiveRoot = findChild(findChild(request.responseXML, "rss"), "channel");
		obj.city = findChild(effectiveRoot, "yweather:location").getAttribute("city");
		obj.humidity = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("humidity");
		obj.windunit = findChild(effectiveRoot, "yweather:units").getAttribute("speed");		
		obj.winddir = findChild(effectiveRoot, "yweather:wind").getAttribute("direction");
		obj.windspeed = findChild(effectiveRoot, "yweather:wind").getAttribute("speed");		
		obj.sunrise = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunrise");
		obj.sunset = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunset");
		var conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
		obj.temp = conditionTag.getAttribute("temp");
		obj.icon = conditionTag.getAttribute("code");
		obj.description = conditionTag.getAttribute("text");
		var forecast = findChild(findChild(effectiveRoot, "item"), "yweather:forecast");
		obj.todaylow = forecast.getAttribute("low");
		obj.todayhigh = forecast.getAttribute("high");
		if (obj.icon == 3200) obj.icon = 48;
		callback (obj); 
	}
	else
	{
		callback ({error:true, errorString:"XML request failed. no responseXML"});
	}
	}
