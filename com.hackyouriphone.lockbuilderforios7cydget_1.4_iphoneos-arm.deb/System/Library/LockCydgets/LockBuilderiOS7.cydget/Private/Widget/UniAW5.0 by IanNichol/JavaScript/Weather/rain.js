// Rain condition
// UniAW5.0 By Ian Nicoll with credit to Dacal

var NUMBER_OF_CLOUDS = 8; // clouds to show on screen
var NUMBER_OF_CLOUDS_IMAGES = 17; // images + 1
var NUMBER_OF_drop = 8; // drop to show on screen
var NUMBER_OF_DROP_IMAGES = 9; // images + 1
var container1 = document.getElementById("cloudContainer");
var container2 = document.getElementById("dropContainer");
if (where == "day") {
document.getElementById("moon").style.display='none';
document.getElementById("sun").style.display='none';
document.getElementById("moonray").style.display='none';
document.getElementById("sunray").style.display='none';
} else {
document.getElementById("moon").style.display='none';
document.getElementById("sun").style.display='none';
document.getElementById("moonray").style.display='none';
document.getElementById("sunray").style.display='none';
}
document.getElementById("weatherWall").style.display='block';

for (var i = 0; i < NUMBER_OF_CLOUDS; i++)
{
container1.appendChild(createACloud());
}

for (var i = 0; i < NUMBER_OF_drop; i++)
{
container2.appendChild(createAdrop());
}

function randomInteger(low, high) {
    return low + Math.floor(Math.random() * (high - low));
}
function randomFloat(low, high) {
    return low + Math.random() * (high - low);
}
function pixelValue(value) {
    return value + "px";
}
function durationValue(value) {
    return value + "s";
}

function createACloud() {
    var cloudDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "Images/Weather/cloud/" + where + "/cloud" + randomInteger(1, NUMBER_OF_CLOUDS_IMAGES) + ".png";
    cloudDiv.style.top = pixelValue(randomInteger(-55, 25));
    cloudDiv.style.left = pixelValue(randomInteger(-220, -40));
    cloudDiv.style.webkitAnimationName = "fade, float";
    var fadeAndfloatDuration = durationValue(randomFloat(40, 100));
    cloudDiv.style.webkitAnimationDuration = fadeAndfloatDuration + ", " + fadeAndfloatDuration;
    cloudDiv.appendChild(image);
    return cloudDiv;
}

function createAdrop() {
    var dropDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "Images/Weather/rain/drop" + randomInteger(1, NUMBER_OF_DROP_IMAGES) + ".png";
    dropDiv.style.top = pixelValue(randomInteger(-30, 80));
    dropDiv.style.left = pixelValue(randomInteger(10, 310));
    dropDiv.style.webkitAnimationName = "fade2, drop";
    var fadeAndDropDuration = durationValue(randomFloat(2, 4));
    dropDiv.style.webkitAnimationDuration = fadeAndDropDuration + ", " + fadeAndDropDuration;
    dropDiv.appendChild(image);
    return dropDiv;
}

document.getElementById("wiper").style.display='block';
document.getElementById("streak").style.display='block';