


$(window).load(function(){
jQuery.cookie = function (key, value, options) {

    // key and at least value given, set cookie...
    if (arguments.length > 1 && String(value) !== "[object Object]") {
  options = jQuery.extend({}, options);

  if (value === null || value === undefined) {
      options.expires = -1;
  }

  if (typeof options.expires === 'number') {
      var days = options.expires, t = options.expires = new Date();
      t.setDate(t.getDate() + days);
  }

  value = String(value);

  return (document.cookie = [
      encodeURIComponent(key), '=',
      options.raw ? value : encodeURIComponent(value),
      options.expires ? '; expires=' + options.expires.toUTCString() : '', 
      options.path ? '; path=' + options.path : '',
      options.domain ? '; domain=' + options.domain : '',
      options.secure ? '; secure' : ''
  ].join(''));
    }

    options = value || {};
    var result, decode = options.raw ? function (s) { return s; } : decodeURIComponent;
    return (result = new RegExp('(?:^|; )' + encodeURIComponent(key) + '=([^;]*)').exec(document.cookie)) ? decode(result[1]) : null;
};


$('#reload').click( function() {
  maincolor=$("#background").css('background-color');
  localStorage.setItem('bgcolor',maincolor);
  window.parent.refreshing();
}); 


$('#dropshadow').click( function() {
  $('#horizrange').css('opacity', '1');
  $('#horizontal').css('opacity', '1');
  $('#shadowsrange').css('opacity', '1');
  $('#shadows').css('opacity', '1');
  $('#verticalrange').css('opacity', '1');
  $('#vertical').css('opacity', '1');
  $('#blurrange').css('opacity', '1');
  $('#blur').css('opacity', '1');
  $('#settingbackground').css('opacity', '1');
  $('#shadowmenus').css('display', 'block');

});  


});  


function save(){

  window.parent.reloadshadows();
}

function showValue(newValue)
{
 document.getElementById("shadowsrange").innerHTML="Shadow "+newValue;
 localStorage.setItem('shadows',newValue);
  window.parent.reloadshadows();
 //window.parent.reloadshadows();
}
function showValue2(newValue)
{
 document.getElementById("horizrange").innerHTML="Horizontal "+newValue;
 localStorage.setItem('horizontal',newValue);
  window.parent.reloadshadows();
}

function showValue3(newValue)
{
 document.getElementById("verticalrange").innerHTML="Vertical "+newValue;
 localStorage.setItem('vertical',newValue);
  window.parent.reloadshadows();
}

function showValue4(newValue)
{
 document.getElementById("blurrange").innerHTML="Blur "+newValue;
 localStorage.setItem('blur',newValue);
  window.parent.reloadshadows();
}