var updateWeatherEvery = updateInterval*60*1000;
var xmldata = false;
var postal;
var refreshLocationTimer;
var updateTimer = 0;
var zip;
var ChangeClick = true;
var displayswitch = false;


function touchEnd(event) {
if ( displayswitch == false ) {
document.getElementById('Overlay').style.webkitAnimationName = "layerMoveDown";
document.getElementById('Overlay').style.webkitAnimationDuration = "0.3s";
    
document.getElementById('btn').style.webkitAnimationName = "rotation";
document.getElementById('btn').style.webkitAnimationDuration = "0.3s";
document.getElementById('btn_up').style.webkitAnimationName = "up";
document.getElementById('btn_up').style.webkitAnimationDuration = "0.4s";
    
document.getElementById('Clock').style.webkitAnimationName = "Opacityii";
document.getElementById('Clock').style.webkitAnimationDuration = "0.3s";
document.getElementById('Calendar').style.webkitAnimationName = "Opacity_";
document.getElementById('Calendar').style.webkitAnimationDuration = "0.3s";

document.getElementById('cityname').style.webkitAnimationName = "Opacity_2";
document.getElementById('cityname').style.webkitAnimationDuration = "0.3s";
document.getElementById('weathericon').style.webkitAnimationName = "Opacity";
document.getElementById('weathericon').style.webkitAnimationDuration = "0.3s";
document.getElementById('temp').style.webkitAnimationName = "Opacity2";
document.getElementById('temp').style.webkitAnimationDuration = "0.3s";
    
document.getElementById('forecast').style.webkitAnimationName = "MoveDown";
document.getElementById('forecast').style.webkitAnimationDuration = "0.3s";
displayswitch = true;
}else{
document.getElementById('Overlay').style.webkitAnimationName = "layerMoveUp";
document.getElementById('Overlay').style.webkitAnimationDuration = "0.3s";
    
document.getElementById('btn').style.webkitAnimationName = "rotation_up";
document.getElementById('btn').style.webkitAnimationDuration = "0.3s";
document.getElementById('btn_up').style.webkitAnimationName = "down";
document.getElementById('btn_up').style.webkitAnimationDuration = "0.4s";
    
document.getElementById('Clock').style.webkitAnimationName = "OpacityUpii";
document.getElementById('Clock').style.webkitAnimationDuration = "0.3s";
document.getElementById('Calendar').style.webkitAnimationName = "Opacity_Up";
document.getElementById('Calendar').style.webkitAnimationDuration = "0.3s";

document.getElementById('cityname').style.webkitAnimationName = "Opacity_Up2";
document.getElementById('cityname').style.webkitAnimationDuration = "0.3s";
document.getElementById('weathericon').style.webkitAnimationName = "OpacityUp";
document.getElementById('weathericon').style.webkitAnimationDuration = "0.3s";
document.getElementById('temp').style.webkitAnimationName = "OpacityUp2";
document.getElementById('temp').style.webkitAnimationDuration = "0.3s";
    
document.getElementById('forecast').style.webkitAnimationName = "MoveUp";
document.getElementById('forecast').style.webkitAnimationDuration = "0.3s";
displayswitch = false;}
}


switch (lang) {
case "fr":
	var days = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
	var months=['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre'];
break;
case "de":
	var days = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];
	var months=["Januar","Februar","Marz","April","Mai","Juni","Juli","August","September ","Oktober","November","Dezember"];
break;
case "sp":
	var days = ["Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"];
	var months=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
break;
case "it":
	var days = ["Domenica","Lunedi","Martedi","Mercoledi","Giovedi","Venerdi","Sabato"];
	var months=['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];
break;
default: 
	var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	var months=["January","February","March","April","May","June","July","August","September","October","November","December"];
break;
}

function ForecastDayNames(day) {

switch (day) {
case "Sun": { return days[0]; }
case "Mon": { return days[1]; }
case "Tue": { return days[2]; }
case "Wed": { return days[3]; }
case "Thu": { return days[4]; }
case "Fri": { return days[5]; }
case "Sat": { return days[6]; }
case "Today": { return "Today"; }
case "Tonight": { return "Tonight"; }}
}

function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentYear = currentTime.getFullYear();
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

if (Clock == "24h") {
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
       document.getElementById("hour").innerHTML = currentHours;
       document.getElementById("minute").innerHTML = currentMinutes;
       document.getElementById("ampm").innerHTML = timeOfDay;
}
if (Clock == "12h") {
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
       document.getElementById("hour").innerHTML = currentHours;
       document.getElementById("minute").innerHTML = currentMinutes;
       document.getElementById("ampm").innerHTML = timeOfDay;
}

document.getElementById("hour").innerHTML = currentHours;
document.getElementById("minute").innerHTML = currentMinutes;
document.getElementById("ampm").innerHTML = timeOfDay;	 
    
document.getElementById("Calendar").innerHTML = days[currentTime.getDay()] + ", " + months[currentTime.getMonth()] + " " + currentDate;
    if (lang == "fr") {
	document.getElementById("Calendar").innerHTML = days[currentTime.getDay()] + " " + currentDate + " " + months[currentTime.getMonth()];
    }
    if (lang == "sp") {
	document.getElementById("Calendar").innerHTML = days[currentTime.getDay()] + ", " + currentDate + " " + months[currentTime.getMonth()];
	}
    if (lang == "de") {
	document.getElementById("Calendar").innerHTML = days[currentTime.getDay()] + ", " + currentDate + ". " + months[currentTime.getMonth()];
	}
    if (lang == "it") {
	document.getElementById("Calendar").innerHTML = days[currentTime.getDay()] + " " + currentDate + " " + months[currentTime.getMonth()];
	}

if (currentTime.getTime() - updateTimer >= updateWeatherEvery) {
	if (updateTimer == 0) {
		if (gps == true) { UpdateLocation(); } else { validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal); }
		} else {
		weatherRefresherTemp(zip);
		}
	updateTimer = currentTime.getTime();
	}
}

 
function init(){
var el = document.getElementById("TouchLayer");
if ( ChangeClick == false ) {el.addEventListener("touchend", touchEnd, false);} 
else {el.addEventListener("click", touchEnd, false);}

document.getElementById("cityname").innerHTML = "Loading..";

updateClock();
setInterval("updateClock();", 1000);
}


function setPostal(obj){
	if (obj.error == false){
		if(obj.cities.length > 0) {
			postal = escape(obj.cities[0].zip).replace(/^%u/g, "%")
			convertWoeid();
			}
			else
			{
			document.getElementById("city").innerHTML="Locale ?!";
			}
		}
		else
		{
		document.getElementById("city").innerHTML="Locale ?!";
		setTimeout('validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)', Math.round(1000*60*5));
		}
}

function weatherRefresherTemp(zip){
	fetchWeatherData(dealWithWeather, zip);
	var refreshWeatherTimerNormal = setTimeout('weatherRefresherTemp(zip)', updateWeatherEvery);
}

function validateWeatherLocation (location, callback) {
	var obj = {error:false, errorString:null, cities: new Array};
	obj.cities[0] = {zip: location};
	callback (obj);
}

function dealWithWeather(obj){
	if (obj.error == false){
		document.getElementById("cityname").innerHTML = obj.city;
		document.getElementById("temp").innerHTML = obj.temp + "&#176;";	       
		document.getElementById("desc").innerHTML=obj.description;
		document.getElementById("weathericon").src="Icons/" + WeatherSet +"/"+ obj.icon +".png";	
		
document.getElementById("Day1").innerHTML=ForecastDayNames(obj.Day1);
document.getElementById("Day1Icon").src="Icons/" + WeatherSet +"/" + obj.Day1Code +".png";
document.getElementById("Day1HiLo").innerHTML=obj.Day1Lo+ "&#176;/ "+ obj.Day1Hi + "&#176;";

document.getElementById("Day2").innerHTML=ForecastDayNames(obj.Day2);
document.getElementById("Day2Icon").src="Icons/" + WeatherSet+"/" + obj.Day2Code +".png";
document.getElementById("Day2HiLo").innerHTML=obj.Day2Lo+ "&#176;/ " +obj.Day2Hi+ "&#176;";

document.getElementById("Day3").innerHTML=ForecastDayNames(obj.Day3);
document.getElementById("Day3Icon").src="Icons/" + WeatherSet+"/" + obj.Day3Code +".png";
document.getElementById("Day3HiLo").innerHTML=obj.Day3Lo+ "&#176;/ "+obj.Day3Hi+ "&#176;";

document.getElementById("Day4").innerHTML=ForecastDayNames(obj.Day4);
document.getElementById("Day4Icon").src="Icons/" + WeatherSet+"/"+ obj.Day4Code +".png";
document.getElementById("Day4HiLo").innerHTML=obj.Day4Lo+ "&#176;/ " + obj.Day4Hi+ "&#176;";
}
}

function findChild (element, nodeName) {
	var child;
	for (child = element.firstChild; child != null; child = child.nextSibling)
	{
		if (child.nodeName == nodeName)
			return child;
	}
	return null;
}

function convertWoeid () {
		var url = "http://weather.yahooapis.com/forecastrss?w="+postal+"&u=f";
		$.get(url, function(data) {
		zip = $(data).find('guid').text().split('_')[0];
		weatherRefresherTemp(zip);
		});
}

// Get data with woeid (no GPS)
function fetchWeatherData (callback, zip) {
	var url="http://xml.weather.yahoo.com/forecastrss/" + zip + "_" + tempUnit + ".xml";
	var xml_request = new XMLHttpRequest();
	var requestTimer = setTimeout(function() {
	xml_request.abort();
	if (xmldata == false) { callback ({error:true}); } else {
	document.getElementById("coordinates").style.color = "red"; 
	document.getElementById("coordinates").innerHTML = "[Offline]"; }
    }, 10000);
	xml_request.onload = function(e) {
	clearTimeout(requestTimer);
	xml_loaded(e, xml_request, callback);
	}
	xml_request.overrideMimeType("text/xml");
	xml_request.open("GET", url);
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null);
	return xml_request;
}

function xml_loaded (event, request, callback) {
	if (request.responseXML)
	{
		var obj = {error:false, errorString:null};
		xmldata = true;
		var effectiveRoot = findChild(findChild(request.responseXML, "rss"), "channel");
		if (gps == false) {
		if (city == "") { obj.city = findChild(effectiveRoot, "yweather:location").getAttribute("city"); }
		else { obj.city = city }
		} else { obj.city = city; }
		obj.humidity = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("humidity");
		obj.windunit = findChild(effectiveRoot, "yweather:units").getAttribute("speed");		
		obj.winddir = findChild(effectiveRoot, "yweather:wind").getAttribute("direction");
		obj.windspeed = findChild(effectiveRoot, "yweather:wind").getAttribute("speed");	
		obj.visibility = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("visibility");	
		obj.visibilityunit = findChild(effectiveRoot, "yweather:units").getAttribute("distance");
		obj.sunrise = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunrise");
		obj.sunset = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunset");
		obj.chill = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");
		obj.realFeel = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");
		var conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
		obj.temp = conditionTag.getAttribute("temp");
		obj.icon = conditionTag.getAttribute("code");
		obj.description = conditionTag.getAttribute("text");
		var forecast = findChild(findChild(effectiveRoot, "item"), "yweather:forecast");
		obj.todaylow = forecast.getAttribute("low");
		obj.todayhigh = forecast.getAttribute("high");
		if (obj.description == "Unknown") {
			obj.description = forecast.getAttribute("text");
			obj.icon = forecast.getAttribute("code");
		}
		if (obj.icon == 3200) obj.icon = 48
	
	obj.Day1 = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("day");
		obj.Day1Hi = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("high");
		obj.Day1Lo = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("low");
		obj.Day1Code = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("code");
		
		obj.Day2 = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("day");
		obj.Day2Hi = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("high");
		obj.Day2Lo = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("low");
		obj.Day2Code = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("code");
		
		obj.Day3 = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("day");
		obj.Day3Hi = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("high");
		obj.Day3Lo = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("low");
		obj.Day3Code = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("code");
		
		obj.Day4 = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("day");
		obj.Day4Hi = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("high");
		obj.Day4Lo = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("low");
		obj.Day4Code = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("code");
		
		
		callback (obj); 
	}
	else
	{
		callback ({error:true, errorString:"XML request failed. no responseXML"});
	}
}