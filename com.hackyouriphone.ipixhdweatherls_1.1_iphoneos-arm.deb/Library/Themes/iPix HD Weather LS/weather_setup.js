// Enter the name of your city, state or town. Default is London.

var locName="London";


// Enter your Zip or Post Code. Default is se3.

var loc="se3";


// Choose temperature unit, C for celsius or F for fahrenheit. Default is c.

var tempUnit="c";


//Change forecast background colour, available colours are red, blue, purple, green or black. Default is black.

var colour_scheme="black";


//Set clock format to 12 or 24 hour. Default is 24.

var format="24";