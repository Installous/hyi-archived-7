//*********************************************************************
//
//   iHrT - an original iPhone theme by storyr
//
//*********************************************************************
//   License
//
//   The iHrT theme and themePump (both by storyr) are licensed 
//   under the Creative Commons Attribution-NonCommercial-ShareAlike 
//   3.0 Unported License. To view a copy of this license, visit 
//   http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter 
//   to:  Creative Commons
//        171 Second Street, Suite 300
//        San Francisco, CA, 94105, USA
//
//   Permissions beyond the scope of this license may be available by 
//   emailing storyr@venusware.net
//*********************************************************************

$(document).ready(function () {
});

