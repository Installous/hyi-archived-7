var Scale = "0.8"; 
var Clock = "24h"; // choose between "12h" or "24h"
var refreshrate = 10; // update interval of weather, in minutes
var PlayerColor = ""; 
var TextColor = ""; 
var LineColor = "azure"; 
var DotColor = "coral"; 
var IndicatorBattColor = "tomato"; 
var WeatherIcon = 1; // 1= white, 2= black, 3= color
var DarkMode = false; 
var HidePlayer = false; 
var HideBattery = false; 
var CustomText = "Ali Maulana"; 
