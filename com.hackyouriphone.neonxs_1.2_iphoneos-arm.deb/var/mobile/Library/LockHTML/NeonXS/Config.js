var MainColor = "AntiqueWhite"; 
var YourName = "John"; 
var ShowAnimation = true; 
var CenterText = true;