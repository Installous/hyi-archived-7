var locName="London, UK"; // Change to the name of your city, state or town
var loc="E10AD"; // Change to your Zip or Postal Code for UK, US or Canada. For other countries please enter city name.
var tempUnit="c"; // Change to C for weather in celsius or F for farenheit.
