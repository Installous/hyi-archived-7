// Configuration here ! //
// By Dacal for Subywrex
// Adaptation for Native Weather
var gps = true; // Set to false for Native Weather
var tempUnit = "c"; // f for fahrenheit (needed only for GPS)
var ampm = false; // Set to true for 12h format
var updateInterval = 20; // in minutes
var lang = "fr"; // (fr) for french, (de) for german, (sp) for spanish, (it) for italian, (en) or anything else for english,(am) for us
var SecDisplay = false // true to display seconds - battery eater ! Don't use it with iSimply !
var AnimatedWeather = true; // false for static weather images only.
var SunsetSunrise = true; // Work only when GPS is set to ON
var GMT = 0; // Adjust tue hour of sunset and sunrise only if YahooWeather don't report correctly summer time