// Thunderstorm condition
// UniAW5.0 By Ian Nicoll with credit to Dacal

var NUMBER_OF_CLOUDS = 7; // clouds to show on screen
var NUMBER_OF_CLOUDS_IMAGES = 16; // images + 1
var NUMBER_OF_drop = 15; // drop to show on screen
var NUMBER_OF_DROP_IMAGES = 4; // images + 1
var container = document.getElementById("frameContainer");
var container1 = document.getElementById("cloudContainer");
var container2 = document.getElementById("dropContainer");
var container3 = document.getElementById("frameContainer");
var container4 = document.getElementById("frameContainer");
if (where == "day") {
document.getElementById("moon").style.display='none';
document.getElementById("sun").style.display='none';
document.getElementById("moonray").style.display='none';
document.getElementById("sunray").style.display='none';
container.appendChild(createAlight2());
container3.appendChild(createAlight());
container4.appendChild(createAlight3());
} else {
container.appendChild(createAlight2());
container3.appendChild(createAlight());
container4.appendChild(createAlight3());
document.getElementById("moon").style.display='none';
document.getElementById("sun").style.display='none';
document.getElementById("moonray").style.display='none';
document.getElementById("sunray").style.display='none';
}
document.getElementById("weatherWall").style.display='block';

for (var i = 0; i < NUMBER_OF_CLOUDS; i++)
{
container1.appendChild(createACloud());
}

for (var i = 0; i < NUMBER_OF_drop; i++)
{
container2.appendChild(createAdrop());
}

function randomInteger(low, high) {
    return low + Math.floor(Math.random() * (high - low));
}

function pixelValue(value) {
    return value + "px";
}

function durationValue(value) {
    return value + "s";
}

function randomFloat(low, high) {
    return low + Math.random() * (high - low);
}

function createAlight() {
    var image = document.createElement("img");
    image.id = "thunder";	
    image.src = "Images/Weather/thunderstorm/Thunder2.png";
    return image;
}
function createAlight2() {
    var image = document.createElement("img");
    image.id = "thunder2";	
    image.src = "Images/Weather/thunderstorm/Thunder1.png";
    return image;
}

function createAlight3() {
    var image = document.createElement("img");
    image.id = "thunder3";	
    image.src = "Images/Weather/thunderstorm/Thunder3.png";
    return image;
}
function createACloud() {
    var cloudDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "Images/Weather/cloud/" + where + "/cloud" + randomInteger(1, NUMBER_OF_CLOUDS_IMAGES) + ".png";
    cloudDiv.style.top = pixelValue(randomInteger(-15, 75));
    cloudDiv.style.left = pixelValue(randomInteger(-220, -40));
    cloudDiv.style.webkitAnimationName = "fade, float";
    var fadeAndfloatDuration = durationValue(randomFloat(40, 100));
    cloudDiv.style.webkitAnimationDuration = fadeAndfloatDuration + ", " + fadeAndfloatDuration;
    cloudDiv.appendChild(image);
    return cloudDiv;
}

function createAdrop() {
    var dropDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "Images/Weather/rain/drop" + randomInteger(1, NUMBER_OF_DROP_IMAGES) + ".png";
    dropDiv.style.top = pixelValue(randomInteger(-100, 50));
    dropDiv.style.left = pixelValue(randomInteger(10, 310));
    dropDiv.style.webkitAnimationName = "fade2, drop";
    var fadeAndDropDuration = durationValue(randomFloat(2, 4));
    dropDiv.style.webkitAnimationDuration = fadeAndDropDuration + ", " + fadeAndDropDuration;
    dropDiv.appendChild(image);
    return dropDiv;
}
