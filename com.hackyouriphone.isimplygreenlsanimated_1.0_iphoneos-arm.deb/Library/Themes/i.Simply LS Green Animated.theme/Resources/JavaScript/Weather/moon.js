// Moon condition
// UniAw5.0 by Ian Nicoll with credit to Dacal

if (where == "day") {
document.getElementById("moon").style.display='none';
document.getElementById("sun").style.display='block';
document.getElementById("moonray").style.display='none';
document.getElementById("sunray").style.display='block';
} else {
document.getElementById("moon").style.display='block';
document.getElementById("sun").style.display='none';
document.getElementById("moonray").style.display='block';
document.getElementById("sunray").style.display='none';
}
document.getElementById("weatherWall").style.display='block';
