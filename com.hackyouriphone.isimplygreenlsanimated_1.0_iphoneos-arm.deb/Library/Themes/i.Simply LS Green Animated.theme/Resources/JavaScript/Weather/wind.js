// Wind condition
// UniAW5.0 By Ian Nicoll with credit to Dacal

var NUMBER_OF_CLOUDS = 8; // clouds to show on screen
var NUMBER_OF_IMAGES = 9; // images + 1
var container = document.getElementById("cloudContainer");
if (where == "day") {
document.getElementById("moon").style.display='none';
document.getElementById("sun").style.display='block';
document.getElementById("moonray").style.display='none';
document.getElementById("sunray").style.display='block';
} else {
document.getElementById("moon").style.display='block';
document.getElementById("sun").style.display='none';
document.getElementById("moonray").style.display='block';
document.getElementById("sunray").style.display='none';
}
document.getElementById("weatherWall").style.display='block';

for (var i = 0; i < NUMBER_OF_CLOUDS; i++)
{
container.appendChild(createACloud());
}

function randomInteger(low, high) {
    return low + Math.floor(Math.random() * (high - low));
}
function randomFloat(low, high) {
    return low + Math.random() * (high - low);
}
function pixelValue(value) {
    return value + "px";
}
function durationValue(value) {
    return value + "s";
}
function createACloud() {
    var cloudDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "Images/Weather/wind/cloud" + randomInteger(1, NUMBER_OF_IMAGES) + ".png";
    cloudDiv.style.top = pixelValue(randomInteger(20, 350));
    cloudDiv.style.left = pixelValue(randomInteger(-80, 0));
    var spinAnimationName = (Math.random() < 0.5) ? "clockwiseSpin" : "counterclockwiseSpinAndFlip";
    cloudDiv.style.webkitAnimationName = "fade, float";
    image.style.webkitAnimationName = spinAnimationName;
    var fadeAndfloatDuration = durationValue(randomFloat(4, 8));
    var spinDuration = durationValue(randomFloat(6, 20));
    cloudDiv.style.webkitAnimationDuration = fadeAndfloatDuration + ", " + fadeAndfloatDuration;
    image.style.webkitAnimationDuration = spinDuration;
    cloudDiv.appendChild(image);
    return cloudDiv;
}

