(height, signalStrengthRaw, isTintBlack, extraOption, color)
{
	var lowerLimit = -130, upperLimit = -80;
	var range = Math.abs(lowerLimit - upperLimit);

	var percentage = 0;
	if (signalStrengthRaw <= lowerLimit) {
		percentage = 0;
	} else if (signalStrengthRaw >= upperLimit) {
		percentage = 1;
	} else {
		percentage = (signalStrengthRaw - lowerLimit) / range;
	}

	var
		canvas = document.createElement("canvas"),
		context = canvas.getContext("2d"),
		spacer = Math.round(height / 20.0),
		barWidth = Math.round(height / 7),
		barHeight = height / 2.0,
		mainColor = "rgb(" + color.join() + ")",
		secondColor = "rgba(" + color.join() + ",0.3)",
		canvasHeight = height,
		canvasWidth = Math.round(barWidth * 5 + 4 * spacer);

	canvas.width = canvasWidth * 3;
	canvas.height = canvasHeight;

	var y1 = (canvasHeight - barHeight) / 2;
	var y2 = barHeight + y1;
	fillWidth = Math.round(percentage * canvasHeight);

	context.fillStyle = secondColor;
	context.save();
	context.beginPath();
	context.moveTo(0, y2);
	context.lineTo(canvasWidth, y2);
	context.lineTo(canvasWidth, y1);
	context.fill();
	context.clip();
	context.fillStyle = mainColor;
	context.fillRect(0, y1, fillWidth, barHeight);
	context.restore();
	context.fillStyle = mainColor;

	var fontHeight = 0.45 * height;

	context.font = fontHeight + "pt -apple-system";
	context.textAlign = "left";
	context.textBaseline = "middle";
	context.fillText(-signalStrengthRaw, canvasWidth + 4 * spacer, height / 2);

	var
		croppedCanvas = document.createElement("canvas"),
		croppedContext = croppedCanvas.getContext("2d");

	croppedCanvas.width = canvasWidth + 4 * spacer + context.measureText(-signalStrengthRaw).width;
	croppedCanvas.height = canvasHeight;

	croppedContext.drawImage(canvas, 0, 0);

	return croppedCanvas.toDataURL("image/png");
}
