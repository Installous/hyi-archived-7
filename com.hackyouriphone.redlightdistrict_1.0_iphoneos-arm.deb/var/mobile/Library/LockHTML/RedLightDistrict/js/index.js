var Messenger = function(el){
  'use strict';
  var m = this;
  
  m.init = function(){
    m.codeletters = "&#*+%?£@§$";
    m.message = 0;
    m.current_length = 0;
    m.fadeBuffer = false;
	//--------------------
	var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
	var months = ['january','february','march','april','may','june','july','august','september','october','november','december'];
	Date.prototype.getMonthName = function() {
		return months[ this.getMonth() ];
	};
	Date.prototype.getDayName = function() {
		return days[ this.getDay() ];
	};
	function formatAMPM() {
		var date = new Date();
		var hours = date.getHours();
		var minutes = date.getMinutes();
		var month = date.getMonthName();
		var year = date.getFullYear();
		
		if (hours < 12) {
			var xSalutation = 'Good Morning';
		} else if (hours < 18) {
			var xSalutation = 'Good Afternoon';
		} else {
			var xSalutation = 'Good Evening';
		}
		
		var ampm = hours >= 12 ? 'PM' : 'AM';
		if (!ShowAMPM) {
			ampm = "";
		}
		hours = hours % 12;
		hours = hours ? hours : 12;
		minutes = minutes < 10 ? '0'+minutes : minutes;
		
		var strTime = hours + ':' + minutes + ' ' + ampm;
		
		var preDate = date.getDate();
		var finalDate = ordinal_suffix_of(preDate);
		var FinalDate2 = finalDate + " " + month + " " + year;
		
		function ordinal_suffix_of(i) {
			var finalDate = i % 10, k = i % 100;
			if (finalDate == 1 && k != 11) {
				return i + "st";
			}
			if (finalDate == 2 && k != 12) {
				return i + "nd";
			}
			if (finalDate == 3 && k != 13) {
				return i + "rd";
			}
			return i + "th";
		}
		//if (timeOnly) {
		//	m.messages = [ strTime ];
		//} else {
			//m.messages = [ xSalutation, strTime, FinalDate2 ];
			m.messages = [ xSalutation, "Welcome Back " + YourName, FinalDate2 ];
		//}
	}	
	var date = new Date();
	var hours = date.getHours();
	var minutes = date.getMinutes();
	var month = date.getMonthName();
	var year = date.getFullYear();
	var ampm = hours >= 12 ? 'PM' : 'AM';
	
	if (hours < 12) {
		var xSalutation = 'Good Morning';
	} else if (hours < 18) {
		var xSalutation = 'Good Afternoon';
	} else {
		var xSalutation = 'Good Evening';
	}
	
	hours = hours % 12;
	hours = hours ? hours : 12;
	minutes = minutes < 10 ? '0'+minutes : minutes;
	
	var strTime = hours + ':' + minutes + ' ' + ampm;
	var preDate = date.getDate();
	var finalDate = ordinal_suffix_of(preDate);
	var FinalDate2 = finalDate + " " + month + " " + year;
	

	
	function ordinal_suffix_of(i) {
		var finalDate = i % 10, k = i % 100;
		if (finalDate == 1 && k != 11) {
			return i + "st";
		}
		if (finalDate == 2 && k != 12) {
			return i + "nd";
		}
		if (finalDate == 3 && k != 13) {
			return i + "rd";
		}
		return i + "th";
	}
	setInterval(formatAMPM, 1000);
	
	//--------------------
    //if (timeOnly) {
	//	m.messages = [ strTime ];
	//} else {
		m.messages = [ xSalutation, "Welcome Back " + YourName, FinalDate2 ];
	//}
	console.log("Updating Time");
    setTimeout(m.animateIn, 100);
  };
  
  m.generateRandomString = function(length){
    var random_text = '';
    while(random_text.length < length){
      random_text += m.codeletters.charAt(Math.floor(Math.random()*m.codeletters.length));
    } 
    
    return random_text;
  };
  
  m.animateIn = function(){
    if(m.current_length < m.messages[m.message].length){
      m.current_length = m.current_length + 2;
      if(m.current_length > m.messages[m.message].length) {
        m.current_length = m.messages[m.message].length;
      }
      
      var message = m.generateRandomString(m.current_length);
      $(el).html(message);
      
      setTimeout(m.animateIn, 20);
    } else { 
      setTimeout(m.animateFadeBuffer, 20);
    }
  };
  
  m.animateFadeBuffer = function(){
    if(m.fadeBuffer === false){
      m.fadeBuffer = [];
      for(var i = 0; i < m.messages[m.message].length; i++){
        m.fadeBuffer.push({c: (Math.floor(Math.random()*12))+1, l: m.messages[m.message].charAt(i)});
      }
    }
    
    var do_cycles = false;
    var message = ''; 
    
    for(var i = 0; i < m.fadeBuffer.length; i++){
      var fader = m.fadeBuffer[i];
      if(fader.c > 0){
        do_cycles = true;
        fader.c--;
        message += m.codeletters.charAt(Math.floor(Math.random()*m.codeletters.length));
      } else {
        message += fader.l;
      }
    }
    
    $(el).html(message);
    
    if(do_cycles === true){
		setTimeout(m.animateFadeBuffer, 50);
    } else {
		//setTimeout(m.cycleText, 2000);
		setTimeout(function() {
			console.log("Starting Next Cycle.");
			setTimeout(m.cycleText, 2000);
		}, (txtTimeOut * 1000));
    }
  };
  
  m.cycleText = function(){
    m.message = m.message + 1;
    if(m.message >= m.messages.length){
      m.message = 0;
    }
    
    m.current_length = 0;
    m.fadeBuffer = false;
    $(el).html('');
    
    setTimeout(m.animateIn, 200);
  };
  
  m.init();
}

console.clear();
var messenger = new Messenger($('#messenger'));