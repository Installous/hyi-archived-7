var ShowAMPM = false; 
var TwentyFourHour = true; 
var txtTimeOut = 5; 
var TimeSize = 135; 
var txtSize = 35; 
var YourName = "Aussie Appz"; 
