  /* Code by Dacal mod by DemoneLatino */

/* *************************************** */
/* ************* Weather  **************** */

// Use www.weather.com to find your weathercode
// For example searching for Milan Italy will get you this URL
// http://www.weather.com/weather/right-now/Milan+Italy+ITXX0042
// The last part ITXX0042 is the weathercode to use in "var locale"

var locale = "USMA0143" // leave "0" if you want to use the GPS or enter your code if you don't have GPS(myLocation) 

//you not have (GPS) "myLocation" download from cydia "GPS Weather Lockscreen" by crazyvivek(iOS 4.x - 5.0.1) or search on google the version compatible with iOS 5.1.1 or contact me via cydia for more support or talk with me on TWITTER @DemoneLatino

var updateInterval = 15	// refresh weather in minutes.

var iconSet = "stardock"  // you can add your set

var iconExt = ".png" // icons extension

var useRealFeel = false;  // true|false

var source = "yahooWeather"  // Don't touch here!!