var dev = "Kisanagii";
var elements = {"zclock":{"z-index":2,"color":"rgb(255, 255, 255)","font-family":"kanji","position":"absolute","font-size":"60px","top":99,"left":"88px","text-shadow":"rgba(0, 0, 0, 0.53) 1px 3px 4px"}};
var wIcon = null;
var wallpaper = "data:,";
var overlay = null;