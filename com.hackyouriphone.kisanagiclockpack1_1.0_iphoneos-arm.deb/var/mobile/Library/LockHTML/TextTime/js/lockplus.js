var dev = "Kisanagii";
var elements = {"ttext":{"z-index":2,"color":"white","font-family":"anders","position":"absolute","font-size":"23px","top":92,"left":"70px","width":"172px"},"month":{"z-index":2,"color":"white","font-family":"anders","position":"absolute","font-size":"12px","top":"129px","left":"107px"},"date":{"z-index":2,"color":"white","font-family":"aileronthin","position":"absolute","font-size":"14px","top":"128px","left":187}};
var wIcon = null;
var wallpaper = "data:,";
var overlay = null;