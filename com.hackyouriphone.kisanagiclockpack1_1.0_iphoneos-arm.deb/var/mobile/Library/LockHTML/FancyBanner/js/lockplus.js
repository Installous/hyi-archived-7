var dev = "Kisanagii";
var elements = {"boxOne":{"width":"320px","height":"102px","background-color":"rgba(255, 255, 255, 0.83)","z-index":1,"border-color":"red","border-style":"solid","border-width":"0px","position":"absolute","top":"97px","left":"0px","box-shadow":"rgb(0,0,0) -1px -1px 2px"},"clockpm":{"z-index":2,"color":"rgb(0, 0, 0)","font-family":"tiza","position":"absolute","font-size":"30px","top":"106px","left":"111px","font-weight":"900"},"datestringrev":{"z-index":2,"color":"rgb(0, 0, 0)","font-family":"signer","position":"absolute","font-size":"17px","top":"157px","left":"20px","font-weight":"900"}};
var wIcon = null;
var wallpaper = "data:,";
var overlay = null;