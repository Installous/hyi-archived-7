

var Clock = "12h";  // choose between "12h" or "24h"
var Lang = "en";   // choose between "en" or “”

var MyTwitter = "@imo7and";   // follow me on Twitter 