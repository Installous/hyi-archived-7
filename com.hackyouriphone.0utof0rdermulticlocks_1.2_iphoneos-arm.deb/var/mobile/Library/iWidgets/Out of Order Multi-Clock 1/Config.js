// WIDGET WEATHER iOS8 styled //

// Created by King O Hill and Marty McFly //



					     

var Second_Hand_Sweep = false;	//Set to false for the ticking effect

var scale = "None";			//"None" for iPhone 5 and lower, "6", "6+", "ipad"

var Clockface = "Clock1.png";		//select clock face, Clock1, Clock2, Clock3

var dateColor = "grey";
var ShowDate = "false";		//"true" to show date, "false" no date shown
