var twentyfourh = false; // true for 24 hr
var pad = true; // true to pad zero in hour
var textcolor = "black"; // Enter the color code or name you want. icon hex code #FF0000 or color name red...
var IconSet = "9"; // Select Weather Icon Pack 1,2,3,4,5,6,7,8,9,10,11,12,13
var Overlays = "6"; // Select Background 1,2,3,4,5,6
