 

var NUMBER_OF_BUBBLE = 15; // bubble to show on screen
	var NUMBER_OF_BUBBLE_IMAGES = 6; // images + 1
	var container = document.getElementById("container");
	var container2 = document.getElementById("container2");
	var container3 = document.getElementById("container3");
	for (var i = 0; i < NUMBER_OF_BUBBLE; i++) { container.appendChild(createAbubble()); }
	for (var i = 0; i < NUMBER_OF_BUBBLE; i++) { container2.appendChild(createAbubble2());}   
	for (var i = 0; i < NUMBER_OF_BUBBLE; i++) { container3.appendChild(createAbubble3());}  
function createAbubble() {
    var bubbleDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "Images/SBubble" + randomInteger(1, NUMBER_OF_BUBBLE_IMAGES) + ".png";
    bubbleDiv.style.top = pixelValue(randomInteger(-1136, 568));
    bubbleDiv.style.left = pixelValue(randomInteger(-640, 330));
    bubbleDiv.style.webkitAnimationName = "fadeDrop, drop";
    var fadeAndDropDuration = durationValue(randomFloat(60, 90));
    bubbleDiv.style.webkitAnimationDuration = fadeAndDropDuration + ", " + fadeAndDropDuration;
    bubbleDiv.appendChild(image);
    return bubbleDiv;
}

function createAbubble2() {
    var bubbleDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "Images/Bubble" + randomInteger(1, NUMBER_OF_BUBBLE_IMAGES) + ".png";
    bubbleDiv.style.top = pixelValue(randomInteger(-1136, 568));
    bubbleDiv.style.left = pixelValue(randomInteger(-640, 330));
    bubbleDiv.style.webkitAnimationName = "fadeDrop, drop";
    var fadeAndDropDuration = durationValue(randomFloat(30, 60));
    bubbleDiv.style.webkitAnimationDuration = fadeAndDropDuration + ", " + fadeAndDropDuration;
    bubbleDiv.appendChild(image);
    return bubbleDiv;
}

function createAbubble3() {
    var bubbleDiv = document.createElement("div");
    var image = document.createElement("img");
    image.src = "Images/MBubble" + randomInteger(1, NUMBER_OF_BUBBLE_IMAGES) + ".png";
    bubbleDiv.style.top = pixelValue(randomInteger(-1136, 568));
    bubbleDiv.style.left = pixelValue(randomInteger(-640, 330));
    bubbleDiv.style.webkitAnimationName = "fadeDrop, drop";
    var fadeAndDropDuration = durationValue(randomFloat(40, 80));
    bubbleDiv.style.webkitAnimationDuration = fadeAndDropDuration + ", " + fadeAndDropDuration;
    bubbleDiv.appendChild(image);
    return bubbleDiv;
}


function randomInteger(low, high) {
    return low + Math.floor(Math.random() * (high - low));
}
function randomFloat(low, high) {
    return low + Math.random() * (high - low);
}
function pixelValue(value) {
    return value + "px";
}
function durationValue(value) {
    return value + "s";
}
