//-----------------------------------------------------------------------------------------------------------
// Initial author : Vivek Thakur /  rewrite by Dacal
// Date : 17/05/2013
//-----------------------------------------------------------------------------------------------------------
 
var prevlatitude;
var prevlongitude;
var textLat;
var textLong;
var city;
var countrycode;
var statename;
var zipcode;
var town = new Array();
var postal = new Array();
var tempstate = new Array();
var tempcountrycode = new Array();
 
String.prototype.sansAccent = function() {
    var accent = [
        /[\300-\306]/g, /[\340-\346]/g, // A, a
        /[\310-\313]/g, /[\350-\353]/g, // E, e
        /[\314-\317]/g, /[\354-\357]/g, // I, i
        /[\322-\330]/g, /[\362-\370]/g, // O, o
        /[\331-\334]/g, /[\371-\374]/g, // U, u
        /[\321]/g, /[\361]/g, // N, n
        /[\307]/g, /[\347]/g, // C, c
    ];
    var noaccent = ['A','a','E','e','I','i','O','o','U','u','N','n','C','c'];
    var str = this;
    for(var i = 0; i < accent.length; i++){
        str = str.replace(accent[i], noaccent[i]);
    }
    return str;
}
 
// LOCAL REQUEST : UPDATE THE COORDINATES FROM MYLOCATION.TXT FILE
function UpdateLocation() {
    refreshLocationTimer = setTimeout(UpdateLocation, 20*1000);
    jQuery.get('file:///private/var/mobile/Documents/myLocation.txt', function(appdata) {
//  jQuery.get('myLocation.txt', function(appdata) {
        if ($.cookie('locationCookie') != null) {
            prevlatitude = $.cookie('locationCookie').prevlatitude;
            prevlongitude = $.cookie('locationCookie').prevlongitude;
        }
        var myvar = appdata;
        var substr = appdata.split('\n');
        var templatitude=(substr[0]).split('=');
        var templongitude=(substr[1]).split('=');
        var latitude = $.trim(templatitude[1]);
        var longitude = $.trim(templongitude[1]);
 
        if ((prevlatitude != latitude) || (prevlongitude != longitude)) {
            if (latitude < 0) { textLat = Math.round(latitude*100)/100 + "\u00B0" + "S"; }
            else if (latitude > 0){ textLat = Math.round(latitude*100)/100 + "\u00B0" + "N"; }
            else { textLat = Math.round(latitude*100)/100 + "\u00B0"; }
            if (longitude < 0) { textLong = Math.round(longitude*100)/100 + "\u00B0" + "W"; }
            else if (longitude > 0) { textLong = Math.round(longitude*100)/100 + "\u00B0" + "E"; }
            else { textLong = Math.round(longitude*100)/100 + "\u00B0"; }
            $.cookie('locationCookie', '{"prevlatitude":"'+latitude+'", "prevlongitude":"'+longitude+'", "textLat":"'+textLat+'", "textLong":"'+textLong+'"}', {expires: 365});
            searchWoeid(latitude, longitude); // SUCCESS
        }
}).fail(function() {
    clearTimeout(refreshLocationTimer); // No myLocation.txt file, stop GPS mode.
    gps = false;
    TextColor = "TextColorGrey";
    if (($.cookie('jsonCookie') == null) || (Update_Always == true)) { weatherRefresherTemp(zip); }
});
}
 
// FIRST INTERNET REQUEST : SEARCH WOEID FROM THE COORDINATES
function searchWoeid(latitude, longitude) {
    var url = 'http://query.yahooapis.com/v1/public/yql?q=select * from geo.placefinder where text="'+latitude+','+longitude+'" and gflags="R"&format=json';
    $.getJSON(url, function(data) {
        var found = data.query.count; // Check if coordinates return a valid location.
        if ( found == 1) {
            city = data.query.results.Result.city;
            var neighborhood = data.query.results.Result.neighborhood;
            var county = data.query.results.Result.county;
            countrycode = data.query.results.Result.countrycode;
            statename = data.query.results.Result.state;
            zipcode = data.query.results.Result.postal;
 
            if (UseNeighborhood == true) {
                if (neighborhood != null) { city = neighborhood; } else { city = county; }
            }
         
            if ((countrycode == "US") && (zipcode != null)) {
                gps = true;
                zip = zipcode;
                TextColor = "TextColorGrey";
                weatherRefresherTemp(zip); // Refresh weather as specified in Config.js.            
            } else {
                searchZipcode();
            }
        } else {
            if (xmldata == false) { // No data. Keep weather or back to locale, maintain the 20s refresh for GPS localization.
            gps = false;
            TextColor = "TextColorGrey";
            weatherRefresherTemp(zip);
            } else {
            $.cookie('offlineCookie', true, {expires: 365});
            document.getElementById("coordinates").className = "TextColorRed";
            document.getElementById("coordinates").innerHTML = "OFFLINE";
            }
        }
}).fail(function() {
    $.removeCookie('locationCookie');
    $.cookie('offlineCookie', true, {expires: 365});
    if (xmldata == true) {
        document.getElementById("coordinates").className = "TextColorRed"; 
        document.getElementById("coordinates").innerHTML = "OFFLINE";
    } else {
        if ( $.cookie('jsonCookie') != null ) {
        xmldata = true;
        dealWithWeather ({error:false, storage:true});
        } else {
        dealWithWeather ({error:true});
        }
    }
});
}   
 
// SECOND INTERNET REQUEST : SEARCH ZIP CODE WITH THE WOEID (NECESSARY FOR FORECAST)
function searchZipcode() {
var url = "http://apple.accuweather.com/adcbin/apple/Apple_find_city.asp?location="+escape(city)+","+countrycode;
$.get(url, function(data) {
    var us =  $(data).find('CityList').attr('us')*1;
    var intl = $(data).find('CityList').attr('intl')*1;
    var extra_cities = $(data).find('CityList').attr('extra_cities')*1;
    var exist = intl + us + extra_cities;
    if (exist != 0) {
        // INITIALIZE ZIP CODE
        var newzip = ""; 
        if (exist == 1) {
            // JUST ONE LOCATION FOUND, CERTAINLY THE GOOD ONE :)
            newzip = $(data).find("location").attr("postal");
        } else {
            // RETRIEVE ALL CITIES
            var i=0;
            $(data).find('location').each( function() {
                town[i] = $(this).attr("city");
                tempstate[i] = $(this).attr("state").sansAccent().toUpperCase();
                postal[i] = $(this).attr("postal");
                tempcountrycode[i] = postal[i].split('|')[1];
            i++;
            });
     
            // ACCURATE TEST : SEARCH FOR CLOSE MATCH
            if (statename != null) {
            statename = statename.sansAccent().toUpperCase();
            for (i=0; i < town.length; i++) {
                    var tmpvar = tempstate[i];
                    if ((town[i] == city) && (tempcountrycode[i] == countrycode) && (tmpvar.indexOf(statename) != -1)) {
                        newzip = postal[i];
                    }
                }
            }
             
            // LESS ACCURATE TEST : SEARCH FOR LESS EXACT MATCH, BASED ON STATE
            if ((newzip == "") && (statename != null) && (statename.indexOf('-') != -1)) {
                var tmp = statename.split('-');
                tmp.sort(function(a,b) {
                return a.length < b.length;
                });
                 
                for (i=0; i < town.length; i++) {
                    if ((town[i] == city) && (tempcountrycode[i] == countrycode) && (tempstate[i].indexOf(tmp[0]) != -1)) {
                        newzip = postal[i];
                    }
                }
            }
        }
        // CHECK IF I HAVE A VALID ZIP CODE
        if (newzip != "") {
            zip = newzip;
            gps = true;
            TextColor = "TextColorGrey";
            weatherRefresherTemp(zip); // Refresh weather as specified in Config.js.
        } else {
            if ( xmldata == false ) {  // Back to locale, but keep the 20s refresh for GPS localization.
                gps = false;
                TextColor = "TextColorGrey";
                weatherRefresherTemp(zip);
            } else {
                gps = true;
                TextColor = "TextColorRed";
                weatherRefresherTemp($.cookie('jsonCookie').zip);   // Keep the latest valid zip to update the weather.
            }           
        }
    } else {
            if ( xmldata == false ) {  // Back to locale, but keep the 20s refresh for GPS localization.
                gps = false;
                TextColor = "TextColorGrey";
                weatherRefresherTemp(zip);
            } else {
                gps = true;
                TextColor = "TextColorRed";
                weatherRefresherTemp($.cookie('jsonCookie').zip);   // Keep the latest valid zip to update the weather.
            }       
    }   
}).fail(function() {
    $.removeCookie('locationCookie');
    $.cookie('offlineCookie', true, {expires: 365});
    if (xmldata == true ) {
        document.getElementById("coordinates").className = "TextColorRed"; 
        document.getElementById("coordinates").innerHTML = "OFFLINE";
    } else {
        if ( $.cookie('jsonCookie') != null ) {
        xmldata = true;
        dealWithWeather ({error:false, storage:true});
        } else {
        dealWithWeather ({error:true});
        }
    }
});
}