        // The location field should be a relatively machine-legible string
// if using the default, Apple/AccuWeather parser (originally from Leopard's Weather.wdgt)
// The other available source is 'yahooWeather' which for the 'locale'
// requires a US zip or location code (e.g. UKXX0085 or CHXX0008) from http://weather.yahoo.com

var locale = "GMXX0004" //e.g. 'Defiance, Ohio'|'Moscow, Russia'|'Ledyard, AT'|'London, UK'

// Set to 'false' if you'd prefer Farenheit
var isCelsius = true //true|false

// Use 'Real Feel' temperatures where possible, taking into account Wind Chill, Humidity etc.
var useRealFeel = false //true|false

/*––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––*/
//Enable Wallpaper and/or Lock Screen
var enableWallpaper = true; //true|false
var enableLockScreen = false; //true|false [Currently, it is suggested that the lockScreen is disabled.]

var stylesheetWall = 'cjartwork' //'split'|'oneLine'
var stylesheetLock = 'none' //See above.

var iconSetWall = 'glanz' //'Elite'
var iconExtWall = ".png" //'.png'|.'gif' etc.
var iconSetLock = 'none' //See above.
var iconExtLock = '.png' //See above.

// Please endeavour to set this to a sensible value if you really must change it...
var updateInterval = 15 //Minutes/>


/*––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––*/


var descriptions =

[

"tornado",

"tropical storm",

"hurricane!",

"severe thunderstorms",

"thunderstorms",

"mixed rain and snow",

"mixed rain and sleet",

"mixed snow and sleet",

"freezing drizzle!",

"drizzle",

"freezing rain",

"showers",

"showers",

"snow flurries",

"light snow showers",

"blowing snow",

"snow",

"hail",

"sleet",

"dust",

"foggy!",

"haze",

"smoky",

"blustery",

"windy",

"cold",

"cloudy ",

"mostly cloudy",

"mostly cloudy",

"partly cloudy",

"partly cloudy",

"clear night",

"sunny",

"fair",

"fair",

"mixed rain and hail",

"hot",

"isolated thunderstorms",

"scattered thunderstorms",

"scattered thunderstorms",

"scattered showers",

"heavy snow",

"scattered snow showers",

"heavy snow",

"partly cloudy",

"thundershowers",

"snow showers",

"isolated thundershowers",

"not available",

]

var MiniIcons =
[
        "tstorm3",                //0         tornado
        "tstorm3",                //1         tropical storm
        "tstorm3",                //2         hurricane
        "tstorm3",                //3         severe thunderstorms
        "tstorm2",                //4         thunderstorms
        "sleet",                //5         mixed rain and snow
        "sleet",                //6         mixed rain and sleet
        "sleet",                //7         mixed snow and sleet
        "sleet",                //8         freezing drizzle
        "light_rain",                //9         drizzle
        "sleet",                //10         freezing rain
        "shower2",                //11         showers
        "shower2",                //12         showers
        "snow1",                //13         snow flurries
        "snow2",                //14         light snow showers
        "snow4",                //15         blowing snow
        "snow4",                //16         snow
        "hail",                //17         hail
        "sleet",                //18         sleet
        "mist",                //19         dust
        "fog",                //20         foggy
        "fog",                //21         haze
        "fog",                //22         smoky
        "cloudy1",                //23         blustery
        "cloudy1",                //24         windy
        "overcast",                //25         cold
        "cloudy1",                //26         cloudy
        "cloudy4_night",                //27         mostly cloudy (night)
        "cloudy4",                //28         mostly cloudy (day)
        "cloudy2_night",                //29         partly cloudy (night)
        "cloudy2",                //30         partly cloudy (day)
        "sunny_night",                //31         clear (night)
        "sunny",                //32         sunny
        "fair_night",                //33         fair (night)
        "fair",                //34         fair (day)
        "hail",                //35         mixed rain and hail
        "sunny",                //36         hot
        "tstorm1",                //37         isolated thunderstorms
        "tstorm2",                //38         scattered thunderstorms
        "tstorm2",                //39         scattered thunderstorms
        "tstorm2",                //40         scattered showers
        "snow5",                //41         heavy snow
        "snow3",                //42         scattered snow showers
        "snow5",                //43         heavy snow
        "cloudy1",                //44         partly cloudy
        "storm1",                //45         thundershowers
        "snow2",                //46         snow showers
        "tstorm1",                //47         isolated thundershowers
        "dunno",                //3200         not available
]

var descriptions =

[

"Tornado",

"Tropischer Sturm",

"Hurrikan!",

"schweres Gewitter",

"Gewitter",

"Regen und Schnee",

"Regen und Graupel",

"Schnee und Graupel",

"gefrierender Nieselregen",

"Nieselregen",

"Eisregen",

"Schauer",

"Schauer",

"Schneegestöber",

"Schneeschauer",

"Schneetreiben",

"Schnee",

"Hagel",

"Schneeregen",

"trübe",

"nebelig!",

"Dunst",

"dunstig",

"stürmisch",

"windig",

"kalt",

"bewölkt ",

"meist bewölkt",

"meist bewölkt",

"leichte bewölkung",

"leichte bewölkung",

"klare Nacht",

"sonnig",

"heiter",

"heiter",

"Regen und Hagel",

"heiss",

"vereinzelte Gewitter",

"vereinzelte Gewitter",

"Gewitter",

"vereinzelte Schauer",

"starker Schneefall",

"Schneeschauer",

"starker Schneefall",

"leichte bewölkung",

"Gewitter",

"Schneeschauer",

"einzelne Gewitter",

"nicht verfügbar",

]

function constructError (string)
{
        return {error:true, errorString:string};
}

function findChild (element, nodeName)
{
        var child;

        for (child = element.firstChild; child != null; child = child.nextSibling)
        {
                if (child.nodeName == nodeName)
                        return child;
        }

        return null;
}


function fetchWeatherData (callback, zip)
{
        url="http://weather.yahooapis.com/forecastrss?u=f&p=" //u=Farenheit, because accuWeather sucks

        var xml_request = new XMLHttpRequest();
        xml_request.onload = function(e) {xml_loaded(e, xml_request, callback);}
        xml_request.overrideMimeType("text/xml");
        xml_request.open("GET", url+zip);
        xml_request.setRequestHeader("Cache-Control", "no-cache");
        xml_request.send(null);

        return xml_request;
}

function xml_loaded (event, request, callback)
{
        if (request.responseXML)
        {
                 var obj = {error:false, errorString:null};
                var effectiveRoot = findChild(findChild(request.responseXML, "rss"), "channel");
                obj.city = findChild(effectiveRoot, "yweather:location").getAttribute("city");
                obj.realFeel = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");//Only accounts for windChill

                conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
                obj.temp = conditionTag.getAttribute("temp");
                obj.icon = conditionTag.getAttribute("code");
                obj.description = conditionTag.getAttribute("text");
                callback (obj);
        }else{
                callback ({error:true, errorString:"XML request failed. no responseXML"});
        }
}


function validateWeatherLocation (location, callback)
{
        var obj = {error:false, errorString:null, cities: new Array};
        obj.cities[0] = {zip: location}; //Not very clever, are we?
        callback (obj);
}

 var postal;
var demoMode = false;
var enabled;

if (location.href.indexOf("Wallpaper")  == -1){
        stylesheet = stylesheetLock;
        iconSet = iconSetLock;
        iconExt = iconExtLock;
        enabled = enableLockScreen;
}else{
        stylesheet = stylesheetWall;
        iconSet = iconSetWall;
        iconExt = iconExtWall;
        enabled = enableWallpaper;
}

if(enabled == true){
if(iconSet == null || iconSet == 'null' || iconSet == ""){
        var iconSet = stylesheet;
}

var headID = document.getElementsByTagName("head")[0];
var styleNode = document.createElement('link');
styleNode.type = 'text/css';
styleNode.rel = 'stylesheet';
styleNode.href = 'Stylesheets/'+stylesheet+'.css';
headID.appendChild(styleNode);

var scriptNode = document.createElement('script');
scriptNode.type = 'text/javascript';
scriptNode.src = 'Sources/'+source+'.js';
headID.appendChild(scriptNode);
}

function onLoad(){
        if (enabled == true){
        if (demoMode == true){
                document.getElementById("weatherIcon").src="Icon Sets/"+iconSet+"/"+"cloudy1"+iconExt;
                document.getElementById("city").innerText="Somewhere";
                document.getElementById("desc").innerText=descriptions[obj.icon];
                document.getElementById("temp").innerText="100º";

        }else{
        document.getElementById("weatherIcon").src="Icon Sets/"+iconSet+"/"+"dunno"+iconExt;
        validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)
        }
        }else{
                document.getElementsByTagName("body")[0].innerText='';
        }
}

function convertTemp(num)
{
        if (isCelsius == true)
                return Math.round ((num - 32) * 5 / 9);
        else
                return num;
}

function setPostal(obj){

        if (obj.error == false){
                if(obj.cities.length > 0){
                        postal = escape(obj.cities[0].zip).replace(/^%u/g, "%")
                        document.getElementById("WeatherContainer").className = "";
                        weatherRefresherTemp();
                }else{
                        document.getElementById("city").innerText="Not Found";
                        document.getElementById("WeatherContainer").className = "errorLocaleNotFound";
                }
        }else{
                document.getElementById("city").innerText=obj.errorString;
                document.getElementById("WeatherContainer").className = "errorLocaleValidate";
                setTimeout('validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)', Math.round(1000*60*5));
        }
}

function dealWithWeather(obj){

        if (obj.error == false){
                document.getElementById("city").innerText=obj.city;
                document.getElementById("desc").innerText=descriptions[obj.icon];

                if(useRealFeel == true){
                        tempValue = convertTemp(obj.realFeel);
                }else{
                        tempValue = convertTemp(obj.temp)
                }
                document.getElementById("temp").innerText=tempValue+"º";
                document.getElementById("weatherIcon").src="Icon Sets/"+iconSet+"/"+MiniIcons[obj.icon]+iconExt;
                document.getElementById("WeatherContainer").className = "";


        }else{
                //Could be down to any number of things, which is unhelpful...
                document.getElementById("WeatherContainer").className = "errorWeatherDataFetch";
        }


}

function weatherRefresherTemp(){ //I'm a bastard ugly hack. Hate me.
        fetchWeatherData(dealWithWeather,postal);
        setTimeout(weatherRefresherTemp, 60*1000*updateInterval);
}