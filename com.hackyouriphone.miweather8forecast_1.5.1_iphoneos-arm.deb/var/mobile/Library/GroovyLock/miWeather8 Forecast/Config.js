var Celsius = false; // Celsius
var Locale = "38671"; // Set your location here. Uses weather.com code not yahoo.
var GPS = false; // Pulls from myLocation.txt
var TwentyFourHourClock = false; // 24 Hour Clock
var Kph = false; //kph
var Curlanguage = ""; // options "de","fr","sp","it","zh". Keep clear to grab phone language
var ShowTabs = true; //show arrows on each side of screen
var Font = "walkway"; //type walkway or stock. stock will use bytafont
var FontColor = "white"; //choose font color for all fonts
var DragSpeed = 300; //configures how far it will scroll when dragged
var MinDragSpeed = 100; //minimum scroll after drag
var EaseType = "easeOutExpo"; //options for bounce-easeOutQuad,easeOutCubic,easeOutBack,etc
var WeatherRefresh = 15; // in minutes
var Cataracs = false; // use cataracs style clock
var CataracsDate = true; //add date to cataracs
var RemoveBlur = false; // remove blur from cataracs.
var CataracsShadow = "0 20px 30px rgba(0, 0, 0, 0.6)"; //drop shadow for cataracs. Enter none for no shadow
var CataracsStroke = "1px solid rgba(255, 255, 255, 0.2)"; //stroke
var CataracsSize = "1"; //cataracs size, enter lower value such as .5 
var MoveCataracs = false; // allows you to move the cataracs clock by dragging it.
var MoveTime = "0px"; // move time and date down (must enter px).
var HideTemp = false; // Hides Temp
var HideCondition = false; // Hides Condition
var HideFeelsLike = false; // Hide FeelsLike
var Info = ""; //Must respring when changing walls, or changing settings. Must turn off clock with groovylock. It doesn't hide the stock clock though.
var MoreInfo = ""; //Use Lock Screen Tools to hide the stock clock. There is a lot of options here. I cover them all on JunesiPhone.com


