if(Celsius==false){var sUnit="s";}else{var sUnit="m";}
if(Kph==false){var kph="no";}else{var kph="yes";}
//start GPS
if(GPS){
    function convertlatlong(Latitude, Longitude) {
    var url2 = 'http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20geo.placefinder%20where%20text%3D"' + Latitude + "%2C" + Longitude + '"%20and%20gflags%3D"R"';
    converttowoeid(url2);
}
function converttowoeid(url2) {
    $.ajax({
        url: url2,
        success: function(e) {
            woeid = $(e).find("woeid").text();
            locale = woeid;
            var url1 = "http://weather.yahooapis.com/forecastrss?w=" + locale;
            $.ajax({
                url: url1,
                success: function(e) {
                    link = $(e).find("guid").text();
                    link = link.split('_');
                    locale = link[0];
                    var sCityCodes = locale;
                    GetXmlFeed(sCityCodes);
                    setInterval(function() {GetXmlFeed(sCityCodes);}, refreshrate);
                }
            });
        }
    });
}
$.get( "file:///private/var/mobile/Documents/myLocation.txt", function( data ) {
    var Lines=data.split('\n'); //spli lines
    var latitude = Lines[0].split('='); //get values after equals
    var longitude = Lines[1].split('=');
    convertlatlong(latitude[1],longitude[1]); //start converting to weather code
});
}
else{
    var sCityCodes = Locale;
    GetXmlFeed(sCityCodes);
    setInterval(function() {GetXmlFeed(sCityCodes);}, refreshrate);
}
//End GPS

function reload_js(src) {
        $('script[src="' + src + '"]').remove();
        $('<script>').attr('src', src).appendTo('head');
    }

function GetXmlFeed(code) {
    //alert(code)
    console.log("updating weather");
    //var code = sCityCodes;
    var sc = document.createElement("script");
    var mainsc = 'http://wxdata.weather.com/wxdata/mobile/mobagg/' + code + '.js?key=2227ef4c-dfa4-11e0-80d5-0022198344f4&units=' + sUnit + '&locale=' + language + '&cb=XmlFeedCB';
    sc.src = mainsc;
    reload_js(mainsc);
}

function XmlFeedCB(js){
    console.log("show data");
  json = js[0];    //json is XML
  Showdata();
}


function Showdata() {
    var imagelocation = "weather/icon/";
    var imageextention = ".png"
    var dailyinfo = json.DailyForecasts; // daily forecast
    var hourlyinfo = json.HourlyForecasts; // hourly forecast
    var narrativeinfo = json.NarrativeForecasts; // Narrative forecast
    var raininfo = json.WhenWillItRain;
    var sunriseset = json.SunRiseSet;
    var hirad = json.HiradObservation;

    sunrise = JSON.stringify(sunriseset[0].rise);
    sunset = JSON.stringify(sunriseset[0].set);
    sunrise = sunrise.replace(/"/g, "");
    sunset = sunset.replace(/"/g, "");
    // convert sunrise from UNIX time
    var timestamp1 = sunrise;
    UX2 = new Date(timestamp1 * 1000),
        hours = (UX2.getHours() < 10 ? '0' + UX2.getHours() : UX2.getHours()),
        minutes = (UX2.getMinutes() < 10 ? '0' + UX2.getMinutes() : UX2.getMinutes()),
        seconds = (UX2.getSeconds() < 10 ? '0' + UX2.getSeconds() : UX2.getSeconds()),
        sunrise = hours + ':' + minutes;

    if (TwentyFourHourClock == "true") {
        hours = hours % 12;
        if (hours == 0) {
            hours += 12;
        }
        sunrise = hours + ':' + minutes;
    }
    // convert sunset from UNIX time
    var timestamp = sunset;
    UX1 = new Date(timestamp * 1000),
        hours = (UX1.getHours() < 10 ? '0' + UX1.getHours() : UX1.getHours()),
        minutes = (UX1.getMinutes() < 10 ? '0' + UX1.getMinutes() : UX1.getMinutes()),
        seconds = (UX1.getSeconds() < 10 ? '0' + UX1.getSeconds() : UX1.getSeconds()),
        sunset = hours + ':' + minutes;

    if (TwentyFourHourClock == "true") {
        hours = hours % 12;
        if (hours == 0) {
            hours += 12;
        }
        sunset = hours + ':' + minutes;
    }



    daily = JSON.stringify(dailyinfo[0]);
    hourly = JSON.stringify(hourlyinfo[0]);
    narrative = JSON.stringify(narrativeinfo[0]);

    if (daily.day == undefined) {
        var tod = dailyinfo[0].night;
    } else {
        var tod = dailyinfo[0].day;
    }

var precip = [];
var hltemps = [];
var dwicon = [];
var ddates = [];
var windv = [];
var windd = [];
for (i = 0; i < dailyinfo.length; i++) {

if (i > 7-1) break;
 var dn = dailyinfo[i].day ? dailyinfo[i].day : dailyinfo[i].night;
  var d = new Date(parseInt(dailyinfo[i].validDate,10) * 1000);
  precip.push('<div class="precip">' + dn.pop + '% '+ preciptxt + '</div>');
  dwicon.push('<img class="weatherIcon" width="40" src="weather/icon/' + dn.icon  + '.png"  title="' + dn.phrase + '"/>'); 
  hltemps.push('<div class="tempMM"><span class="temp-max">'  + (dailyinfo[i].maxTemp  ? (dailyinfo[i].maxTemp + '') : json.StandardObservation.temp) + ((sUnit == 's') ? '\&#8457' : '\&#8451')+'</span> <span class="temp-min"> / ' + (dailyinfo[i].minTemp+'' ? (dailyinfo[i].minTemp + '') : '--') + ((sUnit == 's') ? '\&#8457' : '\&#8451')+'</span></div>');
   windv.push('<div class="wind">'  + dn.wSpeed +" "+ dn.wDirText+ ((Kph) ? ' kph' : ' mph') + '</div>');  
function getCalendarDate(){
      var now = d;
      var daynumberwind = now.getDay();
      var dayname   = sday[daynumberwind];
      var fcastdays = dayname;
 return fcastdays;
 }

 var fcastdays = getCalendarDate();
  windd.push('<span class="windays">' + ('' + fcastdays)+ '</span>');
var fcastdays = getCalendarDate();
var gMonth = smonth[d.getMonth()];
  ddates.push('<span class="weekdays">' + ('' + fcastdays) +", " + gMonth+ " "+d.getDate()+ '</span> <span class="days">' + '</span>');

}

//fix for out of states
try {
jsons = ("{" + json.NowHirad.phrase + "}");
}
catch (exception) {
  var str = JSON.stringify (json.NarrativeForecasts[0].phrase);
str = str.replace(/[\.,-\/#!$%\^&\*;:"{}=\-_`~()]/g,"");
var getNowHirad =  "no";
document.getElementById("extdesc").innerHTML="<span>"+str+"</span>";
jsons = null;}

if(getNowHirad != "no"){
document.getElementById("extdesc").innerHTML="<span>"+json.NowHirad.phrase+"</span>";
}

//res = String(precip).replace(/,/g," ");
if(json.StandardObservation.wSpeed > 0){
document.getElementById('blade').className=" spin";
document.getElementById('blade2').className=" spin";
}
else if(json.StandardObservation.wSpeed>5){
  document.getElementById('blade').className=" spinfaster";
document.getElementById('blade2').className=" spinfaster";
}
else if(json.StandardObservation.wSpeed<=0){
  document.getElementById('blade').className=" ";
document.getElementById('blade2').className=" ";
}

//rotate blades
document.getElementById('precip').innerHTML=precip.join("");
document.getElementById('hltemps').innerHTML=hltemps.join("");
document.getElementById('dwicon').innerHTML=dwicon.join("");
document.getElementById('ddates').innerHTML=ddates.join("");
document.getElementById('windv').innerHTML=windv.join("");
document.getElementById('windd').innerHTML=windd.join("");

    var numofdays = 4;
    var daysize = "30"; //set forecast image size
    var iconlocation = "weather/icon/"; //what folder to pull from
    var iconextention = ".png"; //image extentions
    var degrees = "&deg;";

    //begin forecast

    for (i=0; i<numofdays; i++){
         var count = i+1;
         var dn = dailyinfo[count].day ? dailyinfo[count].day : dailyinfo[count].night;
         var da = new Date(dailyinfo[count].validDate * 1000);
         var ht = dailyinfo[count].maxTemp;
         var lt = dailyinfo[count].minTemp;
         document.getElementById("Day"+count).innerHTML = '<img width=' + daysize + ' src=' +iconlocation+ dn.icon + iconextention + '>';
         document.getElementById("ForecastDay"+count).innerHTML = '<span>' + (sday[da.getDay()]) + '</span>'
         document.getElementById("Day"+count+"High").innerHTML = '<span>' + (ht + degrees + "/" + '<span class="lowtemp">' + lt + degrees) + '</span>'+'</span>'
         //document.getElementById("Precip"+count).innerHTML = '<span>' + dn.pop +"%"+'</span>';
   }

    if (json.StandardObservation.wxIcon.value == undefined) {
        var icon = json.HiradObservation.wxIcon;
        var currentIcon = json.HiradObservation.wxIcon;
    } else {
        var icon = json.StandardObservation.wxIcon;
        var currentIcon = json.StandardObservation.wxIcon;
    }


    if (json.StandardObservation.wxIcon == "") {
        json.StandardObservation.wxIcon = "na"
    };
    if (icon.length == 0) {
        icon = "dunno";
    }
    var HourlyIcon = imagelocation + icon + imageextention;


    document.getElementById("icon").innerHTML = '<img width="60" src=' + HourlyIcon + '>'

    var hiToday = JSON.stringify(+dailyinfo[0].maxTemp + degrees); //Today hi
    hiToday = hiToday.replace(/"/g, "");
    if (hiToday == "NaN" + degrees) {
        hiToday = json.StandardObservation.temp + degrees;
    }
    document.getElementById("hi").innerHTML = '<span>' + "H:"+(hiToday) + '</span>'

    var loToday = JSON.stringify("" + dailyinfo[0].minTemp + degrees); //Today lo
    loToday = loToday.replace(/"/g, "");
    document.getElementById("low").innerHTML = '<span>' + "L:"+ (loToday) + '</span>'


    var ds=dailyinfo[0].day ? dailyinfo[0].day : dailyinfo[0].night;
    document.getElementById("condition").innerHTML = '<span>' + (textstringlater + ds.phrase) + '</span>'



    document.getElementById("temp").innerHTML = '<span>' + ('' + json.StandardObservation.temp+degrees) + '</span>'

    var realFeel = JSON.stringify(hourlyinfo[0].feelsLike + degrees); //Current Temp
    realFeel = realFeel.replace(/"/g, "");
    document.getElementById("feeltemp").innerHTML = '<span>' + (feeltxt + hirad.feelsLike) + '</span>'

    var Humidity = JSON.stringify(humidtxt + hourlyinfo[0].humid); //Humidity
    Humidity = Humidity.replace(/"/g, "");
    document.getElementById("humidity").innerHTML = '<span>' + ('' + Humidity) + '</span>'

    var WindSpeed = JSON.stringify("" + hourlyinfo[0].wSpeed); //Wind Speed
    WindSpeed = WindSpeed.replace(/"/g, "");
       var WindDirection = JSON.stringify(hourlyinfo[0].wDirText); //Wind Direction
    WindDirection = WindDirection.replace(/"/g, "");
    if (WindDirection.length < 1) {
        WindDirection = "No Wind"
    }
   

    if (kph == "yes") {
        conversion = 1.609344
        kphv = WindSpeed * conversion;
        kphv = Math.round(kphv * 100) / 100;
        kphv = Math.round(kphv);
        document.getElementById("windsp").innerHTML = '<span>' + ( kphv + "Kph" + " "+WindDirection) + '</span>'
    }
    else{
         document.getElementById("windsp").innerHTML = '<span><span class="fa fa-leaf icons"></span>'+" "  + ( WindSpeed + "Mph" + " "+WindDirection) + '</span>'
    }


    //document.getElementById("wind").innerHTML = '<span><span class="fa fa-compass icons"></span>'+" "  + ('' + WindDirection) + '</span>'

    var UV = JSON.stringify("uv:" + hourlyinfo[0].uv); //UV
    UV = UV.replace(/"/g, "");
    document.getElementById("uv").innerHTML = '<span>' + ('' + UV) + '</span>'

    var dew = JSON.stringify("" + hourlyinfo[0].dew + "&#176"); //dew

    dew = dew.replace(/"/g, "");
    document.getElementById("dew").innerHTML = '<span><span class="fa fa-tint icons"></span>'+" "  + dew + '</span>'

    var City = JSON.stringify(json.Location.city); //City
    City = City.replace(/"/g, "");
    document.getElementById("city").innerHTML = '<span>' + ('' + City) + '</span>'


try {
    var dsc = json.HiradObservation.text;
    if(dsc.length==0){ document.getElementById("HourlyDesc").innerHTML = "<span>" + json.StandardObservation.text + "</span>";}
        else{
    document.getElementById("condition").innerHTML = "<span>" + json.HiradObservation.text + "</span>";
    }
} catch (C) {
    document.getElementById("condition").innerHTML = "<span>" + json.StandardObservation.text + "</span>"
}


    document.getElementById("raininfo").innerHTML = '<span>' + (raininfo.standardPhrase) + '</span>'

    var Sunrise = sunrise;
    document.getElementById("sunrise").innerHTML = '<span>' + (sunrisetxt + Sunrise) + "am" + '</span>'


    var Sunset = sunset;
    document.getElementById("sunset").innerHTML = '<span>' + (sunsettxt + Sunset) + "pm" + '</span>'

  var Rude = ["Oh shit a tornado", "Damn tropical storm", "Run its a hurricane", "Fucking thunderstorm", "Fuck its a thunderstorm", "Fuck its snowing", "Fucking sleet", "Fucking sleet", "Fuck it's drizzling", "Fuck it's drizzling", "Fucking freezing rain", "Fuck it's raining", "Fuck it's raining", "Fucking flurries", "Fucking light snow", "Fuck it's snowing", "Fuck it's snowing", "Fucking hailing", "Fuck it's sleeting", "Fucking dusty out here", "Fucking foggy", "Fucking hazy", "Fucking smoky", "WTF it's blustery", "Windy as fuck", "Cold as fuck", "It's fucking cloudy", "It's fucking mostly cloudy", "It's fucking mostly cloudy", "It's fucking partly cloudy", "It's fucking partly cloudy", "It's fucking clear", "It's fucking sunny outside", "Fucking fair", "Fucking fair", "Fucking sleeting", "Fuck it's hot", "Isolated fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking thunderstorms", "Scattered fucking showers", "Heavy fucking snow", "Light fucking snow", "Heavy fucking snow", "Partly fucking cloudy", "Fucking thunderstorm", "It's fucking snowing", "It's a fucking thunderstorm", "blank"];

 // document.getElementById('Rude').innerHTML='<span>'+Rude[icon]+'</span>'



try{var q=json.WeatherAlerts[0].headline}catch(C){q="No "+warningtxt}
document.getElementById("warning").innerHTML="<span>"+(warningtxt+q)+"</span>";


document.getElementById("rainfall").innerHTML="<span>"+(preciptxt+Math.round(json.HiradObservation.precipHourly)+'"')+"</span>";

};

//GetXmlFeed(true);




