



if(window.groovyAPI) {
      if(groovyAPI.isShowingNotifications()){
            var value = "20px";
              document.getElementById("body").setAttribute("style","-webkit-filter:blur(" + value + ");margin-top:-20px;-webkit-transform:scale(1.2)");
      }
      else{
          document.getElementById("body").setAttribute("style",""); 
      }
}
else {

}

$(function() {

if(MoveCataracs){
  var catop=localStorage.getItem('ctop');
  var caleft=localStorage.getItem('cleft');
  if(catop){
    document.getElementById('cataracs').style.top=catop;
    document.getElementById('cataracs').style.left=caleft;
  }
  $('#cataracs').draggable({
     stop: function(event, ui){
         var cleft = document.getElementById('cataracs').style.left;
         var ctop = document.getElementById('cataracs').style.top;
         localStorage.setItem('ctop',ctop);
         localStorage.setItem('cleft',cleft);
  }});

}
else{
  var catop=localStorage.getItem('ctop');
  var caleft=localStorage.getItem('cleft');
  if(catop){
    document.getElementById('cataracs').style.top=catop;
    document.getElementById('cataracs').style.left=caleft;
  }
}

if(Cataracs){
  document.getElementById('cataracs').style.display="block";
  document.getElementById('time').style.display="none";
  document.getElementById('DMD').style.display="none";
      if(CataracsDate){
      $("#cdate").css('display','block');
    }
    else{
      $("#cdate").css('display','none');
    }
}
else{
  document.getElementById('cataracs').style.display="none";
  document.getElementById('time').style.display="block";
  document.getElementById('DMD').style.display="block";
}

if(HideTemp){
  document.getElementById('temp').style.display="none";
}
else{
  document.getElementById('temp').style.display="block";
}

if(HideCondition){
  document.getElementById('condition').style.display="none";
}
else{
  document.getElementById('condition').style.display="block";
}
if(HideFeelsLike){
  document.getElementById('feeltemp').style.display="none";
}
else{
  document.getElementById('feeltemp').style.display="block";
}





});
var pressed=0;
function slide(){
  pressed++
  if(pressed == 1){
  document.getElementById('right').innerHTML="&#10097;";
  document.getElementById('cataracs').style.display="none";
  document.getElementById("boxes").className= ' slide';
  document.getElementById('time').style.display="none";
  document.getElementById('DMD').style.display="none";
  document.getElementById('condition').style.display="none";
  document.getElementById('temp').style.display="none";
  document.getElementById('feeltemp').style.display="none";


}
else{
	document.getElementById('right').innerHTML="&#10096;";
      if(Cataracs){
        document.getElementById('cataracs').style.display="block";
    }
    else{
        document.getElementById('time').style.display="block";
      document.getElementById('DMD').style.display="block";
    }
  document.getElementById("boxes").className= ' slideleft';
  document.getElementById("boxes").style.top="0px";
  $('.slider').css('display','none');
  document.getElementById('condition').style.display="block";
  document.getElementById('temp').style.display="block";
  document.getElementById('feeltemp').style.display="block";
  pressed = 0;
}
  }




function renderProgress(progress)
{
    progress = Math.floor(progress);
    if(progress<25){
        var angle = -90 + (progress/100)*360;
        $(".animate-0-25-b").css("transform","rotate("+angle+"deg)");
    }
    else if(progress>=25 && progress<50){
        var angle = -90 + ((progress-25)/100)*360;
        $(".animate-0-25-b").css("transform","rotate(0deg)");
        $(".animate-25-50-b").css("transform","rotate("+angle+"deg)");
    }
    else if(progress>=50 && progress<75){
        var angle = -90 + ((progress-50)/100)*360;
        $(".animate-25-50-b, .animate-0-25-b").css("transform","rotate(0deg)");
        $(".animate-50-75-b").css("transform","rotate("+angle+"deg)");
    }
    else if(progress>=75 && progress<=100){
        var angle = -90 + ((progress-75)/100)*360;
        $(".animate-50-75-b, .animate-25-50-b, .animate-0-25-b")
                                              .css("transform","rotate(0deg)");
        $(".animate-75-100-b").css("transform","rotate("+angle+"deg)");
    }
    $(".text").html(progress+"%");
}




loadbattery = function(){
    if(window.groovyAPI) {
      if(groovyAPI.wiFiEnabled()){
          document.getElementById('wifi').className = " ring";
      }
       if(groovyAPI.bluetoothEnabled()){
           document.getElementById('bt').className = " ring";
       }
       if(groovyAPI.locationServicesEnabled()){
          document.getElementById('ls').className = " ring";
       }


          var glbatt = groovyAPI.getBatteryLevel()*100;
          renderProgress(glbatt);
    }
    else {
     renderProgress(10);
    }  
}



var pressedb=0;
function battery(){
  pressedb++
  if(pressedb == 1){
  	document.getElementById('left').innerHTML="&#10096;";
    if(Cataracs){
        document.getElementById('cataracs').style.display="none";
    }
    else{}
    document.getElementById("batterydis").className= ' slideb';
  }
  else{
  	document.getElementById('left').innerHTML="&#10097;";
     if(Cataracs){
        document.getElementById('cataracs').style.display="block";
    }
    else{}
    document.getElementById("batterydis").className= ' slidebleft';
    pressedb = 0;
  }
}


function formatSizeUnits(bytes){
    if  (bytes>=1000000000) {bytes=(bytes/1000000000).toFixed(2)+' GB';}
    else if (bytes>=1000000)    {bytes=(bytes/1000000).toFixed(2)+' MB';}
    else if (bytes>=1000)       {bytes=(bytes/1000).toFixed(2)+' KB';}
    else if (bytes>1)       {bytes=bytes+' bytes';}
    else if (bytes==1)      {bytes=bytes+' byte';}
    else                {bytes='0 byte';}
    return bytes;
}

if(window.groovyAPI){
  var memused = groovyAPI.getMemoryUsed()
  var mem = groovyAPI.getTotalMemory()
}
else{
  memused = 1.05+" mb";
  mem = 1.05+" gb";
}

document.getElementById('mem').innerHTML= "Memory: "+formatSizeUnits(mem);
document.getElementById('memused').innerHTML="Free: "+formatSizeUnits(memused);


function togglewifi(){
  if(groovyAPI.wiFiEnabled()){
    groovyAPI.setWiFiEnabled(false);
    document.getElementById('wifi').className = " dring";
  }
  else{
  groovyAPI.setWiFiEnabled(true);
  document.getElementById('wifi').className = " ring";
  }
}

function togglebt(){
  if(groovyAPI.bluetoothEnabled()){
   groovyAPI.setBluetoothEnabled(false);
   document.getElementById('bt').className = " dring";
  }
  else{
  groovyAPI.setBluetoothEnabled(true);
  document.getElementById('bt').className = " ring";
  }
}

function togglels(){
  if(groovyAPI.locationServicesEnabled()){
   groovyAPI.setLocationServicesEnabled(false);
   document.getElementById('ls').className = " dring";
  }
  else{
  groovyAPI.setLocationServicesEnabled(true);
  document.getElementById('ls').className = " ring";
  }
}


if(Font){
  $('#body').css('font-family',Font);
}
if(FontColor){
  $('#body').css('color',FontColor);
}

if(RemoveBlur){
$("#cataracs").removeClass("blurred-bg");
}

if(ShowTabs){
$('#tabs').css('display','block');
}
else{
  $('#tabs').css('display','none');
}


$('#cataracs').css('box-shadow',CataracsShadow);
$('#cataracs').css('border',CataracsStroke);
$('#cataracs').css('-webkit-transform',"scale("+CataracsSize+")");
$('#timedate').css('top',MoveTime);



$(function() {
  $( "#datepicker" ).datepicker({ firstDay: 1});
});
 $.datepicker.setDefaults($.datepicker.regional[language]);

 var css = ".ui-state-default {color: "+FontColor+";};";

var htmlDiv = document.createElement('div');
htmlDiv.innerHTML = '<p>foo</p><style>' + css + '</style>';
document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[1]);

