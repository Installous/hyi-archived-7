/*
Configuration here !
Done by Dacal - Modded by Schnedi // don't remove this line motherfucker //
For weather code, go to http://weather.yahoo.com/ and search for your city. The correct zip code is in the URL (only numbers)
*/

var iconSet = "Clima"		// add your own set
var iconSet1 = "Yahoo"		// add your own set
