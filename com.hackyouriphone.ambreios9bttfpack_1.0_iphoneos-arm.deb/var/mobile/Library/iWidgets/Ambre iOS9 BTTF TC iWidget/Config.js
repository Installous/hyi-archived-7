// OPTIONS //
				      
var GMT = 0; // Adjust sunset/sunrise time if necessary.
var UseExtraLocation = "neighborhood"; // city, neighborhood or default.
var XML_TEST = false; 	//true or false (false for normal use).

/*
var iconSet = "Sk3tch"; //Sk3tch, HTC, RealWeatherIconSet or Stardock.
var lang = "en"; // en for English, ge for German, nl for Dutch, fi for Finnish, it for Italian, ru for Russian, sp for Spanish, cn for Chinese, fr for French, no for Norweigan.
var colorvariable = "FF0000"; // Changes the color of all fonts.
var showUpdateTime = true;
*/

