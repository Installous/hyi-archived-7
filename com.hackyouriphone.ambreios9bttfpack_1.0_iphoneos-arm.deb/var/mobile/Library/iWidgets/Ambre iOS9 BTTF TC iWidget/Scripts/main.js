var updateFileTimer = "";
var obj = new Array;
var where = "";
var time_to_change_wall;
var dayhour;
var nighthour;
var ampm = false;   //Don't change. Use Widget Weather settings.
var timeOfDay = "";
var currentHours;

// Set a time out for all ajax requests, desactivate the cache.
$.ajaxSetup({timeout: 8000, cache: false}); 

function init() {
updateClock();
setInterval(updateClock, 1000);
updateWeather();
}

function updateClock() {
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
	var currentDate = currentTime.getDate() < 10 ? '' + currentTime.getDate() : currentTime.getDate();
	time_to_change_wall = currentHours + currentMinutes/60;
	timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";

		if (ampm == false) {
			timeOfDay = "";
			currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
			currentTimeString = currentHours + ":" + currentMinutes;
		} else {
			currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
			// currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
			currentHours = ( currentHours == 0 ) ? 12 : currentHours;
			currentTimeString = currentHours + ":" + currentMinutes + timeOfDay;
		}
		
	var mdegree = currentMinutes * 6;
	var mrotate = "rotate(" + mdegree + "deg)";
	var hdegree = currentHours * 30 + (currentMinutes / 2);
	var hrotate = "rotate(" + hdegree + "deg)";

	$("#hour").css("-webkit-transform", hrotate);
	$("#min").css("-webkit-transform", mrotate);
    
	if
	((currentHours < 10)&& (ampm==true)){document.getElementById("digitalhour").innerHTML = "0" + currentHours;}
	else
	{document.getElementById("digitalhour").innerHTML = currentHours;}
	
	document.getElementById("digitalminute").innerHTML = currentMinutes;
	document.getElementById("month").innerHTML = months[currentTime.getMonth()];	
	
	if
	(currentDate < 10){document.getElementById("date").innerHTML = "0" + currentDate;}
	else
	{document.getElementById("date").innerHTML = currentDate;}

	document.getElementById("year").innerHTML = currentTime.getFullYear();
		

	
	if (ampm == false) {
	
	if ( currentHours < 12 ) {document.getElementById("circuits").src = "Images/TimeCircuits/circuitsAM.png"}
	else{document.getElementById("circuits").src = "Images/TimeCircuits/circuitsPM.png";}
	
	}else{
	
	if (timeOfDay=="PM"){document.getElementById("circuits").src = "Images/TimeCircuits/circuitsPM.png";}
	else{document.getElementById("circuits").src = "Images/TimeCircuits/circuitsAM.png";}
	
	}
		
	// DAY OR NIGHT CHANGE
	if (dayhour != null) {
		if ((time_to_change_wall < dayhour) || (time_to_change_wall >= nighthour)) { var whereTmp = "night";	} else { var whereTmp = "day"; }
		if (whereTmp != where) { dealWithWeather(obj); } // Refresh the weather for day/night condition.
	}
}

function dealWithWeather(obj) {


    if (showUpdateTime == true) {
    	// TIME INFO
    	//document.getElementById("xmlupdate").innerHTML = lastupdatetext + obj.updatetimestring.slice(11);
    	document.getElementById("xmlupdate").style.color = (colorvariable); 
    		if (ampm == true) {
    			document.getElementById("xmlupdate").innerHTML = lastupdatetext + '</span>' + obj.lastupdate[1].split(":")[0] + ":" + obj.lastupdate[1].split(":")[1] + obj.lastupdate[2];
    		} else {
    			document.getElementById("xmlupdate").innerHTML = lastupdatetext + '</span>' + obj.lastupdate[1].split(":")[0] + ":" + obj.lastupdate[1].split(":")[1];
    		}
		}

	// MAIN INFORMATION
	var sunriseh = parseInt(obj.sunrise.split(':')[0]) + GMT;
	var sunrisem = obj.sunrise.split(':')[1];
	var sunseth = parseInt(obj.sunset.split(':')[0]) + GMT;
	var sunsetm = obj.sunset.split(':')[1];
	dayhour = sunriseh + parseInt(sunrisem)/60;
	nighthour = sunseth + parseInt(sunsetm)/60;
		
	if (ampm == false) {
		var sunriseh = ( sunriseh < 10 ? "0" : "" ) + sunriseh;
		var sunseth = ( sunseth < 10 ? "0" : "" ) + sunseth;
		var sunrise = sunriseh + ":" + sunrisem;		
		var sunset = sunseth + ":" + sunsetm;
		} else {
		var timeOfSunset = ( sunseth < 12 ) ? "am" : "pm";
		var timeOfSunrise = ( sunriseh < 12 ) ? "am" : "pm";
		sunriseh = ( sunriseh > 12 ) ? sunriseh - 12 : sunriseh;
		sunriseh = ( sunriseh == 0 ) ? 12 : sunriseh;
		sunseth = ( sunseth > 12 ) ? sunseth - 12 : sunseth;
		sunseth = ( sunseth == 0 ) ? 12 : sunseth;
		var sunrise = sunriseh + ":" + sunrisem + " " + timeOfSunrise;	
		var sunset = sunseth + ":" + sunsetm + " " + timeOfSunset;
	}

	// CHANGE THE BACKGROUND FOR DAY OR NIGHT CONDITION
	if ((time_to_change_wall < dayhour) || (time_to_change_wall >= nighthour)) { where = "night"; } else { where = "day"; }

	// City Name Display Option

	var cityname = obj.city;
	switch (UseExtraLocation) {
		case "city":
		if ((obj.extraLocCity != null) && (obj.extraLocCity != "")) { cityname = obj.extraLocCity; }
		break;
		case "neighborhood":
		if ((obj.extraLocNeighborhood != null) && (obj.extraLocNeighborhood != "")) { cityname = obj.extraLocNeighborhood; }
		else if ((obj.extraLocCounty != null) && (obj.extraLocCounty != "")) { cityname = obj.extraLocCounty; }
		break;
	}


    document.getElementById("city").style.color = (colorvariable); 
    document.getElementById("city").innerHTML = cityname;
	
	document.getElementById("temp").style.color = (colorvariable); 
	document.getElementById("temp").innerHTML = obj.temp + "&#176;";
	document.getElementById("Day0Icon").src = "Icon Sets/"+iconSet+"/"+AdjustIcon(obj.icon, where)+".png";


    document.getElementById("desc").style.color = (colorvariable); 
    document.getElementById("desc").innerHTML = WeatherDesc[obj.icon];
	
}

function updateWeather() {
	if (XML_TEST == true) { var url = "widgetweather.xml" } else { var url =  "file:///private/var/mobile/Documents/widgetweather.xml";}
	jQuery.get(url, function(data) {
		obj.updatetimestring = $(data).find('updatetimestring').text();

			if (updateFileTimer != obj.updatetimestring) {
				obj.high = new Array;
				obj.low  = new Array;
				obj.code = new Array;
				obj.daynumber = new Array;
				obj.dayofweek = new Array;

					$(data).find('currentcondition').each( function() {
						obj.city =$(this).find('name').text();	   
						obj.extraLocCity = $(this).find('extraLocCity').text();
						obj.extraLocNeighborhood = $(this).find('extraLocNeighborhood').text();
						obj.extraLocCounty = $(this).find('extraLocCounty').text();
						obj.temp = $(this).find('temp').text(); 
						obj.icon = $(this).find('code').text();
						obj.observationtime = $(this).find('observationtime').text();
						obj.sunset = $(this).find('sunsettime').text();
						obj.sunrise = $(this).find('sunrisetime').text();
						obj.tempUnit = $(this).find('celsius').text();
						obj.moonphase = $(this).find('moonphase').text()*1;
						obj.pressure = $(this).find('pressure').text();
						obj.humidity = $(this).find('humidity').text(); 
						obj.visibility = $(this).find('visibility').text();
						obj.RealFeel = $(this).find('chill').text();
						obj.direction = $(data).find('direction').text();
						obj.windspeed = Math.round($(data).find('speed').text());
						obj.unitsdistance = $(this).find('unitsdistance').text();
						obj.unitspressure = $(this).find('unitspressure').text();
						obj.unitsspeed = $(this).find('unitsspeed').text();
						obj.unitstemperature = $(this).find('unitstemperature').text(); 
					});

				$(data).find('settings').each( function() {
					obj.timehour = $(this).find('timehour').text();
					ampm = (obj.timehour == "24h") ? false : true;	
				});

			var i=0;
			$(data).find('day').each( function() {
				obj.high[i] =$(this).find('high').text();
				obj.low[i] = $(this).find('low').text();
				obj.code[i] = $(this).find('code').text();	
				obj.daynumber[i] = $(this).find('daynumber').text();	
				obj.dayofweek[i] = $(this).find('dayofweek').text();
				i++;
			});

			updateFileTimer = obj.updatetimestring;
			obj.lastupdate = updateFileTimer.split(' ');
			dealWithWeather(obj);
			if (ampm == true) {
				updateTimer = new Date([obj.lastupdate[0].split('-')[1], obj.lastupdate[0].split('-')[2], obj.lastupdate[0].split('-')[0]].join('/') + " " + obj.lastupdate[1] + " " + obj.lastupdate[2]);
			} else {
				updateTimer = new Date([obj.lastupdate[0].split('-')[1], obj.lastupdate[0].split('-')[2], obj.lastupdate[0].split('-')[0]].join('/') + " " + obj.lastupdate[1]);
			}
		}
	}).fail(function() {
		document.getElementById("xmlupdate").innerHTML = "No XML file !";
	});
	refreshTimer = setTimeout(updateWeather, 20*1000);
}

// WORKAROUND FOR CORRECT ICONS IN ALL SITUATIONS AND TWELVE HOUR FORMAT*

function AdjustIcon(icon, whereTmp) {
	switch(whereTmp) {
		case "day":
			if (icon == 27) { icon = 28; }
			if (icon == 29) { icon = 30; }	
			if (icon == 31) { icon = 32; }	
			if (icon == 33) { icon = 34; }
		break;
		case "night":
			if (icon == 28) { icon = 27; }
			if (icon == 30) { icon = 29; }	
			if (icon == 32) { icon = 31; }	
			if (icon == 34) { icon = 33; }
		break;
	}
	return icon;
}
