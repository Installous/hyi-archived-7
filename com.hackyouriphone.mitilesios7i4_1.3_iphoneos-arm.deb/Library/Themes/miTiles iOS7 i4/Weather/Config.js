var ampm = true; // Set to true for 12h format
var locale = 2389922; // Yahoo Weather Woeid Find yours http://woeid.rosselliot.co.nz/
var tempUnit = "f"; // f for fahrenheit
var updateInterval = 15; // in minutes
var lang = "en"; // (fr) for french, (de) for german, (sp) for spanish, (it) for italian, (en) or anything else for english,(am) for us
var SecDisplay = false; // true to display seconds


var ChangeClick = false; 
var gps = false; 