

// Please enter the rss address
var rssAddress = 'http://www.goodreads.com/quotes_of_the_day/rss';

// Update the page any X minutes.
var updateInterval = 30;

// Try to update the page any X minutes when internet connection is disabled.
var updateIntervalOff = 15;

// Show image? (yes = true, no = false), if true, you won't be able to limit the max letters per description.
var ShowPI = false;

// limit the max letters per description 0 = no limit 10 = max of 10 letters (you can choose any number)...
var LimitLetters = 80;

// Speical support for hebrew (if your main language is hebrew -> true, else -> false)
var hebrew = false;

// Do you want the widget to be right to left? (yes -> true, no -> false)
var rtl = false;