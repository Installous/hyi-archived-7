$(window).load(function(){
jQuery.cookie = function (key, value, options) {

    // key and at least value given, set cookie...
    if (arguments.length > 1 && String(value) !== "[object Object]") {
  options = jQuery.extend({}, options);

  if (value === null || value === undefined) {
      options.expires = -1;
  }

  if (typeof options.expires === 'number') {
      var days = options.expires, t = options.expires = new Date();
      t.setDate(t.getDate() + days);
  }

  value = String(value);

  return (document.cookie = [
      encodeURIComponent(key), '=',
      options.raw ? value : encodeURIComponent(value),
      options.expires ? '; expires=' + options.expires.toUTCString() : '', 
      options.path ? '; path=' + options.path : '',
      options.domain ? '; domain=' + options.domain : '',
      options.secure ? '; secure' : ''
  ].join(''));
    }

    options = value || {};
    var result, decode = options.raw ? function (s) { return s; } : decodeURIComponent;
    return (result = new RegExp('(?:^|; )' + encodeURIComponent(key) + '=([^;]*)').exec(document.cookie)) ? decode(result[1]) : null;
};




$('#savebgbutton').click( function() {
       $.cookie('backgroundcolor', $('#background').css('background-color'),{ expires: 365});
              $("#bgbutton").css('z-index','-100');
       $("#resetbgbutton").css('z-index','-100');
      $("#closebgbutton").css('z-index','-100');
      $("#savebgbutton").css('z-index','-100');
      $("#resetblurbutton").css('z-index','-100');
      $("#blurbutton").css('z-index','-100');
      $("#restartphotosbutton").css('z-index','-100');
      $("#clearcookiesbutton").css('z-index','-110');
       $("#menubackground").css('z-index','-90');
         $.cookie('backgroundz', $('#background').css('z-index'),{ expires: 365});
       
});

if($.cookie('backgroundcolor',{ expires: 365}) != null){


    $('#background').css('background-color', $.cookie('backgroundcolor'),{ expires: 365});
    $('#background').css('z-index', '2');
}
});  

$('#resetbgbutton').click( function() {
       $.cookie('backgroundcolor',null);
        location.reload();



}); 
 


