/*
Configuration here !
Done by Dacal - Modded by Schnedi // Modded by smr_95
For weather code, go to http://weather.yahoo.com/ and search for your city. The correct zip code is in the URL (only numbers)
*/

var iconSet = "smr"		// add your own set
