
twentyfourhour = true// Set false for 12hr

        var French = true;      // change to true to display date in French

        var German = false;      // change to true to display date in German

        var Spanish = false;     // change to true to display date in Spanish

        var Dutch = false;       // change to true to display date in Dutch

        var Italian = false;     // change to true to display date in Italian