/* *************************************** */
/* Leave this notice please, give credit where it's due */
/* Widget code by @FIF7Y - http://www.fif7y.com */
/* MOD by << @Zooropalg >> */

/* The following scripts will allow you to finetune */
/* *************************************** */


/* ******** Configure Your Weather Widget here ******* */
// Yahoo weather code
// To get weather code, follow these steps:
// 1. Visit Yahoo Weather
// http://weather.yahoo.com/
// 2  Search for your city/town.
// 3. Select the appropriate result and go to that page.
// 4. Find a series of numbers at the end of the page's URL. 
// For example, this is New York's:
// http://weather.yahoo.com/united-states/new-york/new-york-2459115/
// 5. The last digits of the URL is your weather code


var locale = "583067" 

// Examples:
// var locale = "2459115"   - New York
// var locale = "44418"     - London
// var locale = "615702"    - Paris
// var locale = "721943"    - Rome
// var locale = "766273"    - Madrid
// var locale = "638242"    - Berlin
// var locale = "583067"   - carentan
// var locale = "582770"    - cambrai



/* **************** CLOCK **************** */

//Toggles twelve and twenty-four hour time.
// false = 12h time format
// true = 24h time format

var twentyFourHourTime = true;

/* ************* BACKGROUND ************** */
// Use the Widgets wallpaper or your own
// Using your own wallpaper requires Wallpaper JPEGifier from cydia
// You will have to respring after selecting a wallpaper -
// through the settings app for changes to apply
// True = Default wallpaper
// False = Your own
var defWallpaper = true;

/* ********* WEATHER ICON STYLE ********** */
// 1 = htc Weather style
// 2 = edgy Weather style
var iconStyle = 1

/* ************* LANGUAGE **************** */
//Choose Languages :
// English = EN
// French = FR
// Italian = IT
// Spanish = ES
// German = DE
// Russian = RU
// Swedish = SE

var language = 'FR';



/* **************************************************** */
/*  *********** Extra Options ************************* */

/* Use Celsius or not */
var isCelsius = true

/* Use Real Feel Temperature or not */
var useRealFeel = false

/* Minutes between updates */
var updateInterval = 15


/* ***************************************************** */
