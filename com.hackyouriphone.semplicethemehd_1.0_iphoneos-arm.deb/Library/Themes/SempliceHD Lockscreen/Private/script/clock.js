if (langen == true) {
var LangTranslate = English;

}else if (langger == true) {
var LangTranslate = German;

}else if (langspa == true) {
var LangTranslate = Spanish;

}else if (langit == true) {
var LangTranslate = Italian;
}

function init ( )
{
  timeDisplay = document.createTextNode ( "" );
document.getElementById("clock").appendChild ( timeDisplay );
}
function updateClock () {
	var currentTime = new Date ();
	var currentHours = currentTime.getHours ();
	var currentMinutes = currentTime.getMinutes ();
	var currentSeconds = currentTime.getSeconds ();
	timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

	if (ampm == false) {
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
	currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;
	currentTimeString = currentHours;
	currentTimeString1 = currentMinutes;
	currentTimeString2 = currentSeconds;
document.getElementById("hours").firstChild.nodeValue = currentTimeString + ":";
document.getElementById("mins").firstChild.nodeValue = currentTimeString1 + ":";
document.getElementById("secs").firstChild.nodeValue = currentTimeString2;
	document.getElementById("ampm").innerHTML = timeOfDay;
	} else {
 	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
	currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;
	currentTimeString = currentHours;
	currentTimeString1 = currentMinutes;
	currentTimeString2 = currentSeconds;
	currentTimeString3 = timeOfDay;
document.getElementById("hours").firstChild.nodeValue = currentTimeString + ":";
document.getElementById("mins").firstChild.nodeValue = currentTimeString1 + ":";
document.getElementById("secs").firstChild.nodeValue = currentTimeString2;
document.getElementById("ampm").firstChild.nodeValue = currentTimeString3;
	}
}

function calendarDate ( )
{
	var this_date_name_array = new Array ("00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27" ,"28", "29" ,"30", "31")
	
var this_month_name_array = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];


if (langen == true) {
var this_weekday_name_array = ["Su","Mo","Tu","We","Th","Fr","Sa"];

}else if (langit == true) {
var this_weekday_name_array = ["Do","Lu","Ma","Me","Gi","Ve","Sa"];

}else if (langger == true) {
var this_weekday_name_array = ["So","Mo","Di","Mi","Do","Fr","Sa"];

}else if (langspa == true) {
var this_weekday_name_array = ["Do","Lu","Ma","Mi","Ju","Vi","Sa"];
}

	var this_date_timestamp = new Date()
	var this_weekday = this_date_timestamp.getDay()
	var this_date = this_date_timestamp.getDate()
	var this_month = this_date_timestamp.getMonth()
	var this_year = this_date_timestamp.getYear()

      if (this_year < 1000)
      this_year+= 1900;
      if (this_year==101)
      this_year=2001;	  

	document.getElementById("weekday").firstChild.nodeValue = this_weekday_name_array[this_weekday] 
	document.getElementById("month").firstChild.nodeValue = this_date_name_array[this_date] + "-" + this_month_name_array[this_month]
	document.getElementById("year").firstChild.nodeValue = this_year
}