//Weather Settings
var locale = "GMXX0033"; // Yahoo Weather
var ampm = true; // Set to true for 12h format and am/pm display | Set false for 24h format
var isCelsius = false; //true|false
var useRealFeel = false; //true|false
var source = 'yahooWeather';
var updateInterval = 5; //Minutes
var enableLockScreen = true;
var iconSetLock = 'Custom'
var iconExtLock = '.png'
var demoMode = false;


//Language Settings (only set ONE to true)
var langen = false; // set "true" for english translation (weather, date etc.)
var langger = true; // set "true" for german translation (weather, date etc.)
var langspa = false; // set "true" for spanish translation (weather, date etc.)
var langit = false; // set "true" for italian translation (weather, date etc.)
