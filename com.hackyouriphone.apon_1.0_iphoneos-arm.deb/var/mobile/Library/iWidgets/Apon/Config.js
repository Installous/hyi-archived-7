var Scale = "0.8"; 
var Clock = "12h"; // choose between "12h" or "24h"
var Lang = "en"; // choose between "en", "id", "fr", "de", or "it"
var refreshrate = 10; // update interval of weather, in minutes
var PlayerColor = ""; 
var TextColor = ""; 
var LineColor = "tomato"; 
var IndicatorBattColor = "coral"; 
var WeatherIcon = 1; // 1= white, 2= black, 3= color
var DarkMode = false; 
var HideImage = false; 
var HidePlayer = false; 
var HideBattery = false; 
var AdaptiveBG = true; // adaptive background color with dominant color in the image
