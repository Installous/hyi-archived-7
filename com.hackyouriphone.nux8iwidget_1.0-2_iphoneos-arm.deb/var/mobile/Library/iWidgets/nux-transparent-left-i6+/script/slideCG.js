  $(document).ready(function(){

  	//A Panel - Simplest Version
  	$("#a_panel").panel({
 		handle:'#a_panel > .panel_tab',
 		content:'#a_panel > .panel_content',
 		opened:true,
 		direction : "both",
     
      	openEvent : 'mouseenter',
      	closeEvent : 'mouseleave',
      	openSelector : '#a_panel',
      	closeSelector : '#a_panel',
 	});		
  	//B Panel - Right Opening Panels Starting Closed
   	$("#b_panel_1").panel({
 		handle:'#b_panel_1 > .panel_tab',
 		content:'#b_panel_1 > .panel_content',
 		opened:false,
 		direction : "right",
      	openEvent : 'mouseenter',
      	closeEvent : 'mouseleave',
      	openSelector : '#b_panel_1',
      	closeSelector : '#b_panel_1',
 	});		
   	
   	$("#b_panel_2").panel({
 		handle:'#b_panel_2 > .panel_tab',
 		content:'#b_panel_2 > .panel_content',
 		opened:false,
 		direction : "right",
      	openEvent : 'mouseenter',
      	closeEvent : 'mouseleave',
      	openSelector : '#b_panel_2',
      	closeSelector : '#b_panel_2',
 	});		
    
	$("#b_panel_3").panel({
 		handle:'#b_panel_3 > .panel_tab',
 		content:'#b_panel_3 > .panel_content',
 		opened:false,
 		direction : "right",
      	openEvent : 'mouseenter',
      	closeEvent : 'mouseleave',
      	openSelector : '#b_panel_3',
      	closeSelector : '#b_panel_3',
 	});		
 
  	//C Panel - Right Opening Panels Starting Open
    	$("#c_panel_1").panel({
 		handle:'#c_panel_1 > .panel_tab',
 		content:'#c_panel_1 > .panel_content',
 		opened:true,
 		direction : "both",
      	openEvent : 'mouseenter',
      	closeEvent : 'mouseleave',
      	openSelector : '#c_panel_1',
      	closeSelector : '#c_panel_1',
 	});		
   	
   	$("#c_panel_2").panel({
 		handle:'#c_panel_2 > .panel_tab',
 		content:'#c_panel_2 > .panel_content',
 		opened:true,
 		direction : "both",
      	openEvent : 'mouseenter',
      	closeEvent : 'mouseleave',
      	openSelector : '#c_panel_2',
      	closeSelector : '#c_panel_2',
 	});		
    
	$("#c_panel_3").panel({
 		handle:'#c_panel_3 > .panel_tab',
 		content:'#c_panel_3 > .panel_content',
 		opened:true,
 		direction : "both",
      	openEvent : 'mouseenter',
      	closeEvent : 'mouseleave',
      	openSelector : '#c_panel_3',
      	closeSelector : '#c_panel_3',
 	});		
 
  	//D Panel - Toggle a Specic Panel From Event
  	
  	$("#d_panel").panel({
 		handle:'#d_panel > .panel_tab',
 		content:'#d_panel > .panel_content',
 		opened:false,
 		direction : "both",
      	toggleEvent : 'click',
      	toggleSelector : '#d_toggle'
 	});		
  	
  	//E Panel - Open all Panels From an Event
  	$("#e_panel_1").panel({
 		handle:'#e_panel_1 > .panel_tab',
 		content:'#e_panel_1 > .panel_content',
 		opened:false,
 		direction : "both",
      	openEvent : 'click',
      	closeEvent : 'mouseleave',
      	openSelector : '#e_open',
      	closeSelector : '#e_panel_1',
 	});	
 	
  	$("#e_panel_2").panel({
 		handle:'#e_panel_2 > .panel_tab',
 		content:'#e_panel_2 > .panel_content',
 		opened:false,
 		direction : "both",
      	openEvent : 'click',
      	closeEvent : 'mouseleave',
      	openSelector : '#e_open',
      	closeSelector : '#e_panel_2',
 	});	

  });