var Clock = "24h"; // choose between "12h" or "24h"
var lang = "en"; // (tr) for turkish, (de) for german, (sp) for spanish, (it) for italian, (en) for english
var updateInterval = 30; 
