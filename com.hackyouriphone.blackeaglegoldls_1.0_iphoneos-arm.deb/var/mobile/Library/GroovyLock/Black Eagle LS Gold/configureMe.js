
var totalpics=1; //Total number of wallpapers in the "Images/Backgrounds" folder...starting from 0


var interval=60; //How often the wallpaper will change (in minutes)

