function init()
{
    var container = document.getElementById('iceblockContainer');
    for (var i = 0; i < NUMBER_OF_Iceblocks; i++) 
    {
        container.appendChild(createAiceblock());
    }
}

function randomInteger(low, high)
{
    return low + Math.floor(Math.random() * (high - low));
}

function randomFloat(low, high)
{
    return low + Math.random() * (high - low);
}

function pixelValue(value)
{
    return value + 'px';
}

function durationValue(value)
{
    return value + 's';
}

function createAiceblock()
{
    var iceblockDiv = document.createElement('div');
    var image = document.createElement('img');
    
    image.src = 'images/iceblock' + randomInteger(1, 5) + '.png';
    
    iceblockDiv.style.top = pixelValue(randomInteger(-150, -50));
    iceblockDiv.style.left = pixelValue(randomInteger(0, 500));
    
    var spinAnimationName = (Math.random() < 0.5) ? 'clockwiseSpin' : 'counterclockwiseSpinAndFlip';
    
    iceblockDiv.style.webkitAnimationName = 'fade, drop';
    image.style.webkitAnimationName = spinAnimationName;
    
    var fadeAndDropDuration = durationValue(randomFloat(5, 11));
    
    var spinDuration = durationValue(randomFloat(4, 8));

    iceblockDiv.style.webkitAnimationDuration = fadeAndDropDuration + ', ' + fadeAndDropDuration;
    image.style.webkitAnimationDuration = spinDuration;

    iceblockDiv.appendChild(image);

    return iceblockDiv;
}

window.addEventListener('load', init, false);
