//
//  hAcxSyncFileInfo.h
//  hAcxAudioManagerTools
//
//  Created by Action Item on 9/26/14.
//  Copyright (c) 2014 hAcx. All rights reserved.
//

@interface hAcxSyncFileInfo : NSObject <NSCoding>

@property (nonatomic, strong) NSString *uniqueIdentifier;
@property (nonatomic, strong) NSString *filepath;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, unsafe_unretained) NSTimeInterval creationTimeInterval;

@end
