
enum  {
    syncServiceGoogleDrive = 5,
    syncServiceDropBox,
}; typedef NSInteger SyncService;
